<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mx-auto', 'max-w-3xl' => ($c['width'] ?? 'narrow') === 'narrow', 'max-w-5xl' => ($c['width'] ?? 'narrow') === 'wide']); ?>">
        <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'align' => 'left','class' => 'mb-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'align' => 'left','class' => 'mb-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
        <?php if(filled($c['body'])): ?>
            <div class="prose-site" data-reveal-children><?php echo $c['body']; ?></div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/rich-text.blade.php ENDPATH**/ ?>
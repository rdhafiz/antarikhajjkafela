<?php
    use App\Support\Money;

    $steps = array_values(array_filter($c['steps'] ?? [], fn ($s) => filled($s['title'])));
    $count = count($steps);
    $dark = $style['tone'] === 'dark';
    $uid = 'journey-'.$section->id;
    $latin = app()->getLocale() !== 'bn';
    $pad = fn (int $n) => Money::digits(str_pad((string) $n, 2, '0', STR_PAD_LEFT));
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'class' => 'mb-12 lg:mb-14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'class' => 'mb-12 lg:mb-14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>

    
    <div
        x-data="journey(<?php echo e($count); ?>)"
        @mouseenter="hold(true)" @mouseleave="hold(false)" @focusin="hold(true)" @focusout="hold(false)"
        class="journey grid gap-5 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:gap-8"
        data-reveal
    >
        <div role="tablist" aria-label="<?php echo e($c['title'] ?: __('Steps')); ?>" class="grid gap-2 lg:flex lg:flex-col lg:gap-0" style="grid-template-columns: repeat(<?php echo e($count); ?>, minmax(0, 1fr))" @keydown="keys($event)">
            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button
                    type="button" role="tab" id="<?php echo e($uid); ?>-tab-<?php echo e($index); ?>" aria-controls="<?php echo e($uid); ?>-panel-<?php echo e($index); ?>"
                    <?php if($index === 0): ?> aria-selected="true" <?php else: ?> aria-selected="false" tabindex="-1" <?php endif; ?>
                    :aria-selected="active === <?php echo e($index); ?>" :tabindex="active === <?php echo e($index); ?> ? 0 : -1"
                    @click="select(<?php echo e($index); ?>)"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['journey-tab group relative flex flex-col gap-1 pt-4 text-start lg:flex-1 lg:flex-row lg:items-center lg:gap-5 lg:py-5 lg:ps-7', 'is-active' => $index === 0]); ?>"
                    :class="{ 'is-active': active === <?php echo e($index); ?>, 'is-past': active > <?php echo e($index); ?> }"
                >
                    <span class="journey-rail" aria-hidden="true"><span></span></span>
                    <span class="journey-num shrink-0 font-display text-[1.375rem] lg:w-12 leading-none font-semibold tabular-nums lg:text-[2rem]"><?php echo e($pad($index + 1)); ?></span>
                    <span class="min-w-0 max-md:sr-only">
                        <span class="journey-title sec-heading block font-display text-[1rem] lg:text-[1.1875rem] leading-snug font-semibold"><?php echo e($step['title']); ?></span>
                    </span>
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'journey-arrow ms-auto hidden size-5 shrink-0 lg:block rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'journey-arrow ms-auto hidden size-5 shrink-0 lg:block rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'journey-stage relative isolate grid min-h-[22rem] overflow-hidden rounded-[2rem] text-white lg:min-h-[26rem]',
            'bg-brand-950' => ! $dark,
            'border border-white/10 bg-white/[0.06]' => $dark,
        ]); ?>" :style="{ '--step': active }">
            <div class="pattern-star absolute inset-0 -z-10 opacity-[0.07]" aria-hidden="true"></div>
            <div class="journey-glow absolute -z-10 size-[28rem] rounded-full bg-gold/10 blur-3xl" aria-hidden="true"></div>

            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    role="tabpanel" id="<?php echo e($uid); ?>-panel-<?php echo e($index); ?>" aria-labelledby="<?php echo e($uid); ?>-tab-<?php echo e($index); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['journey-panel relative flex flex-col p-7 sm:p-10 lg:p-12', 'is-active' => $index === 0]); ?>"
                    :class="{ 'is-active': active === <?php echo e($index); ?> }"
                    <?php if($index > 0): ?> inert <?php endif; ?>
                    :inert="active !== <?php echo e($index); ?>"
                >
                    <span class="journey-bignum font-display font-semibold tabular-nums" aria-hidden="true"><?php echo e($pad($index + 1)); ?></span>

                    <div class="flex items-center gap-4">
                        <span class="jp-in relative flex size-16 shrink-0 items-center justify-center rounded-full bg-gold text-brand-950" style="--i: 0">
                            <span class="journey-ring" aria-hidden="true"></span>
                            <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => $step['icon'] ?: 'check-circle','class' => 'size-7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($step['icon'] ?: 'check-circle'),'class' => 'size-7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                        </span>
                        <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(["jp-in text-[13px] font-semibold text-gold", "tracking-[0.18em] uppercase" => $latin]); ?>" style="--i: 1">
                            <?php echo e(__('Step :current of :total', ['current' => $pad($index + 1), 'total' => $pad($count)])); ?>

                        </p>
                    </div>

                    <h3 class="jp-in mt-8 font-display text-display-md text-white sm:mt-10" style="--i: 2"><?php echo e($step['title']); ?></h3>
                    <?php if(filled($step['text'])): ?>
                        <p class="jp-in mt-4 max-w-md text-[1.0625rem] leading-relaxed text-white/75" style="--i: 3"><?php echo e($step['text']); ?></p>
                    <?php endif; ?>

                    <?php if($count > 1): ?>
                        <div class="jp-in mt-auto flex items-center gap-3 pt-10" style="--i: 4">
                            <button type="button" class="journey-nav" @click="select(<?php echo e(($index - 1 + $count) % $count); ?>)" aria-label="<?php echo e(__('Previous step')); ?>">
                                <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-left','class' => 'size-5 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-left','class' => 'size-5 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                            </button>
                            <button type="button" class="journey-nav" @click="select(<?php echo e(($index + 1) % $count); ?>)" aria-label="<?php echo e(__('Next step')); ?>">
                                <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-right','class' => 'size-5 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-5 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                            </button>
                            <?php if($index + 1 < $count): ?>
                                <p class="ms-2 min-w-0 truncate text-[14px] text-white/60">
                                    <?php echo e(__('Next')); ?>: <span class="font-semibold text-white/90"><?php echo e($steps[$index + 1]['title']); ?></span>
                                </p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/process-steps.blade.php ENDPATH**/ ?>
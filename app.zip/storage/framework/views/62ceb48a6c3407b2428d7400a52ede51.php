<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'eyebrow' => null,
    'highlight' => null,    // gold italic line under the title
    'intro' => null,
    'image' => null,        // App\Models\Media background; falls back to the default banner
    'stats' => [],          // list of ['value' => string|Htmlable, 'label' => string, 'small' => bool] for the strip at the bottom
    'top' => true,          // at the top of the page: 75vh, parallax, overlay header
    'tag' => 'section',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'eyebrow' => null,
    'highlight' => null,    // gold italic line under the title
    'intro' => null,
    'image' => null,        // App\Models\Media background; falls back to the default banner
    'stats' => [],          // list of ['value' => string|Htmlable, 'label' => string, 'small' => bool] for the strip at the bottom
    'top' => true,          // at the top of the page: 75vh, parallax, overlay header
    'tag' => 'section',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $image ??= app(App\Support\Branding::class)->defaultBanner();
    $stats = array_values(array_filter($stats, fn ($stat) => filled((string) ($stat['value'] ?? ''))));
?>
<<?php echo e($tag); ?> <?php echo e($attributes->class(['relative isolate flex flex-col overflow-hidden bg-brand-950 text-white', 'hero-75 pt-20' => $top])); ?> <?php if($top): ?> data-hero <?php endif; ?>>
    <?php if($image): ?>
        <div class="hero-media" <?php if($top): ?> data-parallax-bg <?php endif; ?> aria-hidden="true">
            <img src="<?php echo e($image->url('lg')); ?>" srcset="<?php echo e($image->srcset()); ?>" sizes="100vw" alt="" <?php if($top): ?> fetchpriority="high" <?php else: ?> loading="lazy" <?php endif; ?>>
        </div>
        <div class="absolute inset-0 -z-10 bg-gradient-to-b from-brand-950/80 via-brand-950/65 to-brand-950/90" aria-hidden="true"></div>
    <?php else: ?>
        <div class="absolute inset-0 -z-20 bg-gradient-to-br from-brand via-brand-900 to-brand-950" aria-hidden="true"></div>
        <div class="pattern-star absolute inset-0 -z-10 opacity-[0.06]" aria-hidden="true"></div>
    <?php endif; ?>

    <div class="container-site flex flex-1 flex-col items-center justify-center py-12 text-center sm:py-14">
        <div class="hero-reveal flex max-w-4xl flex-col items-center" <?php if($top): ?> data-parallax-content <?php endif; ?>>
            <?php if(filled($eyebrow)): ?>
                <p class="eyebrow eyebrow-light justify-center"><?php echo e($eyebrow); ?></p>
            <?php endif; ?>
            <h1 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-display-xl text-white', 'mt-5' => filled($eyebrow)]); ?>">
                <?php echo e($title); ?>

                <?php if(filled($highlight)): ?><span class="hero-line text-gold italic"><?php echo e($highlight); ?></span><?php endif; ?>
            </h1>
            <?php if(filled($intro)): ?>
                <p class="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-white/80"><?php echo e($intro); ?></p>
            <?php endif; ?>
            <?php if($slot->isNotEmpty()): ?>
                <div class="mt-9 flex w-full flex-col items-center"><?php echo e($slot); ?></div>
            <?php endif; ?>
        </div>
    </div>

    <?php if($stats): ?>
        <div class="relative z-10 border-t border-white/10 bg-brand-950/85 backdrop-blur-md">
            <dl class="<?php echo \Illuminate\Support\Arr::toCssClasses(['container-site grid gap-y-6 py-5 sm:py-6', ['grid-cols-1', 'grid-cols-2', 'grid-cols-3', 'grid-cols-2 sm:grid-cols-4'][min(4, count($stats)) - 1]]); ?>">
                <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex flex-col-reverse items-center px-2 text-center', 'border-l border-white/10' => $index > 0 && count($stats) < 4, 'sm:border-l sm:border-white/10 sm:first:border-l-0' => count($stats) >= 4]); ?>">
                        <dt class="mt-1 text-[12px] tracking-wide text-white/60 sm:text-[13px]"><?php echo e($stat['label']); ?></dt>
                        <dd class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'font-display text-xl font-semibold text-gold sm:text-3xl' => ! ($stat['small'] ?? false),
                            'flex min-h-8 items-center gap-2 text-[15px] font-semibold text-white sm:min-h-9 sm:text-lg' => $stat['small'] ?? false,
                        ]); ?>" <?php if (! ($stat['small'] ?? false)): ?> data-count <?php endif; ?>><?php echo e($stat['value']); ?></dd>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </dl>
        </div>
    <?php endif; ?>
</<?php echo e($tag); ?>>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/hero.blade.php ENDPATH**/ ?>
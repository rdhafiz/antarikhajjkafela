<?php
    $catalogue = App\Domain\Forms\LeadFields::all();
    $fields = array_values(array_filter($c['fields'] ?? [], fn ($f) => isset($catalogue[$f['field'] ?? ''])));
    $fields = collect($fields)->unique('field')->values()->all();
    $packages = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $c['package_options']))));
    $bullets = array_filter($c['bullets'] ?? [], fn ($b) => filled($b['text']));
    $labels = [
        'name' => __('Full name'), 'phone' => __('Mobile number'), 'email' => __('Email'), 'district' => __('District'),
        'thana' => __('Thana / Upazila'), 'package' => __('Package of interest'), 'travelers' => __('Number of travelers'),
        'travel_month' => __('Preferred travel month'), 'message' => __('Message'),
    ];
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="grid items-start gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div class="lg:sticky lg:top-28">
            <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'align' => 'left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
            <?php if($bullets): ?>
                <ul class="mt-8 space-y-4">
                    <?php $__currentLoopData = $bullets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bullet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex gap-3">
                            <span class="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-emerald text-white"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                            <span class="sec-text text-[1.0625rem]"><?php echo e($bullet['text']); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>

        <?php if (isset($component)) { $__componentOriginal278a1e3ada932f630caf369b0e326277 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal278a1e3ada932f630caf369b0e326277 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.form-shell','data' => ['section' => $section,'submitLabel' => $c['submit_label'] ?: __('Register now'),'success' => $c['success'] ?: __('Thank you! Our team will call you soon, In Sha Allah.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.form-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section),'submit-label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['submit_label'] ?: __('Register now')),'success' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['success'] ?: __('Thank you! Our team will call you soon, In Sha Allah.'))]); ?>
            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('sections.partials.form-field', [
                    'sectionId' => $section->id,
                    'name' => $field['field'],
                    'label' => filled($field['label']) ? $field['label'] : $labels[$field['field']],
                    'type' => $catalogue[$field['field']]['type'],
                    'required' => (bool) $field['required'],
                    'autocomplete' => $catalogue[$field['field']]['autocomplete'],
                    'options' => $packages,
                    'wide' => count($fields) % 2 === 1 && $loop->last,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal278a1e3ada932f630caf369b0e326277)): ?>
<?php $attributes = $__attributesOriginal278a1e3ada932f630caf369b0e326277; ?>
<?php unset($__attributesOriginal278a1e3ada932f630caf369b0e326277); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal278a1e3ada932f630caf369b0e326277)): ?>
<?php $component = $__componentOriginal278a1e3ada932f630caf369b0e326277; ?>
<?php unset($__componentOriginal278a1e3ada932f630caf369b0e326277); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/lead-form.blade.php ENDPATH**/ ?>
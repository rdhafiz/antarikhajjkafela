
<?php
    use App\Domain\Blog\PostPresenter;
    use App\Support\Money;

    $locale = app()->getLocale();
    $rest = $posts->getCollection()->when($lead, fn ($c) => $c->reject(fn ($p) => $p->is($lead)))->values();
    $title = filled($c['title'] ?? null) ? $c['title'] : ($first ? $page->getTranslation('title', $locale) : null);
    $headingTag = $first ? 'h1' : 'h2';
    $pill = 'shrink-0 rounded-full px-4.5 py-2 text-[14px] font-semibold transition-colors duration-300';
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="pointer-events-none absolute -top-40 left-1/2 -z-10 size-[620px] -translate-x-1/2 rounded-full bg-gold/10 blur-3xl" data-parallax="-0.15" aria-hidden="true"></div>

    
    <?php if($title || filled($c['eyebrow'] ?? null) || filled($c['intro'] ?? null)): ?>
        <div class="mx-auto mb-9 max-w-2xl text-center" data-reveal>
            <?php if(filled($c['eyebrow'] ?? null)): ?><p class="eyebrow justify-center"><?php echo e($c['eyebrow']); ?></p><?php endif; ?>
            <?php if($title): ?>
                <<?php echo e($headingTag); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sec-heading text-display-lg', 'mt-4' => filled($c['eyebrow'] ?? null)]); ?>"><?php echo e($title); ?></<?php echo e($headingTag); ?>>
            <?php endif; ?>
            <?php if(filled($c['intro'] ?? null)): ?><p class="sec-text mt-5 text-[1.0625rem] leading-relaxed"><?php echo e($c['intro']); ?></p><?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if($categories->count() > 1 || $tag): ?>
        <nav class="mx-auto mb-12 flex w-fit max-w-full gap-2 overflow-x-auto pb-1 sm:flex-wrap sm:justify-center" aria-label="<?php echo e(__('Categories')); ?>" data-reveal style="--reveal-delay: 80ms">
            <a href="<?php echo e($blogUrl); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([$pill, 'bg-brand text-white' => ! $category && ! $tag, 'bg-white text-ink-2 ring-1 ring-line hover:text-brand' => $category || $tag]); ?>" <?php if(! $category && ! $tag): ?> aria-current="page" <?php endif; ?>><?php echo e(__('All')); ?></a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($item->url()); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([$pill, 'bg-brand text-white' => $category?->is($item), 'bg-white text-ink-2 ring-1 ring-line hover:text-brand' => ! $category?->is($item)]); ?>" <?php if($category?->is($item)): ?> aria-current="page" <?php endif; ?>><?php echo e($item->getTranslation('name', $locale)); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($tag): ?>
                <a href="<?php echo e($blogUrl); ?>" class="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-gold px-4 py-2 text-[14px] font-semibold text-brand-950" aria-label="<?php echo e(__('Remove filter')); ?>: #<?php echo e($tag); ?>">
                    #<?php echo e($tag); ?> <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'x','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                </a>
            <?php endif; ?>
        </nav>
    <?php endif; ?>

    <?php if($posts->isEmpty()): ?>
        <div class="mx-auto max-w-md py-10 text-center" data-reveal>
            <span class="sec-icon mx-auto size-14"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'book','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book','class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
            <p class="sec-heading mt-5 font-display text-display-sm"><?php echo e(__('No articles yet')); ?></p>
            <p class="sec-text mt-2"><?php echo e(__('New guides and news will appear here soon.')); ?></p>
            <?php if($category || $tag): ?>
                <a href="<?php echo e($blogUrl); ?>" class="mt-5 inline-flex font-semibold text-brand hover:underline"><?php echo e(__('See all articles')); ?></a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        
        <?php if($lead): ?>
            <?php
                $leadMinutes = app(PostPresenter::class)->minutes($lead);
                $excerpt = $lead->getTranslation('excerpt', $locale);
            ?>
            <article class="group relative isolate mx-auto flex min-h-[24rem] max-w-6xl flex-col items-start justify-end overflow-hidden rounded-[2rem] bg-brand-950 px-6 pt-24 pb-9 text-start text-white shadow-[var(--shadow-lift)] sm:min-h-[30rem] sm:px-12 sm:pb-12">
                <?php if($lead->banner): ?>
                    <div class="absolute inset-0 -z-20 overflow-hidden">
                        <img src="<?php echo e($lead->banner->url('lg')); ?>" srcset="<?php echo e($lead->banner->srcset()); ?>" sizes="(min-width: 1200px) 1150px, 100vw" alt=""
                             class="size-full object-cover transition-[scale] duration-[1400ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]">
                    </div>
                <?php else: ?>
                    <div class="pattern-star absolute inset-0 -z-20 opacity-[0.08]" aria-hidden="true"></div>
                <?php endif; ?>
                <div class="absolute inset-0 -z-10 bg-gradient-to-r from-brand-950/90 via-brand-950/45 to-transparent rtl:bg-gradient-to-l" aria-hidden="true"></div>
                    <div class="absolute inset-x-0 bottom-0 -z-10 h-2/3 bg-gradient-to-t from-brand-950/85 to-transparent" aria-hidden="true"></div>

                <div class="flex max-w-xl flex-col items-start" data-reveal>
                    <p class="flex flex-wrap items-center gap-x-3 gap-y-2 text-[13px] font-medium text-white/80">
                        <?php if($lead->category): ?>
                            <span class="rounded-full bg-gold px-3 py-1 text-[12px] font-bold text-brand-950"><?php echo e($lead->category->getTranslation('name', $locale)); ?></span>
                        <?php endif; ?>
                        <time datetime="<?php echo e($lead->published_at?->toDateString()); ?>"><?php echo e(PostPresenter::date($lead->published_at)); ?></time>
                        <span class="size-1 rounded-full bg-gold" aria-hidden="true"></span>
                        <span><?php echo e(trans_choice(':count min read|:count min read', $leadMinutes, ['count' => Money::digits($leadMinutes)])); ?></span>
                    </p>
                    <<?php echo e($first ? 'h2' : 'h3'); ?> class="mt-4 font-display text-display-lg text-white">
                        <a href="<?php echo e($lead->url()); ?>" class="after:absolute after:inset-0 focus-visible:outline-none"><?php echo e($lead->getTranslation('title', $locale)); ?></a>
                    </<?php echo e($first ? 'h2' : 'h3'); ?>>
                    <?php if(filled($excerpt)): ?>
                        <p class="mt-3 line-clamp-2 text-[1.0625rem] leading-relaxed text-white/80"><?php echo e($excerpt); ?></p>
                    <?php endif; ?>
                </div>
                <span class="mt-7 inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 text-[15px] font-semibold text-brand-950 shadow-[0_10px_30px_-12px_rgb(250_204_21/0.6)]" data-reveal style="--reveal-delay: 120ms" aria-hidden="true">
                    <?php echo e(__('Read article')); ?>

                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'size-4 transition-[translate] duration-500 group-hover:translate-x-1 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'size-4 transition-[translate] duration-500 group-hover:translate-x-1 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                </span>
            </article>
        <?php endif; ?>

        
        <?php if($rest->isNotEmpty()): ?>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mx-auto flex max-w-6xl flex-wrap justify-center gap-6', 'mt-8' => $lead]); ?>">
                <?php $__currentLoopData = $rest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.post-card','data' => ['post' => $post,'headingTag' => $lead ? 'h3' : 'h2','class' => 'w-full sm:w-[calc(50%-0.75rem)] lg:w-[calc(33.333%-1rem)]','dataReveal' => true,'style' => '--reveal-delay: '.(($index % 3) * 90).'ms']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.post-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post),'heading-tag' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lead ? 'h3' : 'h2'),'class' => 'w-full sm:w-[calc(50%-0.75rem)] lg:w-[calc(33.333%-1rem)]','data-reveal' => true,'style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('--reveal-delay: '.(($index % 3) * 90).'ms')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a)): ?>
<?php $attributes = $__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a; ?>
<?php unset($__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a)): ?>
<?php $component = $__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a; ?>
<?php unset($__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal421d6be1b5f010ae1063d2260f192bb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal421d6be1b5f010ae1063d2260f192bb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.pagination','data' => ['paginator' => $posts,'class' => 'mt-14 flex justify-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($posts),'class' => 'mt-14 flex justify-center']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal421d6be1b5f010ae1063d2260f192bb5)): ?>
<?php $attributes = $__attributesOriginal421d6be1b5f010ae1063d2260f192bb5; ?>
<?php unset($__attributesOriginal421d6be1b5f010ae1063d2260f192bb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal421d6be1b5f010ae1063d2260f192bb5)): ?>
<?php $component = $__componentOriginal421d6be1b5f010ae1063d2260f192bb5; ?>
<?php unset($__componentOriginal421d6be1b5f010ae1063d2260f192bb5); ?>
<?php endif; ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/blog/listing.blade.php ENDPATH**/ ?>
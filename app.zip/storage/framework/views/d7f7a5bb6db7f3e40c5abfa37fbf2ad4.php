<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['package']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['package']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $locale = app()->getLocale();
    $state = $package->bookingState();
    $name = $package->getTranslation('name', $locale);
?>
<div <?php echo e($attributes->class('h-full')); ?>>
<article class="group relative flex h-full flex-col overflow-hidden rounded-[1.5rem] border border-line bg-white shadow-[var(--shadow-soft)] transition-[translate,box-shadow] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1.5 hover:shadow-[var(--shadow-lift)]">
    <div class="relative aspect-[16/10] overflow-hidden bg-brand">
        <?php if($package->banner): ?>
            <img
                src="<?php echo e($package->banner->url('sm')); ?>"
                srcset="<?php echo e($package->banner->srcset()); ?>"
                sizes="(min-width: 1024px) 380px, (min-width: 640px) 50vw, 100vw"
                alt=""
                loading="lazy"
                decoding="async"
                class="size-full object-cover transition-[scale] duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.05]"
            >
        <?php else: ?>
            <div class="pattern-star absolute inset-0 opacity-[0.08]" aria-hidden="true"></div>
            <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'kaaba','class' => 'absolute top-1/2 left-1/2 size-16 -translate-x-1/2 -translate-y-1/2 text-gold/70']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'kaaba','class' => 'absolute top-1/2 left-1/2 size-16 -translate-x-1/2 -translate-y-1/2 text-gold/70']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
        <?php endif; ?>
        <div class="absolute inset-0 bg-gradient-to-t from-brand-950/60 via-transparent to-transparent" aria-hidden="true"></div>

        <div class="absolute top-4 left-4 flex flex-wrap gap-2">
            <span class="rounded-full bg-white/95 px-3 py-1 text-[12px] font-semibold text-brand"><?php echo e($package->service?->getTranslation('name', $locale)); ?></span>
            <?php if($package->is_featured): ?>
                <span class="rounded-full bg-gold px-3 py-1 text-[12px] font-bold text-brand-950"><?php echo e(__('Featured')); ?></span>
            <?php endif; ?>
        </div>
        <?php if($state !== 'open'): ?>
            <span class="absolute right-4 bottom-4 rounded-full bg-brand-950/85 px-3 py-1 text-[12px] font-semibold text-white">
                <?php echo e($state === 'closed' ? __('Booking closed') : __('Opening soon')); ?>

            </span>
        <?php endif; ?>
    </div>

    <div class="flex flex-1 flex-col p-6">
        <h3 class="font-display text-display-sm text-brand">
            <a href="<?php echo e($package->url()); ?>" class="after:absolute after:inset-0"><?php echo e($name); ?></a>
        </h3>
        <?php if($summary = $package->getTranslation('summary', $locale)): ?>
            <p class="mt-2.5 line-clamp-2 text-[15px] leading-relaxed text-ink-2"><?php echo e($summary); ?></p>
        <?php endif; ?>

        <div class="mt-auto flex items-end justify-between gap-4 pt-6">
            <div>
                <?php if($package->min_price): ?>
                    <p class="text-[12px] font-semibold tracking-wide text-ink-3 uppercase"><?php echo e(__('Starting from')); ?></p>
                    <p class="font-display text-[1.6rem] leading-tight font-semibold text-brand"><?php echo e(App\Support\Money::html($package->min_price)); ?></p>
                <?php endif; ?>
            </div>
            <?php if($package->duration_days): ?>
                <p class="flex items-center gap-1.5 rounded-full bg-sand-100 px-3 py-1.5 text-[13px] font-semibold text-ink-2">
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'calendar','class' => 'size-4 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'calendar','class' => 'size-4 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    <?php echo e(trans_choice(':count day|:count days', $package->duration_days, ['count' => App\Support\Money::digits($package->duration_days)])); ?>

                </p>
            <?php endif; ?>
        </div>
    </div>
</article>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/package-card.blade.php ENDPATH**/ ?>
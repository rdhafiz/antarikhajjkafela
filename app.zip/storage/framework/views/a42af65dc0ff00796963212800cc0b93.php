<?php
    use App\Support\Money;

    $locale = app()->getLocale();
    $slides = $items->map(fn ($item) => $item->type === 'video'
        ? ['type' => 'video', 'id' => $item->youtubeId(), 'caption' => $item->getTranslation('caption', $locale)]
        : ['type' => 'image', 'src' => $item->media->url('lg'), 'caption' => $item->getTranslation('caption', $locale) ?: $item->media->getTranslation('alt', $locale)]
    )->values();
    $photoCount = $items->where('type', 'image')->count();
    $videoCount = $items->where('type', 'video')->count();
?>
<?php if (isset($component)) { $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.layout','data' => ['header' => 'overlay']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'overlay']); ?>
    <?php if (isset($component)) { $__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-header','data' => ['title' => $title,'image' => $cover,'intro' => $album->getTranslation('description', $locale),'eyebrow' => App\Support\Dates::format($album->event_date, 'j F Y', $locale),'stats' => [
            ['value' => $photoCount ? Money::digits($photoCount) : null, 'label' => __('Photos')],
            ['value' => $videoCount ? Money::digits($videoCount) : null, 'label' => __('Videos')],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cover),'intro' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($album->getTranslation('description', $locale)),'eyebrow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(App\Support\Dates::format($album->event_date, 'j F Y', $locale)),'stats' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['value' => $photoCount ? Money::digits($photoCount) : null, 'label' => __('Photos')],
            ['value' => $videoCount ? Money::digits($videoCount) : null, 'label' => __('Videos')],
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a)): ?>
<?php $attributes = $__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a; ?>
<?php unset($__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a)): ?>
<?php $component = $__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a; ?>
<?php unset($__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a); ?>
<?php endif; ?>

    <section class="section-light bg-sand-50 py-12 sm:py-16" x-data="lightbox(<?php echo \Illuminate\Support\Js::from($slides)->toHtml() ?>)" @keydown.window="key($event)">
        <div class="container-site">
            <h2 class="sr-only"><?php echo e(__('Photos and videos')); ?></h2>
            <ul class="grid grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3 lg:grid-cols-4" data-reveal>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sm:col-span-2 sm:row-span-2' => $index === 0 && $items->count() >= 5]); ?>">
                        <button type="button" class="group relative block aspect-square w-full overflow-hidden rounded-xl bg-brand-950 focus-visible:ring-4 focus-visible:ring-gold/60 focus-visible:outline-none" @click="open(<?php echo e($index); ?>)"
                                aria-label="<?php echo e($item->type === 'video' ? __('Play video') : __('Open photo')); ?> <?php echo e(Money::digits($index + 1)); ?><?php echo e(($cap = $item->getTranslation('caption', $locale)) ? ': '.$cap : ''); ?>">
                            <?php if($item->type === 'video'): ?>
                                <img src="https://i.ytimg.com/vi/<?php echo e($item->youtubeId()); ?>/hqdefault.jpg" alt="" loading="lazy" decoding="async" class="absolute inset-0 size-full scale-[1.34] object-cover opacity-85 transition-transform duration-500 group-hover:scale-[1.4]">
                                <span class="absolute top-1/2 left-1/2 flex size-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-gold text-brand-950 shadow-xl transition-transform group-hover:scale-110"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'play','class' => 'ml-0.5 size-6 fill-current']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','class' => 'ml-0.5 size-6 fill-current']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                            <?php else: ?>
                                <img
                                    src="<?php echo e($item->media->url($index === 0 && $items->count() >= 5 ? 'md' : 'thumb')); ?>"
                                    <?php if($index === 0 && $items->count() >= 5): ?> srcset="<?php echo e($item->media->srcset()); ?>" sizes="(min-width: 1024px) 50vw, (min-width: 640px) 66vw, 100vw" <?php endif; ?>
                                    alt=""
                                    <?php if($index > 3): ?> loading="lazy" <?php endif; ?>
                                    decoding="async"
                                    class="absolute inset-0 size-full object-cover transition-transform duration-500 group-hover:scale-105"
                                >
                                <span class="absolute inset-0 flex items-center justify-center bg-brand-950/0 transition-colors group-hover:bg-brand-950/30" aria-hidden="true">
                                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'expand','class' => 'size-7 text-white opacity-0 transition-opacity group-hover:opacity-100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'expand','class' => 'size-7 text-white opacity-0 transition-opacity group-hover:opacity-100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                </span>
                            <?php endif; ?>
                        </button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        
        <template x-teleport="body">
            <div x-show="current !== null" x-cloak x-transition.opacity.duration.200ms x-trap.noscroll.inert="current !== null"
                 class="fixed inset-0 z-[100] flex flex-col bg-brand-950/97 text-white"
                 role="dialog" aria-modal="true" aria-label="<?php echo e($title); ?>"
                 @touchstart.passive="touchStart($event)" @touchend.passive="touchEnd($event)">
                <div class="flex items-center justify-between gap-4 px-4 py-3 sm:px-6">
                    <p class="text-[14px] font-semibold text-white/70" aria-live="polite"><span x-text="position"></span></p>
                    <button type="button" class="flex size-11 items-center justify-center rounded-full bg-white/10 hover:bg-white/20" @click="close()" aria-label="<?php echo e(__('Close')); ?>"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'x','class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></button>
                </div>

                <div class="relative flex min-h-0 flex-1 items-center justify-center px-2 sm:px-20">
                    <template x-if="slide && slide.type === 'image'">
                        <img :src="slide.src" :alt="slide.caption || ''" class="max-h-full max-w-full rounded-lg object-contain shadow-2xl">
                    </template>
                    <template x-if="slide && slide.type === 'video'">
                        <div class="aspect-video w-full max-w-5xl overflow-hidden rounded-xl bg-black">
                            <iframe class="size-full" :src="`https://www.youtube-nocookie.com/embed/${slide.id}?autoplay=1&rel=0`" :title="slide.caption || <?php echo \Illuminate\Support\Js::from(__('Video'))->toHtml() ?>" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </template>

                    <button type="button" x-show="slides.length > 1" class="absolute top-1/2 left-2 hidden size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 sm:flex" @click="prev()" aria-label="<?php echo e(__('Previous')); ?>"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-left','class' => 'size-6 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-left','class' => 'size-6 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></button>
                    <button type="button" x-show="slides.length > 1" class="absolute top-1/2 right-2 hidden size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 sm:flex" @click="next()" aria-label="<?php echo e(__('Next')); ?>"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-right','class' => 'size-6 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-6 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></button>
                </div>

                <div class="flex min-h-16 items-center justify-center gap-4 px-4 py-4 text-center">
                    <button type="button" x-show="slides.length > 1" class="flex size-11 shrink-0 items-center justify-center rounded-full bg-white/10 sm:hidden" @click="prev()" aria-label="<?php echo e(__('Previous')); ?>"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-left','class' => 'size-5 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-left','class' => 'size-5 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></button>
                    <p class="max-w-2xl flex-1 text-[15px] text-white/85" x-text="slide?.caption || ''"></p>
                    <button type="button" x-show="slides.length > 1" class="flex size-11 shrink-0 items-center justify-center rounded-full bg-white/10 sm:hidden" @click="next()" aria-label="<?php echo e(__('Next')); ?>"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-right','class' => 'size-5 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-5 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></button>
                </div>
            </div>
        </template>
    </section>

    <?php if($more->isNotEmpty()): ?>
        <section class="section-light py-16 sm:py-20" aria-labelledby="more-albums">
            <div class="container-site">
                <div class="mb-10 flex flex-wrap items-end justify-between gap-4">
                    <h2 id="more-albums" class="sec-heading text-display-lg"><?php echo e(__('More albums')); ?></h2>
                    <a href="<?php echo e($galleryUrl); ?>" class="inline-flex items-center gap-1.5 font-semibold text-brand hover:underline"><?php echo e(__('Full gallery')); ?> <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'size-4 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'size-4 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></a>
                </div>
                <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    <?php $__currentLoopData = $more; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.album-card','data' => ['album' => $item,'dataReveal' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.album-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['album' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item),'data-reveal' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3)): ?>
<?php $attributes = $__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3; ?>
<?php unset($__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3)): ?>
<?php $component = $__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3; ?>
<?php unset($__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $attributes = $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $component = $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/gallery/show.blade.php ENDPATH**/ ?>
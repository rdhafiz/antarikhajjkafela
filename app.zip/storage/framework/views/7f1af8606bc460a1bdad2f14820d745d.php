<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['post', 'lead' => false, 'headingTag' => 'h3', 'center' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['post', 'lead' => false, 'headingTag' => 'h3', 'center' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    use App\Domain\Blog\PostPresenter;
    use App\Support\Money;

    $locale = app()->getLocale();
    $title = $post->getTranslation('title', $locale);
    $excerpt = $post->getTranslation('excerpt', $locale);
    $minutes = app(PostPresenter::class)->minutes($post);
?>
<div <?php echo e($attributes->class('h-full')); ?>>
<article class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'group relative flex h-full overflow-hidden rounded-[1.5rem] border border-line bg-white shadow-[var(--shadow-soft)] transition-[translate,box-shadow] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1.5 hover:shadow-[var(--shadow-lift)]',
    'flex-col lg:grid lg:grid-cols-[1.15fr_1fr]' => $lead,
    'flex-col' => ! $lead,
]); ?>">
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['relative overflow-hidden bg-brand', 'aspect-[16/10] lg:aspect-auto lg:min-h-[420px]' => $lead, 'aspect-[16/10]' => ! $lead]); ?>">
        <?php if($post->banner): ?>
            <img
                src="<?php echo e($post->banner->url($lead ? 'md' : 'sm')); ?>"
                srcset="<?php echo e($post->banner->srcset()); ?>"
                sizes="<?php echo e($lead ? '(min-width: 1024px) 640px, 100vw' : '(min-width: 1024px) 380px, (min-width: 640px) 50vw, 100vw'); ?>"
                alt=""
                <?php if(! $lead): ?> loading="lazy" <?php endif; ?>
                decoding="async"
                class="absolute inset-0 size-full object-cover transition-[scale] duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.05]"
            >
        <?php else: ?>
            <div class="pattern-star absolute inset-0 opacity-[0.08]" aria-hidden="true"></div>
            <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'book','class' => 'absolute top-1/2 left-1/2 size-14 -translate-x-1/2 -translate-y-1/2 text-gold/70']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book','class' => 'absolute top-1/2 left-1/2 size-14 -translate-x-1/2 -translate-y-1/2 text-gold/70']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($post->category): ?>
            <span class="absolute top-4 left-4 rounded-full bg-white/95 px-3 py-1 text-[12px] font-semibold text-brand"><?php echo e($post->category->getTranslation('name', $locale)); ?></span>
        <?php endif; ?>
    </div>

    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex flex-1 flex-col', 'p-7 sm:p-9 lg:p-11 lg:justify-center' => $lead, 'p-6' => ! $lead, 'items-center text-center' => $center]); ?>">
        <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] font-medium text-ink-3', 'justify-center' => $center]); ?>">
            <time datetime="<?php echo e($post->published_at?->toDateString()); ?>"><?php echo e(PostPresenter::date($post->published_at)); ?></time>
            <span class="size-1 rounded-full bg-gold" aria-hidden="true"></span>
            <span><?php echo e(trans_choice(':count min read|:count min read', $minutes, ['count' => Money::digits($minutes)])); ?></span>
        </p>
        <<?php echo e($headingTag); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-3 font-display text-brand', 'text-display-md' => $lead, 'text-display-sm' => ! $lead]); ?>">
            <a href="<?php echo e($post->url()); ?>" class="after:absolute after:inset-0 focus-visible:outline-none"><?php echo e($title); ?></a>
        </<?php echo e($headingTag); ?>>
        <?php if($excerpt): ?>
            <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-3 leading-relaxed text-ink-2', 'text-[1.0625rem] line-clamp-4' => $lead, 'text-[15px] line-clamp-3' => ! $lead]); ?>"><?php echo e($excerpt); ?></p>
        <?php endif; ?>
        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['inline-flex items-center gap-1.5 text-[14px] font-semibold text-brand', 'mt-7' => $lead, 'mt-auto pt-5' => ! $lead]); ?>">
            <?php echo e(__('Read article')); ?>

            <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'size-4 transition-transform group-hover:translate-x-1 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'size-4 transition-transform group-hover:translate-x-1 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
        </span>
    </div>
</article>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/post-card.blade.php ENDPATH**/ ?>
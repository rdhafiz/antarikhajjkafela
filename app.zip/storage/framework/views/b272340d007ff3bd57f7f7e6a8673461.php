<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $filled = isset(App\Support\Icons::FILLED[$name]);
    $paths = $filled ? App\Support\Icons::FILLED[$name] : (App\Support\Icons::STROKE[$name] ?? '');
?>
<?php if($filled): ?>
    <svg <?php echo e($attributes->merge(['class' => 'size-5', 'aria-hidden' => 'true'])); ?> viewBox="0 0 24 24" fill="currentColor"><?php echo $paths; ?></svg>
<?php else: ?>
    <svg <?php echo e($attributes->merge(['class' => 'size-5', 'aria-hidden' => 'true'])); ?> viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><?php echo $paths; ?></svg>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/icon.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['languages', 'tone' => 'light']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['languages', 'tone' => 'light']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div
    role="group"
    aria-label="<?php echo e(__('Language')); ?>"
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'inline-flex shrink-0 items-center rounded-full p-0.5 ring-1 transition-colors',
        'bg-white/8 ring-white/15' => $tone === 'dark',
        'bg-sand-100 ring-line' => in_array($tone, ['light', 'header'], true),
        'group-data-[transparent=true]/header:bg-white/10 group-data-[transparent=true]/header:ring-white/20' => $tone === 'header',
    ]); ?>"
>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a
            href="<?php echo e($language['url']); ?>"
            rel="nofollow"
            hreflang="<?php echo e($language['code']); ?>"
            lang="<?php echo e($language['code']); ?>"
            <?php if($language['active']): ?> aria-current="true" <?php endif; ?>
            title="<?php echo e($language['name']); ?>"
            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'rounded-full px-3 py-1 text-[13px] leading-5 font-semibold transition-colors',
                'bg-gold text-brand-950' => $language['active'],
                'text-white/75 hover:text-white' => ! $language['active'] && $tone === 'dark',
                'text-ink-2 hover:text-brand' => ! $language['active'] && in_array($tone, ['light', 'header'], true),
                'group-data-[transparent=true]/header:text-white/80 group-data-[transparent=true]/header:hover:text-white' => ! $language['active'] && $tone === 'header',
            ]); ?>"
            
            style="font-family: system-ui, sans-serif"
        ><?php echo e($language['code'] === 'en' ? 'EN' : $language['native']); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/language-switcher.blade.php ENDPATH**/ ?>
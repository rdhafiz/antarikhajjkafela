<?php
    $dark = $style['tone'] === 'dark';
    $imageLeft = ($c['image_position'] ?? 'right') === 'left';
    $bullets = array_filter($c['bullets'] ?? [], fn ($b) => filled($b['text']));
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['lg:order-2' => $imageLeft]); ?>" data-reveal>
            <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'align' => 'left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
            <?php if(filled($c['body'])): ?>
                <div class="prose-site mt-6"><?php echo $c['body']; ?></div>
            <?php endif; ?>
            <?php if($bullets): ?>
                <ul class="mt-7 grid gap-3 sm:grid-cols-2">
                    <?php $__currentLoopData = $bullets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bullet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex gap-3">
                            <span class="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-emerald text-white"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                            <span class="sec-text"><?php echo e($bullet['text']); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <div class="mt-9 flex flex-col gap-3 empty:hidden sm:flex-row">
                <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['primary'],'variant' => $dark ? 'gold' : 'primary','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['primary']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dark ? 'gold' : 'primary'),'icon-right' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['secondary'],'variant' => $dark ? 'outline-light' : 'outline']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['secondary']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dark ? 'outline-light' : 'outline')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
            </div>
        </div>

        <?php if($c['image']): ?>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['relative', 'lg:order-1' => $imageLeft]); ?>" data-reveal style="--reveal-delay: 100ms">
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['absolute -bottom-4 size-40 rounded-[2rem] bg-gold/25 -z-10', '-left-4' => ! $imageLeft, '-right-4' => $imageLeft]); ?>" aria-hidden="true"></div>
                <img
                    src="<?php echo e($c['image']->url('md')); ?>"
                    srcset="<?php echo e($c['image']->srcset()); ?>"
                    sizes="(min-width: 1024px) 45vw, 100vw"
                    alt="<?php echo e($c['image']->getTranslation('alt', app()->getLocale())); ?>"
                    loading="lazy"
                    decoding="async"
                    class="aspect-[4/3] w-full rounded-[1.75rem] object-cover shadow-[var(--shadow-lift)]"
                >
                <?php if(filled($c['badge'])): ?>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['absolute top-5 rounded-full bg-brand px-4 py-2 text-[13px] font-semibold text-white shadow-lg', 'right-5' => ! $imageLeft, 'left-5' => $imageLeft]); ?>"><?php echo e($c['badge']); ?></span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/image-text.blade.php ENDPATH**/ ?>
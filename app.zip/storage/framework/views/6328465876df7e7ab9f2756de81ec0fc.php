<?php
    use App\Support\Money;

    $recaptcha = settings('tracking.recaptcha_site_key') && settings('tracking.recaptcha_secret_key') ? settings('tracking.recaptcha_site_key') : null;
    $advance = ['type' => $package->advance_type ?: 'none', 'value' => (float) $package->advance_value];
    $canPayOnline = $gateway && $advance['type'] !== 'none';
    $config = [
        'options' => $options,
        'option' => (int) old('option', $selected['id']),
        'travelers' => (int) old('travelers', 1),
        'rooms' => (int) old('rooms', 1),
        'payment' => old('payment', $canPayOnline ? 'now' : 'later'),
        'advance' => $advance,
        'recaptcha' => $recaptcha,
        'locale' => app()->getLocale(),
    ];
    $invalid = fn (string $name) => $errors->has($name) ? 'aria-invalid="true" aria-describedby="'.e($name).'-error"' : '';
?>
<?php $site = app(App\Support\SiteContext::class); ?>
<?php
    $phones = $site->phones();
    $steps = [
        ['id' => 'step-option', 'label' => __('Option')],
        ['id' => 'step-details', 'label' => __('Your details')],
        ['id' => 'step-documents', 'label' => __('Documents')],
        ['id' => 'step-payment', 'label' => __('Payment')],
    ];
    $pad = fn (int $n) => Money::digits(str_pad((string) $n, 2, '0', STR_PAD_LEFT));
?>
<?php if (isset($component)) { $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="section-light bg-sand-50 pt-10 sm:pt-12">
        <div class="container-site">
            <div class="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between" data-reveal>
                <div class="flex items-center gap-5">
                    <?php if($package->banner): ?>
                        <img src="<?php echo e($package->banner->url('sm')); ?>" alt="" width="96" height="96" class="hidden size-20 shrink-0 rounded-2xl object-cover shadow-[var(--shadow-soft)] sm:block">
                    <?php endif; ?>
                    <div>
                        <p class="eyebrow"><?php echo e(__('Book your journey')); ?></p>
                        <h1 class="mt-2 font-display text-display-md text-brand"><?php echo e($name); ?></h1>
                    </div>
                </div>
                <a href="<?php echo e($package->url()); ?>" class="inline-flex items-center gap-1.5 text-[14px] font-semibold text-brand hover:text-gold-deep">
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-left','class' => 'size-4 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-left','class' => 'size-4 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    <?php echo e(__('Back to the package')); ?>

                </a>
            </div>
        </div>
    </div>

    
    <div x-data="sectionNav" class="sticky top-20 z-20 mt-8 border-y border-line bg-white/95 backdrop-blur-md">
        <div class="container-site">
            <nav class="no-scrollbar -mx-1 flex gap-1 overflow-x-auto py-2.5" aria-label="<?php echo e(__('Booking steps')); ?>" x-ref="links">
                <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#<?php echo e($step['id']); ?>" data-target="<?php echo e($step['id']); ?>"
                       class="book-step section-nav-link flex shrink-0 items-center gap-2.5 rounded-full py-1.5 ps-1.5 pe-4 text-[14px] font-semibold whitespace-nowrap"
                       :class="active === '<?php echo e($step['id']); ?>' && 'is-active'"
                       :aria-current="active === '<?php echo e($step['id']); ?>' ? 'step' : null">
                        <span class="book-step-num flex size-7 items-center justify-center rounded-full text-[12.5px] font-bold tabular-nums"><?php echo e(Money::digits($i + 1)); ?></span>
                        <?php echo e($step['label']); ?>

                    </a>
                    <?php if(! $loop->last): ?><span class="my-auto hidden h-px w-6 shrink-0 bg-line sm:block" aria-hidden="true"></span><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
        </div>
    </div>

    <section class="section-light relative isolate bg-sand-50 pt-8 pb-14 sm:pt-10 sm:pb-20">
        <div class="pattern-star-ink pointer-events-none absolute inset-0 -z-10 opacity-[0.02]" aria-hidden="true"></div>
        <div class="container-site">
            <form method="POST" action="<?php echo e(route('bookings.store', $package->slug)); ?>" enctype="multipart/form-data" novalidate
                  x-data="bookingForm(<?php echo \Illuminate\Support\Js::from($config)->toHtml() ?>)" @submit="submit($event)" @focusin.once="loadRecaptcha()"
                  class="grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_380px]">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="recaptcha_token" x-ref="token">
                <div class="absolute -left-[9999px]" aria-hidden="true">
                    <label for="website">Website</label>
                    <input id="website" type="text" name="website" tabindex="-1" autocomplete="off">
                </div>

                <div class="space-y-6">
                    <?php if($errors->any()): ?>
                        <div class="rounded-2xl bg-red-50 px-5 py-4 text-[14px] text-red-800 ring-1 ring-red-200" role="alert" tabindex="-1" x-init="$el.focus()">
                            <p class="font-semibold"><?php echo e(__('Please check the highlighted fields.')); ?></p>
                            <?php $__currentLoopData = ['recaptcha', 'passport', 'nid']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__errorArgs = [$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <fieldset id="step-option" class="book-card scroll-mt-40">
                        <legend class="sr-only"><?php echo e(__('Choose your package option')); ?></legend>
                        <div class="book-card-head" data-reveal aria-hidden="true">
                            <span class="book-card-num"><?php echo e($pad(1)); ?></span>
                            <div>
                                <p class="font-display text-display-sm text-brand"><?php echo e(__('Choose your package option')); ?></p>
                                <p class="mt-1 text-[14.5px] text-ink-2"><?php echo e(__('Pick a room option and how many people are travelling.')); ?></p>
                            </div>
                        </div>
                        <div class="book-card-body">
                            <div class="grid gap-3 sm:grid-cols-2">
                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="book-choice relative flex cursor-pointer flex-col p-5" :class="option === <?php echo e($option['id']); ?> && 'is-selected'" data-reveal style="--reveal-delay: <?php echo e(($i % 4) * 80); ?>ms">
                                        <input type="radio" name="option" value="<?php echo e($option['id']); ?>" x-model.number="option" class="sr-only">
                                        <span class="text-[12px] font-semibold tracking-[0.12em] text-gold-deep uppercase"><?php echo e($option['type']); ?></span>
                                        <span class="mt-1.5 pe-8 font-semibold text-ink"><?php echo e($option['title']); ?></span>
                                        <span class="mt-3 font-display text-[1.375rem] leading-none font-semibold text-brand"><?php echo e(Money::html($option['price'])); ?> <span class="font-sans text-[13px] font-normal text-ink-3"><?php echo e($option['unit_label']); ?></span></span>
                                        <span class="book-choice-check absolute top-4 end-4 flex size-6 items-center justify-center rounded-full" aria-hidden="true"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php $__errorArgs = ['option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="error-site"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="mt-6 grid gap-5 sm:grid-cols-2" data-reveal style="--reveal-delay: 120ms">
                                <div>
                                    <label for="travelers" class="label-site"><?php echo e(__('Number of travelers')); ?><span class="text-red-600">*</span></label>
                                    <div class="book-stepper flex items-stretch">
                                        <button type="button" @click="travelers = Math.max(1, travelers - 1)" aria-label="<?php echo e(__('Fewer travelers')); ?>">−</button>
                                        <input id="travelers" name="travelers" type="number" min="1" max="50" inputmode="numeric" x-model.number="travelers" class="input-site rounded-none border-x-0 text-center font-semibold" <?php echo $invalid('travelers'); ?>>
                                        <button type="button" @click="travelers = Math.min(50, travelers + 1)" aria-label="<?php echo e(__('More travelers')); ?>">+</button>
                                    </div>
                                    <?php $__errorArgs = ['travelers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p id="travelers-error" class="error-site"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div x-show="selected.unit === 'room'" x-cloak>
                                    <label for="rooms" class="label-site"><?php echo e(__('Number of rooms')); ?></label>
                                    <input id="rooms" name="rooms" type="number" min="1" max="50" inputmode="numeric" x-model.number="rooms" class="input-site" :disabled="selected.unit !== 'room'">
                                    <?php $__errorArgs = ['rooms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="error-site"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </fieldset>

                    
                    <fieldset id="step-details" class="book-card scroll-mt-40">
                        <legend class="sr-only"><?php echo e(__('Your details')); ?></legend>
                        <div class="book-card-head" data-reveal aria-hidden="true">
                            <span class="book-card-num"><?php echo e($pad(2)); ?></span>
                            <div>
                                <p class="font-display text-display-sm text-brand"><?php echo e(__('Your details')); ?></p>
                                <p class="mt-1 text-[14.5px] text-ink-2"><?php echo e(__('We call this number to confirm your booking.')); ?></p>
                            </div>
                        </div>
                        <div class="book-card-body grid gap-5 sm:grid-cols-2">
                            <?php $__currentLoopData = [
                                ['name', __('Full name'), 'text', true, 'name'],
                                ['phone', __('Mobile number'), 'tel', true, 'tel'],
                                ['email', __('Email'), 'email', false, 'email'],
                                ['address', __('Address'), 'text', false, 'street-address'],
                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$key, $label, $type, $required, $autocomplete]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div data-reveal style="--reveal-delay: <?php echo e(($i % 2) * 80); ?>ms">
                                    <label for="<?php echo e($key); ?>" class="label-site"><?php echo e($label); ?><?php if($required): ?><span class="text-red-600">*</span><?php endif; ?>
                                        <?php if($key === 'email'): ?><span class="font-normal text-ink-3" x-text="payment === 'now' ? <?php echo \Illuminate\Support\Js::from(' ('.__('needed for online payment').')')->toHtml() ?> : ''"></span><?php endif; ?>
                                    </label>
                                    <input id="<?php echo e($key); ?>" name="<?php echo e($key); ?>" type="<?php echo e($type); ?>" value="<?php echo e(old($key)); ?>" autocomplete="<?php echo e($autocomplete); ?>" <?php if($required): echo 'required'; endif; ?> <?php if($type === 'tel'): ?> inputmode="tel" <?php endif; ?> class="input-site" <?php echo $invalid($key); ?>>
                                    <?php $__errorArgs = [$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p id="<?php echo e($key); ?>-error" class="error-site"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="sm:col-span-2" data-reveal>
                                <label for="note" class="label-site"><?php echo e(__('Message')); ?> <span class="font-normal text-ink-3">(<?php echo e(__('optional')); ?>)</span></label>
                                <textarea id="note" name="note" rows="3" class="input-site" placeholder="<?php echo e(__('Names of the travelers, special needs, questions…')); ?>"><?php echo e(old('note')); ?></textarea>
                                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="error-site"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </fieldset>

                    
                    <fieldset id="step-documents" class="book-card scroll-mt-40">
                        <legend class="sr-only"><?php echo e(__('Documents')); ?></legend>
                        <div class="book-card-head" data-reveal aria-hidden="true">
                            <span class="book-card-num"><?php echo e($pad(3)); ?></span>
                            <div>
                                <p class="font-display text-display-sm text-brand"><?php echo e(__('Documents')); ?> <span class="font-sans text-[14px] font-normal text-ink-3">(<?php echo e(__('optional')); ?>)</span></p>
                                <p class="mt-1 text-[14.5px] text-ink-2"><?php echo e(__('You can upload passport and NID copies now or give them to us later. JPG, PNG or PDF, up to 5 MB each. Only our staff can see them.')); ?></p>
                            </div>
                        </div>
                        <div class="book-card-body grid gap-4 sm:grid-cols-2">
                            <?php $__currentLoopData = ['passport' => [__('Passport copies'), 'passport'], 'nid' => [__('NID copies'), 'document']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => [$label, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div x-data="{ files: [] }" data-reveal style="--reveal-delay: <?php echo e($loop->index * 80); ?>ms">
                                    <label for="<?php echo e($key); ?>" class="book-drop group flex cursor-pointer flex-col items-center px-5 py-7 text-center">
                                        <span class="flex size-12 items-center justify-center rounded-2xl bg-brand text-gold transition-[scale] duration-500 group-hover:scale-105"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => $icon,'class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                        <span class="mt-3 font-semibold text-brand"><?php echo e($label); ?></span>
                                        <span class="mt-1 text-[13px] text-ink-3" x-text="files.length ? files.join(', ') : <?php echo \Illuminate\Support\Js::from(__('Choose files'))->toHtml() ?>"><?php echo e(__('Choose files')); ?></span>
                                    </label>
                                    <input id="<?php echo e($key); ?>" name="<?php echo e($key); ?>[]" type="file" multiple accept=".jpg,.jpeg,.png,.webp,.pdf" class="sr-only"
                                           @change="files = [...$event.target.files].map((f) => f.name)">
                                    <?php $__errorArgs = [$key.'.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="error-site"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </fieldset>

                    
                    <fieldset id="step-payment" class="book-card scroll-mt-40">
                        <legend class="sr-only"><?php echo e(__('Payment')); ?></legend>
                        <div class="book-card-head" data-reveal aria-hidden="true">
                            <span class="book-card-num"><?php echo e($pad(4)); ?></span>
                            <div>
                                <p class="font-display text-display-sm text-brand"><?php echo e(__('Payment')); ?></p>
                                <p class="mt-1 text-[14.5px] text-ink-2"><?php echo e(__('Choose how you would like to pay.')); ?></p>
                            </div>
                        </div>
                        <div class="book-card-body">
                            <div class="grid gap-3 sm:grid-cols-2">
                                <?php if($canPayOnline): ?>
                                    <label class="book-choice relative flex cursor-pointer gap-4 p-5" :class="payment === 'now' && 'is-selected'" data-reveal>
                                        <input type="radio" name="payment" value="now" x-model="payment" class="sr-only">
                                        <span class="flex size-11 shrink-0 items-center justify-center rounded-xl bg-sand-100 text-gold-deep"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'wallet','class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wallet','class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                        <span class="min-w-0 pe-6">
                                            <span class="block font-semibold text-ink"><?php echo e(__('Pay the advance now')); ?></span>
                                            <span class="mt-1 block text-[14px] text-ink-2"><?php echo e(__('Secure online payment by card or mobile banking through :gateway.', ['gateway' => $gateway->label()])); ?></span>
                                            <span class="mt-2 block font-display text-lg font-semibold text-brand" x-text="money(advanceAmount)"></span>
                                        </span>
                                        <span class="book-choice-check absolute top-4 end-4 flex size-6 items-center justify-center rounded-full" aria-hidden="true"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                    </label>
                                <?php endif; ?>
                                <label class="book-choice relative flex cursor-pointer gap-4 p-5" :class="payment === 'later' && 'is-selected'" data-reveal style="--reveal-delay: 80ms">
                                    <input type="radio" name="payment" value="later" x-model="payment" class="sr-only">
                                    <span class="flex size-11 shrink-0 items-center justify-center rounded-xl bg-sand-100 text-gold-deep"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'headset','class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'headset','class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                    <span class="min-w-0 pe-6">
                                        <span class="block font-semibold text-ink"><?php echo e(__('Book now, pay later')); ?></span>
                                        <span class="mt-1 block text-[14px] text-ink-2"><?php echo e(__('We reserve your place and call you to arrange the payment.')); ?></span>
                                    </span>
                                    <span class="book-choice-check absolute top-4 end-4 flex size-6 items-center justify-center rounded-full" aria-hidden="true"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                </label>
                            </div>

                            <label class="mt-6 flex items-start gap-3 rounded-2xl bg-sand-50 p-4 text-[14px] text-ink-2 ring-1 ring-line" data-reveal>
                                <input type="checkbox" name="agree" value="1" <?php if(old('agree')): echo 'checked'; endif; ?> class="mt-0.5 size-5 shrink-0 rounded accent-[var(--color-brand)]" <?php echo $invalid('agree'); ?>>
                                <span><?php echo e(__('I agree to the')); ?> <a href="<?php echo e(url('terms-and-conditions')); ?>" target="_blank" class="font-semibold text-brand underline"><?php echo e(__('booking terms and conditions')); ?></a><?php echo e(__(', including that prices may change with Saudi government or airline fees.')); ?></span>
                            </label>
                            <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p id="agree-error" class="error-site"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </fieldset>
                </div>

                
                <div class="space-y-4 lg:sticky lg:top-40" data-reveal style="--reveal-delay: 120ms">
                    <div class="overflow-hidden rounded-[1.75rem] bg-brand-950 text-white shadow-[var(--shadow-lift)]">
                        <div class="relative isolate overflow-hidden p-6">
                            <?php if($package->banner): ?>
                                <img src="<?php echo e($package->banner->url('sm')); ?>" alt="" class="absolute inset-0 -z-20 size-full object-cover opacity-40">
                                <div class="absolute inset-0 -z-10 bg-gradient-to-t from-brand-950 via-brand-950/70 to-brand-950/30" aria-hidden="true"></div>
                            <?php else: ?>
                                <div class="pattern-star absolute inset-0 -z-10 opacity-[0.05]" aria-hidden="true"></div>
                            <?php endif; ?>
                            <p class="text-[12px] font-semibold tracking-wider text-gold uppercase"><?php echo e(__('Your booking')); ?></p>
                            <p class="mt-2 font-display text-[1.35rem] leading-snug"><?php echo e($name); ?></p>
                            <p class="mt-1 text-[14px] text-white/75" x-text="selected.type + ' · ' + selected.title"></p>
                        </div>
                        <dl class="space-y-3 border-t border-white/10 p-6 text-[15px]">
                            <div class="flex justify-between gap-4"><dt class="text-white/65"><?php echo e(__('Price')); ?></dt><dd class="text-end" x-text="money(selected.price) + ' ' + selected.unit_label"></dd></div>
                            <div class="flex justify-between gap-4"><dt class="text-white/65" x-text="selected.unit === 'room' ? <?php echo \Illuminate\Support\Js::from(__('Rooms'))->toHtml() ?> : <?php echo \Illuminate\Support\Js::from(__('Travelers'))->toHtml() ?>"></dt><dd x-text="digits(selected.unit === 'room' ? rooms : (selected.unit === 'group' ? 1 : travelers))"></dd></div>
                            <div class="flex items-baseline justify-between gap-4 border-t border-white/10 pt-4"><dt class="font-semibold"><?php echo e(__('Total')); ?></dt><dd class="text-[1.625rem] leading-none font-bold text-gold tabular-nums" x-text="money(total)"></dd></div>
                            <div x-show="advanceAmount > 0" class="flex justify-between gap-4 text-[14px]"><dt class="text-white/65"><?php echo e(__('Advance to confirm')); ?></dt><dd x-text="money(advanceAmount)"></dd></div>
                        </dl>
                        <div class="p-6 pt-0">
                            <button type="submit" class="btn btn-gold btn-lg w-full" :disabled="busy">
                                <svg x-show="busy" x-cloak class="size-5 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-opacity=".25" stroke-width="3"/><path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>
                                <span x-text="payment === 'now' ? <?php echo \Illuminate\Support\Js::from(__('Book and pay advance'))->toHtml() ?> : <?php echo \Illuminate\Support\Js::from(__('Confirm booking'))->toHtml() ?>"><?php echo e(__('Confirm booking')); ?></span>
                            </button>
                            <p class="mt-3 text-center text-[12px] text-white/60"><?php echo e(__('Final amounts are confirmed by our team.')); ?><?php if($recaptcha): ?> <?php echo e(__('Protected by reCAPTCHA.')); ?><?php endif; ?></p>
                        </div>
                    </div>

                    
                    <div class="rounded-[1.75rem] border border-line bg-white p-6">
                        <ul class="space-y-3 text-[14px] text-ink-2">
                            <li class="flex gap-3"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'headset','class' => 'mt-0.5 size-4.5 shrink-0 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'headset','class' => 'mt-0.5 size-4.5 shrink-0 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(__('Our team will call you shortly to confirm.')); ?></li>
                            <li class="flex gap-3"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'shield','class' => 'mt-0.5 size-4.5 shrink-0 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shield','class' => 'mt-0.5 size-4.5 shrink-0 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(__('Your documents are seen only by our staff.')); ?></li>
                            <li class="flex gap-3"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'wallet','class' => 'mt-0.5 size-4.5 shrink-0 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wallet','class' => 'mt-0.5 size-4.5 shrink-0 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(__('Please pay only through our official channels.')); ?></li>
                        </ul>
                        <?php if($phones): ?>
                            <a href="<?php echo e($phones[0]['href']); ?>" class="mt-5 flex items-center justify-between gap-3 rounded-2xl bg-sand-50 px-4 py-3 ring-1 ring-line transition-colors hover:bg-sand-100">
                                <span>
                                    <span class="block text-[12px] font-semibold tracking-wider text-ink-3 uppercase"><?php echo e(__('Need help?')); ?></span>
                                    <span class="font-semibold text-brand" dir="ltr"><?php echo e($phones[0]['display']); ?></span>
                                </span>
                                <span class="flex size-10 items-center justify-center rounded-full bg-brand text-white"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'phone','class' => 'size-4.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','class' => 'size-4.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $attributes = $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $component = $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/bookings/create.blade.php ENDPATH**/ ?>
<?php $site = app(App\Support\SiteContext::class); ?>
<?php
    $variant = $c['variant'] ?? 'banner';
    $phones = $site->phones();
    $whatsapp = $site->whatsappUrl();
    $dark = $style['tone'] === 'dark';
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <?php if($variant === 'minimal'): ?>
        <div class="flex flex-col items-center gap-8 text-center lg:flex-row lg:justify-between lg:text-left" data-reveal>
            <div class="max-w-2xl">
                <?php if(filled($c['eyebrow'])): ?><p class="eyebrow"><?php echo e($c['eyebrow']); ?></p><?php endif; ?>
                <h2 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sec-heading text-display-md', 'mt-3' => filled($c['eyebrow'])]); ?>"><?php echo e($c['title']); ?></h2>
                <?php if(filled($c['text'])): ?><p class="sec-text mt-3"><?php echo e($c['text']); ?></p><?php endif; ?>
            </div>
            <?php echo $__env->make('sections.partials.cta-buttons', ['onDark' => $dark], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php else: ?>
        
        <div class="relative isolate overflow-hidden rounded-[2rem] bg-brand text-white shadow-[var(--shadow-lift)]" data-reveal="scale">
            <?php if($variant === 'banner' && $c['image']): ?>
                <div class="absolute inset-x-0 -inset-y-[25%] -z-20" data-parallax="0.18" aria-hidden="true">
                    <img src="<?php echo e($c['image']->url('lg')); ?>" srcset="<?php echo e($c['image']->srcset()); ?>" sizes="(min-width: 1280px) 1200px, 100vw" alt="" loading="lazy" decoding="async" class="size-full object-cover">
                </div>
                <div class="absolute inset-0 -z-10 bg-gradient-to-r from-brand-950/95 via-brand/85 to-brand/40" aria-hidden="true"></div>
            <?php endif; ?>
            <div class="pattern-star absolute inset-0 -z-10 opacity-[0.06]" aria-hidden="true"></div>
            <div class="absolute -right-24 -bottom-32 -z-10 size-[420px] rounded-full bg-gold/15 blur-3xl" aria-hidden="true"></div>

            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid items-center', 'lg:grid-cols-[1.1fr_0.9fr]' => $variant === 'split' && $c['image']]); ?>">
                <div class="px-7 py-12 sm:px-12 sm:py-14 lg:px-16">
                    <?php if(filled($c['eyebrow'])): ?><p class="eyebrow eyebrow-light"><?php echo e($c['eyebrow']); ?></p><?php endif; ?>
                    <h2 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-display-lg text-white', 'mt-4' => filled($c['eyebrow'])]); ?>"><?php echo e($c['title']); ?></h2>
                    <?php if(filled($c['text'])): ?><p class="mt-5 max-w-xl text-[1.0625rem] leading-relaxed text-white/75"><?php echo e($c['text']); ?></p><?php endif; ?>
                    <div class="mt-9"><?php echo $__env->make('sections.partials.cta-buttons', ['onDark' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                </div>
                <?php if($variant === 'split' && $c['image']): ?>
                    <div class="relative h-72 lg:h-full lg:min-h-[420px]">
                        <img src="<?php echo e($c['image']->url('md')); ?>" srcset="<?php echo e($c['image']->srcset()); ?>" sizes="(min-width: 1024px) 40vw, 100vw" alt="" loading="lazy" decoding="async" class="absolute inset-0 size-full object-cover">
                        <div class="absolute inset-0 bg-gradient-to-r from-brand via-brand/30 to-transparent max-lg:bg-gradient-to-t" aria-hidden="true"></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/cta.blade.php ENDPATH**/ ?>
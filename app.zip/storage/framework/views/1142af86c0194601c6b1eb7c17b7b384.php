<?php
    $variant = $c['variant'] ?? 'split';
    $dark = $style['tone'] === 'dark';
    $slides = array_values(array_filter($c['slides'] ?? [], fn ($s) => $s['image']));
    $highlights = array_values(array_filter($c['highlights'] ?? [], fn ($h) => filled($h['value'])));
    // At the top of a page the hero fills the screen (home) or three quarters of it (like other pages), with parallax.
    $height = $first ? ($page->isHome() ? 'hero-full' : 'hero-75') : null;
?>

<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section,'container' => false,'dataHero' => $first ? true : null,'class' => \Illuminate\Support\Arr::toCssClasses([$first ? 'pt-20' : '', $height, 'flex flex-col' => $height, 'bg-gradient-to-br from-brand via-brand-900 to-brand-950' => ! $style['image'] && str_contains($style['class'], 'bg-brand-950')])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section),'container' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'data-hero' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($first ? true : null),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses([$first ? 'pt-20' : '', $height, 'flex flex-col' => $height, 'bg-gradient-to-br from-brand via-brand-900 to-brand-950' => ! $style['image'] && str_contains($style['class'], 'bg-brand-950')]))]); ?>
    <?php if (! ($style['image'] || ($variant === 'centered' && $c['image']) || $variant === 'slider')): ?>
        <div class="pattern-star absolute inset-0 -z-10 opacity-[0.06]" aria-hidden="true"></div>
        <div class="absolute top-1/4 -right-48 -z-10 size-[620px] rounded-full bg-gold/12 blur-3xl" aria-hidden="true"></div>
        <div class="absolute -bottom-56 -left-40 -z-10 size-[520px] rounded-full bg-emerald/20 blur-3xl" aria-hidden="true"></div>
    <?php endif; ?>

    <?php if($variant === 'slider' && $slides): ?>
        <div
            x-data="{ i: 0, n: <?php echo e(count($slides)); ?>, timer: null,
                go(k) { this.i = (k + this.n) % this.n },
                start() { if (this.n > 1 && !matchMedia('(prefers-reduced-motion: reduce)').matches) this.timer = setInterval(() => this.go(this.i + 1), 6500) },
                stop() { clearInterval(this.timer) } }"
            x-init="start()"
            @mouseenter="stop()" @mouseleave="start()" @focusin="stop()"
            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['relative min-h-[560px] sm:min-h-[620px]', 'flex-1' => $height, 'lg:min-h-[680px]' => ! $height]); ?>"
            role="region" aria-roledescription="carousel" aria-label="<?php echo e(__('Highlights')); ?>"
        >
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="absolute inset-0 flex items-center transition-opacity duration-1000"
                    :class="i === <?php echo e($index); ?> ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'"
                    <?php if($index > 0): ?> style="opacity:0" <?php endif; ?>
                    role="group" aria-roledescription="slide" aria-label="<?php echo e($index + 1); ?> / <?php echo e(count($slides)); ?>"
                    :aria-hidden="(i !== <?php echo e($index); ?>).toString()"
                >
                    <img
                        src="<?php echo e($slide['image']->url('lg')); ?>"
                        srcset="<?php echo e($slide['image']->srcset()); ?>"
                        sizes="100vw"
                        alt="<?php echo e($slide['image']->getTranslation('alt', app()->getLocale())); ?>"
                        class="absolute inset-0 -z-20 size-full object-cover"
                        <?php if($index === 0): ?> fetchpriority="high" <?php else: ?> loading="lazy" <?php endif; ?>
                    >
                    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-brand-950/90 via-brand-950/65 to-brand-950/20" aria-hidden="true"></div>
                    <div class="container-site py-24 text-white">
                        <div class="max-w-2xl">
                            <?php if(filled($slide['eyebrow'])): ?><p class="eyebrow eyebrow-light"><?php echo e($slide['eyebrow']); ?></p><?php endif; ?>
                            <<?php echo e($index === 0 ? 'h1' : 'h2'); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-display-xl text-white', 'mt-5' => filled($slide['eyebrow'])]); ?>"><?php echo e($slide['title']); ?></<?php echo e($index === 0 ? 'h1' : 'h2'); ?>>
                            <?php if(filled($slide['text'])): ?><p class="mt-6 max-w-xl text-lg leading-relaxed text-white/80"><?php echo e($slide['text']); ?></p><?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $slide['link'],'variant' => 'gold','size' => 'lg','iconRight' => 'arrow-right','class' => 'mt-9']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide['link']),'variant' => 'gold','size' => 'lg','icon-right' => 'arrow-right','class' => 'mt-9']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($slides) > 1): ?>
                <div class="absolute inset-x-0 bottom-8 z-20">
                    <div class="container-site flex items-center gap-4">
                        <div class="flex gap-2">
                            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" @click="go(<?php echo e($index); ?>)" class="h-1.5 rounded-full transition-all duration-300"
                                        :class="i === <?php echo e($index); ?> ? 'w-10 bg-gold' : 'w-5 bg-white/40 hover:bg-white/70'"
                                        aria-label="<?php echo e(__('Show slide :n', ['n' => $index + 1])); ?>"></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="ml-auto flex gap-2">
                            <button type="button" @click="go(i - 1)" class="flex size-11 items-center justify-center rounded-full border border-white/25 text-white hover:bg-white/10" aria-label="<?php echo e(__('Previous slide')); ?>"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></button>
                            <button type="button" @click="go(i + 1)" class="flex size-11 items-center justify-center rounded-full border border-white/25 text-white hover:bg-white/10" aria-label="<?php echo e(__('Next slide')); ?>"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    <?php elseif($variant === 'centered'): ?>
        <?php if($c['image']): ?>
            <div class="hero-media" data-parallax-bg aria-hidden="true">
                <img src="<?php echo e($c['image']->url('lg')); ?>" srcset="<?php echo e($c['image']->srcset()); ?>" sizes="100vw" alt="" fetchpriority="high">
            </div>
            <div class="absolute inset-0 -z-10 bg-gradient-to-b from-brand-950/80 via-brand-950/70 to-brand-950/90" aria-hidden="true"></div>
        <?php endif; ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['container-site flex flex-col items-center justify-center py-24 text-center', 'flex-1' => $height, 'min-h-[560px] sm:min-h-[620px]' => ! $height]); ?>">
            <div class="hero-reveal max-w-3xl" data-parallax-content>
                <?php if(filled($c['eyebrow'])): ?><p class="eyebrow eyebrow-light justify-center"><?php echo e($c['eyebrow']); ?></p><?php endif; ?>
                <h1 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-display-xl text-white', 'mt-5' => filled($c['eyebrow'])]); ?>">
                    <?php echo e($c['title']); ?>

                    <?php if(filled($c['highlight'])): ?><span class="hero-line text-gold italic"><?php echo e($c['highlight']); ?></span><?php endif; ?>
                </h1>
                <?php if(filled($c['text'])): ?><p class="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-white/80"><?php echo e($c['text']); ?></p><?php endif; ?>
                <div class="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
                    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['primary'],'variant' => 'gold','size' => 'lg','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['primary']),'variant' => 'gold','size' => 'lg','icon-right' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['secondary'],'variant' => 'outline-light','size' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['secondary']),'variant' => 'outline-light','size' => 'lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['container-site grid items-center gap-14 py-20 sm:py-24 lg:grid-cols-[1.1fr_0.9fr] lg:py-28', 'flex-1' => $height]); ?>">
            <div class="hero-reveal" data-parallax-content>
                <?php if(filled($c['eyebrow'])): ?><p class="eyebrow"><?php echo e($c['eyebrow']); ?></p><?php endif; ?>
                <h1 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sec-heading text-display-xl', 'mt-5' => filled($c['eyebrow'])]); ?>">
                    <?php echo e($c['title']); ?>

                    <?php if(filled($c['highlight'])): ?><span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['hero-line italic', 'text-gold' => $dark, 'text-gold-deep' => ! $dark]); ?>"><?php echo e($c['highlight']); ?></span><?php endif; ?>
                </h1>
                <?php if(filled($c['text'])): ?><p class="sec-text mt-6 max-w-xl text-lg leading-relaxed"><?php echo e($c['text']); ?></p><?php endif; ?>
                <div class="mt-9 flex flex-col gap-3 sm:flex-row">
                    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['primary'],'variant' => $dark ? 'gold' : 'primary','size' => 'lg','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['primary']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dark ? 'gold' : 'primary'),'size' => 'lg','icon-right' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['secondary'],'variant' => $dark ? 'outline-light' : 'outline','size' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['secondary']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dark ? 'outline-light' : 'outline'),'size' => 'lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                </div>
            </div>

            <div class="hero-reveal relative mx-auto w-full max-w-md lg:max-w-none" data-parallax-bg>
                <?php if($c['image']): ?>
                    
                    <div class="relative">
                        <div class="absolute -inset-3 rounded-t-[999px] rounded-b-[2rem] border border-gold/40" aria-hidden="true"></div>
                        <img
                            src="<?php echo e($c['image']->url('md')); ?>"
                            srcset="<?php echo e($c['image']->srcset()); ?>"
                            sizes="(min-width: 1024px) 40vw, 90vw"
                            alt="<?php echo e($c['image']->getTranslation('alt', app()->getLocale())); ?>"
                            width="<?php echo e($c['image']->variants['md']['width'] ?? 1024); ?>"
                            height="<?php echo e($c['image']->variants['md']['height'] ?? 1280); ?>"
                            fetchpriority="high"
                            class="aspect-[4/5] w-full rounded-t-[999px] rounded-b-[1.75rem] object-cover shadow-[var(--shadow-lift)]"
                        >
                    </div>
                <?php else: ?>
                    <div class="relative mx-auto hidden aspect-square w-full max-w-md lg:block">
                        <div class="absolute inset-0 rotate-45 rounded-[3rem] border border-gold/30"></div>
                        <div class="absolute inset-8 rounded-[2.5rem] border border-white/10 bg-white/[0.04] backdrop-blur-sm"></div>
                        <img src="<?php echo e(app(App\Support\Branding::class)->iconUrl(512)); ?>" alt="" width="512" height="512" loading="lazy" class="absolute inset-[22%] size-[56%] object-contain drop-shadow-2xl">
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if($highlights): ?>
        <div class="relative z-10 border-t border-white/10 bg-brand-950/85 backdrop-blur-md">
            <dl class="<?php echo \Illuminate\Support\Arr::toCssClasses(['container-site grid grid-cols-2 gap-y-6 py-8', ['sm:grid-cols-1', 'sm:grid-cols-2', 'sm:grid-cols-3', 'sm:grid-cols-4'][min(4, count($highlights)) - 1]]); ?>">
                <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-col-reverse items-center text-center sm:border-l sm:border-white/10 sm:first:border-l-0">
                        <dt class="mt-1 text-[13px] tracking-wide text-white/60"><?php echo e($item['label']); ?></dt>
                        <dd class="font-display text-3xl font-semibold text-gold" data-count><?php echo e(App\Support\Money::digits($item['value'])); ?></dd>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </dl>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/hero.blade.php ENDPATH**/ ?>
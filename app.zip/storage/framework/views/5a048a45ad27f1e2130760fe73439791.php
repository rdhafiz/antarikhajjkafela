<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Admin · <?php echo e($appName); ?></title>

    <style>
        :root {
            --admin-primary: <?php echo e($theme['primary_color']); ?>;
            --admin-secondary: <?php echo e($theme['secondary_color']); ?>;
            --admin-accent: <?php echo e($theme['accent_color']); ?>;
            --admin-sidebar-bg: <?php echo e($theme['sidebar_bg']); ?>;
            --admin-sidebar-text: <?php echo e($theme['sidebar_text']); ?>;
            --admin-sidebar-accent: <?php echo e($theme['sidebar_accent']); ?>;
            --admin-sidebar-logo-bg: <?php echo e($theme['sidebar_logo_bg']); ?>;
            --admin-header-bg: <?php echo e($theme['header_bg']); ?>;
            --admin-header-text: <?php echo e($theme['header_text']); ?>;
        }
    </style>

    <?php $branding = app(App\Support\Branding::class); ?>
    <?php if($favicon = $branding->favicon()): ?>
        <link rel="icon" type="image/webp" href="<?php echo e($favicon->url('32')); ?>">
    <?php endif; ?>

    <link rel="preload" as="font" type="font/woff2" href="<?php echo e(Vite::asset('resources/fonts/plus-jakarta-sans-latin-400.woff2')); ?>" crossorigin>
    
    <script>window.adminBase = <?php echo \Illuminate\Support\Js::from('/'.trim(config('app.admin_prefix'), '/').'/')->toHtml() ?>;</script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/admin/main.ts'); ?>
</head>
<body class="antialiased">
    <div id="admin"></div>
    <noscript>The admin portal requires JavaScript.</noscript>
</body>
</html>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/admin/app.blade.php ENDPATH**/ ?>
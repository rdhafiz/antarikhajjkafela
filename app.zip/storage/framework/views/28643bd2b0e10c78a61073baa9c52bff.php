<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['package', 'card', 'showService' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['package', 'card', 'showService' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    use App\Support\Money;

    $locale = app()->getLocale();
    $name = $package->getTranslation('name', $locale);
    $summary = $package->getTranslation('summary', $locale);
    $open = $card['state'] === 'open';
?>
<article <?php echo e($attributes->class(['pkg-feature relative overflow-hidden rounded-[2rem] border border-line bg-white shadow-[var(--shadow-soft)]'])); ?>>
    <div class="relative isolate flex aspect-[4/3] flex-col justify-between overflow-hidden bg-brand p-6 text-white sm:aspect-[16/7] sm:p-8 lg:aspect-[16/6] lg:p-10">
        <?php if($package->banner): ?>
            <div class="absolute inset-0 -z-20 overflow-hidden">
                <img
                    src="<?php echo e($package->banner->url('lg')); ?>"
                    srcset="<?php echo e($package->banner->srcset()); ?>"
                    sizes="(min-width: 1200px) 1150px, 100vw"
                    alt="" loading="lazy" decoding="async"
                    class="pkg-feature-img size-full object-cover"
                >
            </div>
        <?php else: ?>
            <div class="pattern-star absolute inset-0 -z-20 opacity-[0.08]" aria-hidden="true"></div>
        <?php endif; ?>
        <div class="absolute inset-0 -z-10 bg-gradient-to-t from-brand-950/90 via-brand-950/30 to-brand-950/10" aria-hidden="true"></div>

        <div class="flex flex-wrap items-start gap-2" data-reveal>
            <?php if($showService && $package->service): ?>
                <span class="rounded-full bg-white/95 px-3 py-1 text-[12px] font-semibold text-brand"><?php echo e($package->service->getTranslation('name', $locale)); ?></span>
            <?php endif; ?>
            <?php if($package->is_featured): ?>
                <span class="rounded-full bg-gold px-3 py-1 text-[12px] font-bold text-brand-950"><?php echo e(__('Featured')); ?></span>
            <?php endif; ?>
            <?php if($package->duration_days): ?>
                <span class="flex items-center gap-1.5 rounded-full bg-white/95 px-3 py-1 text-[12px] font-semibold text-brand">
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'calendar','class' => 'size-3.5 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'calendar','class' => 'size-3.5 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    <?php echo e(trans_choice(':count day|:count days', $package->duration_days, ['count' => Money::digits($package->duration_days)])); ?>

                </span>
            <?php endif; ?>
            <?php if (! ($open)): ?>
                <span class="rounded-full bg-brand-950/85 px-3 py-1 text-[12px] font-semibold text-white"><?php echo e($card['state'] === 'closed' ? __('Booking closed') : __('Opening soon')); ?></span>
            <?php endif; ?>
        </div>

        <div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between" data-reveal style="--reveal-delay: 100ms">
            <h3 class="max-w-xl font-display text-display-md text-white">
                <a href="<?php echo e($package->url()); ?>" class="pkg-feature-title"><?php echo e($name); ?></a>
            </h3>
            <?php if($package->min_price): ?>
                <div class="shrink-0 sm:text-end">
                    <p class="text-[12px] font-semibold tracking-[0.14em] text-white/70 uppercase"><?php echo e(__('Starting from')); ?></p>
                    <p class="mt-1 font-display text-[2rem] leading-none font-semibold text-gold sm:text-[2.5rem]"><?php echo e(Money::html($package->min_price)); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid gap-8 p-6 sm:p-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:grid-rows-[auto_1fr] lg:gap-x-12 lg:p-10">
        <div class="lg:col-start-1 lg:row-start-1">
            <?php if(filled($summary)): ?>
                <p class="text-[1.0625rem] leading-relaxed text-ink-2" data-reveal><?php echo e($summary); ?></p>
            <?php endif; ?>

            <?php if($card['flight']): ?>
                <p class="mt-5 flex items-start gap-2.5 text-[14.5px] leading-snug text-ink-2" data-reveal style="--reveal-delay: 100ms">
                    <span class="flex size-8 shrink-0 items-center justify-center rounded-full bg-sand-100"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'plane','class' => 'size-4 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plane','class' => 'size-4 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                    <span class="pt-1.5">
                        <span class="font-semibold text-brand"><?php echo e($card['flight']['airline']); ?></span>
                        <?php if(filled($card['flight']['schedule'] ?? null)): ?> · <?php echo e($card['flight']['schedule']); ?><?php endif; ?>
                    </span>
                </p>
            <?php endif; ?>
        </div>

        <?php if($card['tiers']): ?>
            <div class="lg:col-start-2 lg:row-span-2 lg:row-start-1">
                <p class="text-[12px] font-semibold tracking-[0.14em] text-ink-3 uppercase" data-reveal><?php echo e(__('Package options')); ?></p>
                <ul class="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line">
                    <?php $__currentLoopData = $card['tiers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-reveal="left" style="--reveal-delay: <?php echo e(80 + $index * 110); ?>ms">
                            <a
                                href="<?php echo e($open ? route('bookings.create', ['slug' => $package->slug, 'option' => $tier['option']]) : $package->url().'#prices'); ?>"
                                class="pkg-tier block px-4 py-3.5 sm:px-5"
                            >
                                <span class="flex items-start justify-between gap-4">
                                    <span class="min-w-0 pt-0.5 font-semibold text-brand"><?php echo e($tier['name']); ?></span>
                                    <span class="flex shrink-0 items-center gap-2.5 text-end">
                                        <span>
                                            <span class="block font-display text-[1.25rem] leading-tight font-semibold text-brand"><?php echo e(Money::html($tier['price'])); ?></span>
                                            <span class="block text-[12px] text-ink-3"><?php echo e($tier['unit']); ?></span>
                                        </span>
                                        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'pkg-tier-arrow size-4 shrink-0 text-gold-deep rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'pkg-tier-arrow size-4 shrink-0 text-gold-deep rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                    </span>
                                </span>
                                <?php $__currentLoopData = $tier['hotels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="mt-1 flex gap-1.5 text-[13.5px] leading-snug text-ink-3">
                                        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'hotel','class' => 'mt-0.5 size-3.5 shrink-0 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'hotel','class' => 'mt-0.5 size-3.5 shrink-0 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                        <span class="min-w-0">
                                            <?php if(filled($hotel['heading'] ?? null)): ?><span class="font-semibold text-ink-2"><?php echo e($hotel['heading']); ?>:</span><?php endif; ?>
                                            <?php echo e(collect([$hotel['subheading'] ?? null, $hotel['description'] ?? null])->filter()->implode(' · ')); ?>

                                        </span>
                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <span class="sr-only"><?php echo e($open ? __('Book now') : __('View details')); ?></span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="flex flex-col gap-3 sm:flex-row lg:col-start-1 lg:row-start-2 lg:flex-col lg:self-end xl:flex-row" data-reveal style="--reveal-delay: 150ms">
            <?php if($open): ?>
                <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => route('bookings.create', $package->slug),'variant' => 'gold','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('bookings.create', $package->slug)),'variant' => 'gold','icon-right' => 'arrow-right']); ?><?php echo e(__('Book now')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $package->url(),'variant' => 'outline']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($package->url()),'variant' => 'outline']); ?><?php echo e(__('View full details')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
        </div>
    </div>
</article>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/package-feature.blade.php ENDPATH**/ ?>
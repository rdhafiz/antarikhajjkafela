<?php if (isset($component)) { $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.layout','data' => ['header' => $darkTop ? 'overlay' : 'solid','focused' => $page->isCampaign() && $page->focused_layout,'tracking' => $page->isCampaign() ? ($page->tracking ?? []) : [],'footerCta' => $footerCta]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($darkTop ? 'overlay' : 'solid'),'focused' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page->isCampaign() && $page->focused_layout),'tracking' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page->isCampaign() ? ($page->tracking ?? []) : []),'footer-cta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($footerCta)]); ?>
    <?php if($preview): ?>
        <div class="relative z-50 flex items-center justify-center gap-3 bg-gold px-4 py-2 text-center text-[13px] font-semibold text-brand-950">
            <?php echo e(__('Preview')); ?> · <?php echo e($page->isPublished() ? __('Published') : __('Draft, not visible to visitors')); ?>

            <?php if($page->isCampaign() && $page->campaignState() !== 'live' && $page->isPublished()): ?>
                · <?php echo e(ucfirst($page->campaignState())); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php echo $html; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $attributes = $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $component = $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/page.blade.php ENDPATH**/ ?>
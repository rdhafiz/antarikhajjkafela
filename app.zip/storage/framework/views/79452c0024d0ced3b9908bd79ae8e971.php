
<?php ($id = 'f-'.$sectionId.'-'.$name); ?>
<div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sm:col-span-2' => in_array($type, ['textarea'], true) || ($wide ?? false)]); ?>">
    <label for="<?php echo e($id); ?>" class="mb-1.5 block text-[14px] font-semibold text-ink">
        <?php echo e($label); ?><?php if($required): ?><span class="ml-0.5 text-red-600" aria-hidden="true">*</span><?php endif; ?>
    </label>
    <?php if($type === 'textarea'): ?>
        <textarea id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" rows="4" <?php if($required): echo 'required'; endif; ?>
                  :aria-invalid="errors.<?php echo e($name); ?> ? 'true' : null" :aria-describedby="errors.<?php echo e($name); ?> ? '<?php echo e($id); ?>-error' : null"
                  class="block w-full rounded-xl border border-line bg-white px-4 py-3 text-[15px] text-ink placeholder:text-ink-3 focus:border-brand focus:ring-3 focus:ring-brand/15 focus:outline-none"
                  :class="errors.<?php echo e($name); ?> && '!border-red-500'"></textarea>
    <?php elseif($type === 'select'): ?>
        <select id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" <?php if($required): echo 'required'; endif; ?>
                :aria-invalid="errors.<?php echo e($name); ?> ? 'true' : null"
                class="block h-12 w-full rounded-xl border border-line bg-white px-4 text-[15px] text-ink focus:border-brand focus:ring-3 focus:ring-brand/15 focus:outline-none"
                :class="errors.<?php echo e($name); ?> && '!border-red-500'">
            <option value=""><?php echo e(__('Please choose')); ?></option>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php else: ?>
        <input id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" type="<?php echo e($type); ?>" <?php if($required): echo 'required'; endif; ?>
               <?php if($autocomplete ?? null): ?> autocomplete="<?php echo e($autocomplete); ?>" <?php endif; ?>
               <?php if($type === 'number'): ?> min="1" max="50" inputmode="numeric" <?php endif; ?>
               <?php if($type === 'tel'): ?> inputmode="tel" <?php endif; ?>
               :aria-invalid="errors.<?php echo e($name); ?> ? 'true' : null" :aria-describedby="errors.<?php echo e($name); ?> ? '<?php echo e($id); ?>-error' : null"
               class="block h-12 w-full rounded-xl border border-line bg-white px-4 text-[15px] text-ink placeholder:text-ink-3 focus:border-brand focus:ring-3 focus:ring-brand/15 focus:outline-none"
               :class="errors.<?php echo e($name); ?> && '!border-red-500'">
    <?php endif; ?>
    <p id="<?php echo e($id); ?>-error" x-show="errors.<?php echo e($name); ?>" x-text="errors.<?php echo e($name); ?>?.[0]" x-cloak class="mt-1.5 text-[13px] font-medium text-red-600" role="alert"></p>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/partials/form-field.blade.php ENDPATH**/ ?>
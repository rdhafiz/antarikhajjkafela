<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['section', 'submitLabel', 'success', 'plain' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['section', 'submitLabel', 'success', 'plain' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php ($recaptcha = settings('tracking.recaptcha_site_key') && settings('tracking.recaptcha_secret_key') ? settings('tracking.recaptcha_site_key') : null); ?>

<div <?php echo e($attributes->class(['rounded-[1.75rem] bg-white p-6 shadow-[var(--shadow-lift)] ring-1 ring-line sm:p-9' => ! $plain, 'text-ink'])->merge($plain ? [] : ['data-reveal' => ''])); ?> id="form-<?php echo e($section->id); ?>">
    <?php if(session('form_success') === $section->id): ?>
        <div class="flex flex-col items-center py-10 text-center" role="status">
            <span class="flex size-14 items-center justify-center rounded-full bg-emerald text-white"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
            <p class="mt-5 font-display text-display-sm text-brand"><?php echo e($success); ?></p>
        </div>
    <?php else: ?>
        <form
            method="POST"
            action="<?php echo e(route('forms.submit', $section)); ?>#form-<?php echo e($section->id); ?>"
            x-data="siteForm(<?php echo \Illuminate\Support\Js::from($recaptcha)->toHtml() ?>)"
            @submit.prevent="submit($el)"
            @focusin.once="loadRecaptcha()"
            novalidate
        >
            <?php echo csrf_field(); ?>
            
            <div class="absolute -left-[9999px]" aria-hidden="true">
                <label for="website-<?php echo e($section->id); ?>">Website</label>
                <input id="website-<?php echo e($section->id); ?>" type="text" name="website" tabindex="-1" autocomplete="off">
            </div>

            <template x-if="done">
                <div class="flex flex-col items-center py-10 text-center" role="status">
                    <span class="flex size-14 items-center justify-center rounded-full bg-emerald text-white"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                    <p class="mt-5 font-display text-display-sm text-brand"><?php echo e($success); ?></p>
                </div>
            </template>

            <div x-show="!done">
                <div class="grid gap-5 sm:grid-cols-2">
                    <?php echo e($slot); ?>

                </div>

                <p x-show="message" x-text="message" x-cloak class="mt-5 rounded-xl bg-red-50 px-4 py-3 text-[14px] font-medium text-red-700" role="alert"></p>

                <button type="submit" class="btn btn-primary btn-lg mt-7 w-full" :disabled="busy">
                    <svg x-show="busy" x-cloak class="size-5 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-opacity=".25" stroke-width="3"/><path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>
                    <?php echo e($submitLabel); ?>

                </button>
                <?php if($recaptcha): ?>
                    <p class="mt-4 text-center text-[12px] text-ink-3"><?php echo e(__('Protected by reCAPTCHA.')); ?></p>
                <?php endif; ?>
            </div>
        </form>
    <?php endif; ?>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/form-shell.blade.php ENDPATH**/ ?>
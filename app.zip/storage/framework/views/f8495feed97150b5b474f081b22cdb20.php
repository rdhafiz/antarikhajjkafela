<?php
    $count = $photos->count();
    // Five photos make a mosaic: one large tile beside four small ones.
    $mosaic = $count === 5;
    $dark = $style['tone'] === 'dark';
?>
<?php if($count || $albums->isNotEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
        <?php if($dark && ! $style['image']): ?>
            <div class="pattern-star pointer-events-none absolute -inset-y-[25%] inset-x-0 -z-10 opacity-[0.05]" data-parallax="0.2" aria-hidden="true"></div>
            <div class="pointer-events-none absolute -right-40 -bottom-40 -z-10 size-[520px] rounded-full bg-gold/10 blur-3xl" data-parallax="-0.15" aria-hidden="true"></div>
        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'class' => 'mb-14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'class' => 'mb-14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
        <?php if($albums->isNotEmpty()): ?>
            
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid gap-6 sm:grid-cols-2', 'lg:grid-cols-3' => $albums->count() !== 2 && $albums->count() !== 4, 'mx-auto max-w-4xl' => $albums->count() === 2]); ?>">
                <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-reveal="scale" style="--reveal-delay: <?php echo e(($index % 3) * 100); ?>ms">
                        <?php if (isset($component)) { $__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.album-card','data' => ['album' => $album]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.album-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['album' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($album)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3)): ?>
<?php $attributes = $__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3; ?>
<?php unset($__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3)): ?>
<?php $component = $__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3; ?>
<?php unset($__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
        <ul class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'grid grid-cols-2 gap-2.5 sm:gap-3',
            'sm:grid-cols-3' => $count <= 3,
            'sm:grid-cols-4' => $count > 3 && $count !== 10,
            'sm:grid-cols-5' => $count === 10,
        ]); ?>" data-reveal="scale">
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($big = $mosaic && $index === 0); ?>
                <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['col-span-2 row-span-2' => $big]); ?>">
                    <div class="size-full" data-reveal="scale" style="--reveal-delay: <?php echo e(($index % 5) * 90); ?>ms">
                    <a href="<?php echo e($photo->album->url()); ?>" class="group relative block aspect-square overflow-hidden rounded-xl bg-brand-950 focus-visible:ring-4 focus-visible:ring-gold/60 focus-visible:outline-none sm:h-full">
                        <img
                            src="<?php echo e($photo->media->url($big ? 'md' : 'thumb')); ?>"
                            <?php if($big): ?> srcset="<?php echo e($photo->media->srcset()); ?>" sizes="(min-width: 640px) 50vw, 100vw" <?php endif; ?>
                            alt="<?php echo e($photo->getTranslation('caption', app()->getLocale()) ?: $photo->media->getTranslation('alt', app()->getLocale())); ?>"
                            loading="lazy"
                            decoding="async"
                            class="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-105"
                        >
                        <span class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-brand-950/85 to-transparent p-3 pt-10 text-[13px] font-semibold text-white opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
                            <?php echo e($photo->album->getTranslation('title', app()->getLocale())); ?>

                        </span>
                    </a>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        <?php if($c['cta']): ?>
            <div class="mt-12 text-center">
                <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['cta'],'variant' => $style['tone'] === 'dark' ? 'gold' : 'primary','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['cta']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style['tone'] === 'dark' ? 'gold' : 'primary'),'icon-right' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/gallery-preview.blade.php ENDPATH**/ ?>
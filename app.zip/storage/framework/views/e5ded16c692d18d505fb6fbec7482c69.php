<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'tone' => 'sand',       // sand | white | sand-deep | navy
    'spacing' => 'lg',      // sm | md | lg | none
    'pattern' => false,     // subtle star lattice in the background
    'id' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'tone' => 'sand',       // sand | white | sand-deep | navy
    'spacing' => 'lg',      // sm | md | lg | none
    'pattern' => false,     // subtle star lattice in the background
    'id' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $tones = [
        'sand' => 'bg-sand-50 text-ink',
        'white' => 'bg-white text-ink',
        'sand-deep' => 'bg-sand-100 text-ink',
        'navy' => 'bg-brand text-white',
    ];
    $spacings = [
        'none' => '',
        'sm' => 'py-12 sm:py-14',
        'md' => 'py-16 sm:py-20',
        'lg' => 'py-20 sm:py-24 lg:py-28',
    ];
?>
<section <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?> <?php echo e($attributes->class(['relative isolate overflow-hidden', $tones[$tone] ?? $tones['sand'], $spacings[$spacing] ?? $spacings['lg']])); ?>>
    <?php if($pattern): ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'pointer-events-none absolute inset-0 -z-10',
            'pattern-star opacity-[0.06]' => $tone === 'navy',
            'pattern-star-ink opacity-[0.025]' => $tone !== 'navy',
        ]); ?>" aria-hidden="true"></div>
    <?php endif; ?>
    <div class="container-site">
        <?php echo e($slot); ?>

    </div>
</section>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/section.blade.php ENDPATH**/ ?>
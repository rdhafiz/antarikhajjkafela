<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>New enquiry</title></head>
<body style="margin:0;background:#f7f2e9;font-family:Arial,Helvetica,sans-serif;color:#0d1b2e;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:32px 12px;">
        <tr><td align="center">
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden;">
                <tr><td style="background:#012a51;padding:20px 28px;color:#fdc802;font-size:13px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;">
                    <?php echo e($inquiry->source === 'lead_form' ? 'Campaign registration' : 'Website message'); ?>

                </td></tr>
                <tr><td style="padding:28px;">
                    <p style="margin:0 0 18px;font-size:16px;">A new enquiry was received<?php echo e(isset($inquiry->data['page']) ? ' on "'.$inquiry->data['page'].'"' : ''); ?>.</p>
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;">
                        <?php $__currentLoopData = array_filter(['Name' => $inquiry->name, 'Phone' => $inquiry->phone, 'Email' => $inquiry->email]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td style="padding:8px 0;color:#66738a;width:38%;"><?php echo e($label); ?></td><td style="padding:8px 0;font-weight:bold;"><?php echo e($value); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = collect($inquiry->data)->except('page'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td style="padding:8px 0;color:#66738a;vertical-align:top;"><?php echo e(str($key)->replace('_', ' ')->title()); ?></td><td style="padding:8px 0;white-space:pre-line;"><?php echo e($value); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <p style="margin:26px 0 0;">
                        <a href="<?php echo e(admin_url('inquiries')); ?>" style="display:inline-block;background:#012a51;color:#ffffff;text-decoration:none;padding:12px 22px;border-radius:999px;font-weight:bold;font-size:14px;">Open the inquiry inbox</a>
                    </p>
                </td></tr>
            </table>
        </td></tr>
    </table>
</body>
</html>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/emails/inquiry-received.blade.php ENDPATH**/ ?>
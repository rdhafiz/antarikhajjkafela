<?php $structuredData = app(App\Support\Seo\StructuredData::class); ?>
<?php $branding = app(App\Support\Branding::class); ?>
<?php
    $seo = seo();
    $title = $seo->resolvedTitle();
    $description = $seo->resolvedDescription();
    $image = $seo->resolvedImage();
    $locale = app()->getLocale();
    $ogLocale = ['en' => 'en_US', 'bn' => 'bn_BD'][$locale] ?? $locale;
?>
<title><?php echo e($title); ?></title>
<?php if($description): ?>
    <meta name="description" content="<?php echo e($description); ?>">
<?php endif; ?>
<link rel="canonical" href="<?php echo e($seo->resolvedCanonical()); ?>">
<meta name="robots" content="<?php echo e($seo->noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large'); ?>">
<?php if($verification = settings('tracking.search_console_verification')): ?>
    <meta name="google-site-verification" content="<?php echo e($verification); ?>">
<?php endif; ?>

<meta property="og:type" content="<?php echo e($seo->type); ?>">
<meta property="og:site_name" content="<?php echo e(setting_t('branding.site_name')); ?>">
<meta property="og:title" content="<?php echo e($title); ?>">
<?php if($description): ?>
    <meta property="og:description" content="<?php echo e($description); ?>">
<?php endif; ?>
<meta property="og:url" content="<?php echo e($seo->resolvedCanonical()); ?>">
<meta property="og:image" content="<?php echo e($image); ?>">
<?php if($image && str_contains($image, '/og.')): ?>
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
<?php endif; ?>
<meta property="og:image:alt" content="<?php echo e($title); ?>">
<meta property="og:locale" content="<?php echo e($ogLocale); ?>">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($title); ?>">
<?php if($description): ?>
    <meta name="twitter:description" content="<?php echo e($description); ?>">
<?php endif; ?>
<meta name="twitter:image" content="<?php echo e($image); ?>">

<script type="application/ld+json"><?php echo $structuredData->toJson($seo); ?></script>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/seo-head.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['review', 'withVideo' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['review', 'withVideo' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $locale = app()->getLocale();
    $name = $review->getTranslation('name', $locale);
    $intro = $review->getTranslation('intro', $locale);
    $text = $review->getTranslation('text', $locale);
    $videoId = $withVideo ? $review->youtubeId() : null;
    $long = mb_strlen((string) $text) > 320;
    $initials = collect(preg_split('/\s+/u', preg_replace('/[^\p{L}\s]/u', '', $name)))->filter()->take(2)->map(fn ($w) => mb_substr($w, 0, 1))->implode('');
?>
<figure <?php echo e($attributes->class('sec-card relative flex flex-col rounded-[1.5rem] p-6 sm:p-7')); ?>>
    <?php if($videoId): ?>
        <?php if (isset($component)) { $__componentOriginal777d174d449987e366d0f1bfb42a6927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal777d174d449987e366d0f1bfb42a6927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.youtube','data' => ['id' => $videoId,'title' => $name,'class' => '-mx-1 -mt-1 mb-6','rounded' => 'rounded-xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.youtube'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($videoId),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($name),'class' => '-mx-1 -mt-1 mb-6','rounded' => 'rounded-xl']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal777d174d449987e366d0f1bfb42a6927)): ?>
<?php $attributes = $__attributesOriginal777d174d449987e366d0f1bfb42a6927; ?>
<?php unset($__attributesOriginal777d174d449987e366d0f1bfb42a6927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal777d174d449987e366d0f1bfb42a6927)): ?>
<?php $component = $__componentOriginal777d174d449987e366d0f1bfb42a6927; ?>
<?php unset($__componentOriginal777d174d449987e366d0f1bfb42a6927); ?>
<?php endif; ?>
    <?php endif; ?>

    <div class="flex items-center justify-between gap-4">
        <?php if($review->rating): ?>
            <?php if (isset($component)) { $__componentOriginalbfd438c48abc74c4d441f9a756f44afc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfd438c48abc74c4d441f9a756f44afc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.stars','data' => ['rating' => $review->rating]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.stars'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($review->rating)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfd438c48abc74c4d441f9a756f44afc)): ?>
<?php $attributes = $__attributesOriginalbfd438c48abc74c4d441f9a756f44afc; ?>
<?php unset($__attributesOriginalbfd438c48abc74c4d441f9a756f44afc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfd438c48abc74c4d441f9a756f44afc)): ?>
<?php $component = $__componentOriginalbfd438c48abc74c4d441f9a756f44afc; ?>
<?php unset($__componentOriginalbfd438c48abc74c4d441f9a756f44afc); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'quote','class' => 'ml-auto size-8 text-gold/60']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'quote','class' => 'ml-auto size-8 text-gold/60']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
    </div>

    <?php if(filled($text)): ?>
        <blockquote class="mt-4 flex-1" <?php if($long): ?> x-data="{ open: false }" <?php endif; ?>>
            <p class="sec-text text-[15.5px] leading-relaxed whitespace-pre-line" <?php if($long): ?> :class="open || 'line-clamp-6'" <?php endif; ?>><?php echo e($text); ?></p>
            <?php if($long): ?>
                <button type="button" class="mt-2 text-[14px] font-semibold text-[var(--sec-eyebrow)] hover:underline" @click="open = !open" x-text="open ? <?php echo \Illuminate\Support\Js::from(__('Show less'))->toHtml() ?> : <?php echo \Illuminate\Support\Js::from(__('Read more'))->toHtml() ?>" :aria-expanded="open"><?php echo e(__('Read more')); ?></button>
            <?php endif; ?>
        </blockquote>
    <?php endif; ?>

    <figcaption class="mt-6 flex items-center gap-3.5 border-t border-[var(--sec-border)] pt-5">
        <?php if($review->photo): ?>
            <img src="<?php echo e($review->photo->url('sm')); ?>" alt="" width="48" height="48" loading="lazy" decoding="async" class="size-12 shrink-0 rounded-full object-cover ring-2 ring-gold/50">
        <?php else: ?>
            <span class="flex size-12 shrink-0 items-center justify-center rounded-full bg-brand font-display text-[17px] font-semibold text-gold ring-2 ring-gold/40" aria-hidden="true"><?php echo e($initials); ?></span>
        <?php endif; ?>
        <span class="min-w-0">
            <span class="sec-heading block font-semibold"><?php echo e($name); ?></span>
            <?php if($intro): ?>
                <span class="sec-muted block text-[13px]"><?php echo e($intro); ?></span>
            <?php endif; ?>
        </span>
    </figcaption>
</figure>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/review-card.blade.php ENDPATH**/ ?>
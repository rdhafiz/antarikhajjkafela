<?php $site = app(App\Support\SiteContext::class); ?>
<?php if($url = $site->whatsappUrl(__('Assalamu alaikum, I would like to know about your Hajj & Umrah packages.'))): ?>
<aside aria-label="<?php echo e(__('Chat with us on WhatsApp')); ?>">
    <a
        href="<?php echo e($url); ?>"
        target="_blank"
        rel="noopener"
        class="group fixed right-4 bottom-4 z-40 flex items-center rounded-full bg-[#15803d] p-3.5 text-white shadow-[0_12px_30px_-8px_rgb(21_128_61/0.6)] transition-[translate,box-shadow] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 sm:right-6 sm:bottom-6"
        style="margin-bottom: env(safe-area-inset-bottom)"
        aria-label="<?php echo e(__('Chat with us on WhatsApp')); ?>"
    >
        <span class="absolute inset-0 animate-[wa-ping_2.4s_ease-out_infinite] rounded-full bg-[#15803d] motion-reduce:hidden" aria-hidden="true"></span>
        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'whatsapp','class' => 'relative size-7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'whatsapp','class' => 'relative size-7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
        <span class="relative hidden max-w-0 overflow-hidden text-[15px] font-semibold whitespace-nowrap transition-[max-width,padding] duration-300 group-hover:max-w-40 group-hover:pr-1.5 group-hover:pl-2 group-focus-visible:max-w-40 group-focus-visible:pr-1.5 group-focus-visible:pl-2 sm:block">
            <?php echo e(__('Chat with us')); ?>

        </span>
    </a>
    <style>
        @keyframes wa-ping {
            0% { transform: scale(1); opacity: 0.45; }
            70%, 100% { transform: scale(1.45); opacity: 0; }
        }
    </style>
</aside>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/whatsapp-button.blade.php ENDPATH**/ ?>
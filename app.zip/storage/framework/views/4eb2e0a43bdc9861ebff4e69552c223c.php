<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['album']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['album']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    use App\Support\Money;

    $locale = app()->getLocale();
    $images = $album->images_count ?? null;
    $videos = $album->videos_count ?? null;
?>
<div <?php echo e($attributes); ?>>
<article class="group relative overflow-hidden rounded-[1.5rem] bg-brand-950 shadow-[var(--shadow-soft)] transition-[translate,box-shadow] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1.5 hover:shadow-[var(--shadow-lift)]">
    <div class="relative aspect-[4/3]">
        <?php if($album->cover): ?>
            <img
                src="<?php echo e($album->cover->url('thumb') ?? $album->cover->url('sm')); ?>"
                srcset="<?php echo e($album->cover->srcset()); ?>"
                sizes="(min-width: 1024px) 380px, (min-width: 640px) 50vw, 100vw"
                alt=""
                loading="lazy"
                decoding="async"
                class="absolute inset-0 size-full object-cover transition-[scale] duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.05]"
            >
        <?php else: ?>
            <div class="pattern-star absolute inset-0 opacity-[0.08]" aria-hidden="true"></div>
        <?php endif; ?>
        <div class="absolute inset-0 bg-gradient-to-t from-brand-950/90 via-brand-950/25 to-transparent" aria-hidden="true"></div>

        <div class="absolute inset-x-0 bottom-0 p-6 text-center">
            <?php if($album->event_date): ?>
                <p class="text-[12px] font-semibold tracking-wider text-gold uppercase"><?php echo e(App\Support\Dates::format($album->event_date, 'F Y', $locale)); ?></p>
            <?php endif; ?>
            <h3 class="mt-1.5 font-display text-display-sm text-white">
                <a href="<?php echo e($album->url()); ?>" class="after:absolute after:inset-0 focus-visible:outline-none"><?php echo e($album->getTranslation('title', $locale)); ?></a>
            </h3>
            <?php if($images !== null): ?>
                <p class="mt-2.5 flex items-center justify-center gap-4 text-[13px] font-medium text-white/75">
                    <?php if($images): ?>
                        <span class="inline-flex items-center gap-1.5"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'image','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(trans_choice(':count photo|:count photos', $images, ['count' => Money::digits($images)])); ?></span>
                    <?php endif; ?>
                    <?php if($videos): ?>
                        <span class="inline-flex items-center gap-1.5"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'play','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(trans_choice(':count video|:count videos', $videos, ['count' => Money::digits($videos)])); ?></span>
                    <?php endif; ?>
                </p>
            <?php endif; ?>
        </div>
    </div>
</article>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/album-card.blade.php ENDPATH**/ ?>

<?php
    $twoColumn = ($s['layout'] ?? 'full') === 'two_column';
    $image = $s['image'];
    $bg = $s['background_color'];
    $text = $s['text_color'];
    $hasBgImage = ! $twoColumn && $image;
    $hasHeading = filled($s['badge']) || filled($s['heading']) || filled($s['subheading']);
    // Full-width sections without an image: heading on the left, content across the rest.
    $split = ! $twoColumn && $hasHeading && $s['blocks'];

    // Dark when there is a background image (overlay), or a dark background color.
    $isDark = $hasBgImage || ($bg && (function ($hex) {
        [$r, $g, $b] = sscanf($hex, '#%02x%02x%02x');

        return (0.299 * $r + 0.587 * $g + 0.114 * $b) < 150;
    })($bg));
    $palette = $text ? "--sec-heading: {$text}; --sec-text: {$text}; --sec-muted: {$text};" : '';
    $style = trim(($bg && ! $hasBgImage ? "background-color: {$bg}; " : '').$palette);
?>
<section
    <?php if(filled($s['heading'])): ?> id="details-<?php echo e($index + 1); ?>" <?php endif; ?>
    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['relative isolate scroll-mt-36 overflow-clip py-16 sm:py-20 lg:py-24', 'section-dark' => $isDark, 'section-light' => ! $isDark, 'bg-white' => ! $bg && ! $hasBgImage && $index % 2 === 0, 'bg-sand-50' => ! $bg && ! $hasBgImage && $index % 2 === 1]); ?>"
    <?php if($style): ?> style="<?php echo e($style); ?>" <?php endif; ?>
>
    <?php if($hasBgImage): ?>
        <img src="<?php echo e($image->url('lg')); ?>" srcset="<?php echo e($image->srcset()); ?>" sizes="100vw" alt="" loading="lazy" decoding="async" class="absolute inset-0 -z-20 size-full object-cover">
        <div class="absolute inset-0 -z-10" style="background-color: <?php echo e($bg ?: '#06182e'); ?>; opacity: .82" aria-hidden="true"></div>
    <?php endif; ?>

    <div class="container-site">
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'grid items-center gap-12 lg:grid-cols-2 lg:gap-16' => $twoColumn && $image,
            'grid gap-8 lg:grid-cols-[minmax(0,0.75fr)_minmax(0,1.25fr)] lg:gap-16' => $split,
            'mx-auto max-w-4xl' => ! ($twoColumn && $image) && ! $split,
        ]); ?>">
            <?php if($split): ?>
                <div class="lg:sticky lg:top-40 lg:self-start" data-reveal>
                    <?php if(filled($s['badge'])): ?>
                        <span class="inline-flex rounded-full bg-gold px-3.5 py-1 text-[12px] font-bold tracking-wide text-brand-950 uppercase"><?php echo e($s['badge']); ?></span>
                    <?php endif; ?>
                    <?php if(filled($s['heading'])): ?>
                        <h2 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sec-heading text-display-md', 'mt-4' => filled($s['badge'])]); ?>"><?php echo e($s['heading']); ?></h2>
                    <?php endif; ?>
                    <?php if(filled($s['subheading'])): ?>
                        <p class="sec-text mt-3 text-[1.0625rem] leading-relaxed"><?php echo e($s['subheading']); ?></p>
                    <?php endif; ?>
                    <?php if($s['cta']): ?>
                        <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $s['cta'],'variant' => $isDark ? 'gold' : 'primary','iconRight' => 'arrow-right','class' => 'mt-8']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s['cta']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isDark ? 'gold' : 'primary'),'icon-right' => 'arrow-right','class' => 'mt-8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="pkg-blocks min-w-0" data-reveal-items="li, .prose-site > *, figure, iframe">
                    <?php echo $__env->make('partials.content-blocks', ['blocks' => $s['blocks']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            <?php else: ?>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['lg:order-2' => $twoColumn && ($s['image_position'] ?? 'right') === 'left']); ?>">
                <div data-reveal>
                    <?php if(filled($s['badge'])): ?>
                        <span class="inline-flex rounded-full bg-gold px-3.5 py-1 text-[12px] font-bold tracking-wide text-brand-950 uppercase"><?php echo e($s['badge']); ?></span>
                    <?php endif; ?>
                    <?php if(filled($s['heading'])): ?>
                        <h2 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sec-heading text-display-md', 'mt-4' => filled($s['badge'])]); ?>"><?php echo e($s['heading']); ?></h2>
                    <?php endif; ?>
                    <?php if(filled($s['subheading'])): ?>
                        <p class="sec-text mt-3 text-[1.0625rem] leading-relaxed"><?php echo e($s['subheading']); ?></p>
                    <?php endif; ?>
                </div>
                <?php if($s['blocks']): ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-8' => filled($s['heading']) || filled($s['subheading'])]); ?>" data-reveal-items="li, .prose-site > *, figure, iframe">
                        <?php echo $__env->make('partials.content-blocks', ['blocks' => $s['blocks']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endif; ?>
                <?php if($s['cta']): ?>
                    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $s['cta'],'variant' => $isDark ? 'gold' : 'primary','iconRight' => 'arrow-right','class' => 'mt-8']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s['cta']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isDark ? 'gold' : 'primary'),'icon-right' => 'arrow-right','class' => 'mt-8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>

            <?php endif; ?>

            <?php if($twoColumn && $image): ?>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['lg:order-1' => ($s['image_position'] ?? 'right') === 'left']); ?>">
                    <img
                        src="<?php echo e($image->url('md')); ?>"
                        srcset="<?php echo e($image->srcset()); ?>"
                        sizes="(min-width: 1024px) 45vw, 100vw"
                        alt="<?php echo e($image->getTranslation('alt', app()->getLocale())); ?>"
                        loading="lazy"
                        decoding="async"
                        class="aspect-[4/3] w-full rounded-[1.75rem] object-cover shadow-[var(--shadow-lift)]"
                    >
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/packages/section.blade.php ENDPATH**/ ?>
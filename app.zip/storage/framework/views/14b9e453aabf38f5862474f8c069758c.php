<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <?php if (! ($style['image'])): ?>
        <div class="pattern-star pointer-events-none absolute -inset-y-[30%] inset-x-0 -z-10 opacity-[0.05]" data-parallax="0.3" aria-hidden="true"></div>
    <?php endif; ?>
    <div class="pointer-events-none absolute top-1/2 -left-24 -z-10 size-[420px] -translate-y-1/2 rounded-full border-[28px] border-gold/[0.07]" data-parallax="-0.25" aria-hidden="true"></div>
    <div class="pointer-events-none absolute -right-16 -bottom-24 -z-10 size-72 rounded-full bg-gold/10 blur-3xl" data-parallax="0.2" aria-hidden="true"></div>
    <figure class="mx-auto max-w-3xl text-center" data-reveal="wipe">
        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'moon','class' => 'mx-auto size-8 text-gold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'moon','class' => 'mx-auto size-8 text-gold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
        <?php if(filled($c['arabic'])): ?>
            <p lang="ar" dir="rtl" class="sec-heading mt-7 font-serif text-[1.9rem] leading-[1.9]"><?php echo e($c['arabic']); ?></p>
        <?php endif; ?>
        <blockquote class="sec-heading mt-6 font-display text-display-md italic">“<?php echo e($c['text']); ?>”</blockquote>
        <?php if(filled($c['source'])): ?>
            <figcaption class="mt-6 inline-flex items-center gap-3 text-[14px] font-semibold tracking-wide text-gold uppercase">
                <span class="h-px w-8 bg-gold/60"></span><?php echo e($c['source']); ?><span class="h-px w-8 bg-gold/60"></span>
            </figcaption>
        <?php endif; ?>
    </figure>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/quote.blade.php ENDPATH**/ ?>
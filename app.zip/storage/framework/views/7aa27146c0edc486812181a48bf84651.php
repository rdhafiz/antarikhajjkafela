<?php $site = app(App\Support\SiteContext::class); ?>
<footer class="bg-brand-950 text-[13px] text-white/55">
    <div class="container-site flex flex-col gap-3 py-8 sm:flex-row sm:items-center sm:justify-between">
        <p>© <?php echo e(now()->year); ?> <?php echo e($site->name()); ?>. <?php echo e(__('All rights reserved.')); ?></p>
        <div class="flex flex-wrap items-center gap-x-5 gap-y-2">
            <?php $__currentLoopData = $site->phones(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($phone['href']); ?>" class="hover:text-white"><?php echo e($phone['display']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('/')); ?>" class="hover:text-white"><?php echo e(__('Visit our website')); ?></a>
        </div>
    </div>
</footer>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/focused-footer.blade.php ENDPATH**/ ?>
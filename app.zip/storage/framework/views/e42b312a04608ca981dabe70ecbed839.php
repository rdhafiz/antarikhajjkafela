<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'style',                // resolved SectionStyle
    'section' => null,
    'container' => true,    // wrap the content in .container-site
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'style',                // resolved SectionStyle
    'section' => null,
    'container' => true,    // wrap the content in .container-site
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section
    <?php if($style['id']): ?> id="<?php echo e($style['id']); ?>" <?php endif; ?>
    <?php if($section): ?> data-section="<?php echo e($section->component); ?>" <?php endif; ?>
    <?php echo e($attributes->class(['relative isolate overflow-hidden', $style['class']])); ?>

    <?php if($style['style']): ?> style="<?php echo e($style['style']); ?>" <?php endif; ?>
>
    <?php if($style['image']): ?>
        <div class="absolute inset-x-0 -inset-y-[20%] -z-20" data-parallax="0.15" aria-hidden="true">
            <img
                src="<?php echo e($style['image']->url('lg')); ?>"
                srcset="<?php echo e($style['image']->srcset()); ?>"
                sizes="100vw"
                alt=""
                loading="lazy"
                decoding="async"
                class="size-full object-cover"
            >
        </div>
        <div class="absolute inset-0 -z-10" style="<?php echo e($style['overlay']); ?>" aria-hidden="true"></div>
    <?php endif; ?>

    <?php if($container): ?>
        <div class="container-site"><?php echo e($slot); ?></div>
    <?php else: ?>
        <?php echo e($slot); ?>

    <?php endif; ?>
</section>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/block.blade.php ENDPATH**/ ?>
<?php ($dark = $style['tone'] === 'dark'); ?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="grid items-center gap-14 lg:grid-cols-[0.95fr_1.05fr] lg:gap-20">
        
        <div class="relative mx-auto w-full max-w-lg lg:max-w-none" data-reveal="left">
            <div class="pointer-events-none absolute -top-10 -left-10 -z-10 size-48 rounded-full border border-gold/40" data-parallax="0.18" aria-hidden="true"></div>
            <?php if($c['image']): ?>
                <img
                    src="<?php echo e($c['image']->url('md')); ?>"
                    srcset="<?php echo e($c['image']->srcset()); ?>"
                    sizes="(min-width: 1024px) 40vw, 90vw"
                    alt="<?php echo e($c['image']->getTranslation('alt', app()->getLocale())); ?>"
                    loading="lazy"
                    decoding="async"
                    class="aspect-[4/5] w-[82%] rounded-t-[999px] rounded-b-[1.75rem] object-cover shadow-[var(--shadow-lift)]"
                >
            <?php else: ?>
                <div class="relative flex aspect-[4/5] w-[82%] items-center justify-center overflow-hidden rounded-t-[999px] rounded-b-[1.75rem] bg-gradient-to-b from-brand to-brand-950" aria-hidden="true">
                    <div class="pattern-star absolute inset-0 opacity-[0.08]"></div>
                    <img src="<?php echo e(app(App\Support\Branding::class)->iconUrl(512)); ?>" alt="" width="512" height="512" loading="lazy" class="relative w-1/2 drop-shadow-2xl">
                </div>
            <?php endif; ?>

            <?php if($c['image_secondary']): ?>
                <img
                    src="<?php echo e($c['image_secondary']->url('md')); ?>"
                    srcset="<?php echo e($c['image_secondary']->srcset()); ?>"
                    sizes="(min-width: 1024px) 18vw, 42vw"
                    alt="<?php echo e($c['image_secondary']->getTranslation('alt', app()->getLocale())); ?>"
                    loading="lazy"
                    decoding="async"
                    class="absolute right-0 bottom-[-6%] aspect-square w-[46%] rounded-[1.5rem] border-[6px] border-white object-cover shadow-[var(--shadow-lift)]"
                >
            <?php endif; ?>

            <?php if(filled($c['years_value'])): ?>
                <div class="absolute top-[12%] right-[4%] rounded-2xl bg-brand px-5 py-4 text-center text-white shadow-[var(--shadow-lift)]">
                    <p class="font-display text-4xl leading-none font-semibold text-gold" data-count><?php echo e(App\Support\Money::digits($c['years_value'])); ?></p>
                    <?php if(filled($c['years_label'])): ?><p class="mt-1.5 max-w-24 text-[12px] leading-tight text-white/75"><?php echo e($c['years_label']); ?></p><?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div data-reveal="right" style="--reveal-delay: 120ms">
            
            <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'align' => 'left','as' => $first ? 'h1' : 'h2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'align' => 'left','as' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($first ? 'h1' : 'h2')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
            <?php if(filled($c['body'])): ?>
                <div class="prose-site mt-6"><?php echo $c['body']; ?></div>
            <?php endif; ?>
            <?php if(filled($c['quote'])): ?>
                <figure class="sec-card mt-8 p-6">
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'quote','class' => 'size-7 text-gold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'quote','class' => 'size-7 text-gold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    <blockquote class="sec-heading mt-3 font-display text-[1.15rem] leading-relaxed"><?php echo e($c['quote']); ?></blockquote>
                    <?php if(filled($c['quote_author'])): ?><figcaption class="sec-muted mt-3 text-[14px] font-semibold">— <?php echo e($c['quote_author']); ?></figcaption><?php endif; ?>
                </figure>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['link'],'variant' => $dark ? 'gold' : 'primary','iconRight' => 'arrow-right','class' => 'mt-9']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['link']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dark ? 'gold' : 'primary'),'icon-right' => 'arrow-right','class' => 'mt-9']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/about.blade.php ENDPATH**/ ?>
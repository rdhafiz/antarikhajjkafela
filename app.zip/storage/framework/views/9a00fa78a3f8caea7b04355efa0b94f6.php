<?php $site = app(App\Support\SiteContext::class); ?>
<?php
    use App\Domain\Travel\PackagePresenter;
    use App\Support\Money;

    $locale = app()->getLocale();
    $booking = $p['booking'];
    $bookable = $booking['state'] === 'open';
    $phones = $site->phones();
    $airlines = collect($p['flights'])->pluck('airline')->filter()->unique()->implode(', ');
    $enquire = fn (?string $option = null) => $site->whatsappUrl(trim(__('Assalamu alaikum, I am interested in the ":package" package', ['package' => $p['name']]).($option ? ' – '.$option : '').'.'));
?>
<?php if (isset($component)) { $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.layout','data' => ['header' => 'overlay']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'overlay']); ?>
    
    <?php if (isset($component)) { $__componentOriginal7581f317093bf3292868869e04b36f91 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7581f317093bf3292868869e04b36f91 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.hero','data' => ['eyebrow' => $p['service']->getTranslation('name', $locale),'title' => $p['name'],'intro' => $p['summary'],'image' => $p['banner'],'stats' => [
            ['value' => $p['from'] ? Money::html($p['from']) : null, 'label' => __('Starting from')],
            ['value' => $p['duration'] ? trans_choice(':count day|:count days', $p['duration'], ['count' => Money::digits($p['duration'])]) : null, 'label' => __('Duration')],
            ['value' => new Illuminate\Support\HtmlString('<span class=\'size-2.5 shrink-0 rounded-full '.($bookable ? 'bg-emerald' : ($booking['state'] === 'upcoming' ? 'bg-gold' : 'bg-red-400')).'\'></span>'.e($booking['label'])), 'label' => __('Booking'), 'small' => true],
            ['value' => $airlines ?: null, 'label' => __('Airline'), 'small' => true],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p['service']->getTranslation('name', $locale)),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p['name']),'intro' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p['summary']),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p['banner']),'stats' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['value' => $p['from'] ? Money::html($p['from']) : null, 'label' => __('Starting from')],
            ['value' => $p['duration'] ? trans_choice(':count day|:count days', $p['duration'], ['count' => Money::digits($p['duration'])]) : null, 'label' => __('Duration')],
            ['value' => new Illuminate\Support\HtmlString('<span class=\'size-2.5 shrink-0 rounded-full '.($bookable ? 'bg-emerald' : ($booking['state'] === 'upcoming' ? 'bg-gold' : 'bg-red-400')).'\'></span>'.e($booking['label'])), 'label' => __('Booking'), 'small' => true],
            ['value' => $airlines ?: null, 'label' => __('Airline'), 'small' => true],
        ])]); ?>
        <div class="flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
            <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => '#prices','variant' => 'gold','size' => 'lg','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '#prices','variant' => 'gold','size' => 'lg','icon-right' => 'arrow-right']); ?><?php echo e(__('See prices & hotels')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
            <?php if($whatsapp = $enquire()): ?>
                <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $whatsapp,'variant' => 'whatsapp','size' => 'lg','icon' => 'whatsapp','external' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($whatsapp),'variant' => 'whatsapp','size' => 'lg','icon' => 'whatsapp','external' => true]); ?><?php echo e(__('Ask on WhatsApp')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7581f317093bf3292868869e04b36f91)): ?>
<?php $attributes = $__attributesOriginal7581f317093bf3292868869e04b36f91; ?>
<?php unset($__attributesOriginal7581f317093bf3292868869e04b36f91); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7581f317093bf3292868869e04b36f91)): ?>
<?php $component = $__componentOriginal7581f317093bf3292868869e04b36f91; ?>
<?php unset($__componentOriginal7581f317093bf3292868869e04b36f91); ?>
<?php endif; ?>

    <?php
        // In-page sections for the sticky bar: options, flights, then each custom section that has a heading.
        $nav = collect([
            $p['types'] ? ['id' => 'prices', 'label' => __('Options & hotels')] : null,
            $p['flights'] ? ['id' => 'flights', 'label' => __('Flights')] : null,
        ])->filter()->merge(
            collect($p['sections'])->map(fn ($s, $i) => filled($s['heading']) ? ['id' => 'details-'.($i + 1), 'label' => $s['badge'] ?: $s['heading']] : null)->filter()
        )->values();
    ?>

    
    <?php if($nav->count() > 1): ?>
        <div x-data="sectionNav" class="sticky top-20 z-20 border-b border-line bg-white/95 backdrop-blur-md">
            <div class="container-site flex items-center gap-4">
                <nav class="no-scrollbar -mx-1 flex min-w-0 flex-1 gap-1 overflow-x-auto py-2.5" aria-label="<?php echo e(__('On this page')); ?>" x-ref="links">
                    <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#<?php echo e($item['id']); ?>" data-target="<?php echo e($item['id']); ?>"
                           class="section-nav-link shrink-0 rounded-full px-4 py-2 text-[14px] font-semibold whitespace-nowrap"
                           :class="active === '<?php echo e($item['id']); ?>' && 'is-active'"
                           :aria-current="active === '<?php echo e($item['id']); ?>' ? 'true' : null"><?php echo e($item['label']); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>
                <div class="hidden shrink-0 items-center gap-4 sm:flex">
                    <?php if($p['from']): ?>
                        <p class="text-end leading-tight">
                            <span class="block text-[11px] font-semibold tracking-[0.12em] text-ink-3 uppercase"><?php echo e(__('Starting from')); ?></span>
                            <span class="font-display text-[1.25rem] font-semibold text-brand"><?php echo e(Money::html($p['from'])); ?></span>
                        </p>
                    <?php endif; ?>
                    <?php if($bookable): ?>
                        <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => route('bookings.create', $package->slug),'variant' => 'gold','size' => 'sm','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('bookings.create', $package->slug)),'variant' => 'gold','size' => 'sm','icon-right' => 'arrow-right']); ?><?php echo e(__('Book now')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if($p['types']): ?>
        <section id="prices" class="section-light relative isolate scroll-mt-36 overflow-clip bg-sand-50 py-16 sm:py-20 lg:py-24" x-data="{ tab: 0 }">
            <div class="pattern-star-ink pointer-events-none absolute -inset-y-[20%] inset-x-0 -z-10 opacity-[0.025]" data-parallax="0.15" aria-hidden="true"></div>
            <div class="container-site">
                <div class="mx-auto mb-12 max-w-2xl text-center" data-reveal>
                    <p class="eyebrow justify-center"><?php echo e(__('Prices & hotels')); ?></p>
                    <h2 class="mt-4 text-display-lg text-brand"><?php echo e(__('Choose the option that suits you')); ?></h2>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid gap-6 lg:gap-8', 'lg:grid-cols-[minmax(0,0.72fr)_minmax(0,1.28fr)]' => count($p['types']) > 1]); ?>">
                    <?php if(count($p['types']) > 1): ?>
                        <div role="tablist" aria-label="<?php echo e(__('Package types')); ?>" aria-orientation="vertical" class="flex flex-col gap-3 lg:sticky lg:top-40 lg:self-start"
                             @keydown.down.prevent="tab = (tab + 1) % <?php echo e(count($p['types'])); ?>; $nextTick(() => $el.querySelectorAll('[role=tab]')[tab].focus())"
                             @keydown.up.prevent="tab = (tab + <?php echo e(count($p['types']) - 1); ?>) % <?php echo e(count($p['types'])); ?>; $nextTick(() => $el.querySelectorAll('[role=tab]')[tab].focus())">
                            <?php $__currentLoopData = $p['types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $typeFrom = collect($type['prices'])->min('price');
                                ?>
                                <div class="flex flex-col" data-reveal style="--reveal-delay: <?php echo e($i * 100); ?>ms">
                                    <button type="button" role="tab" id="type-tab-<?php echo e($i); ?>" aria-controls="type-panel-<?php echo e($i); ?>"
                                            <?php if($i === 0): ?> aria-selected="true" <?php else: ?> aria-selected="false" tabindex="-1" <?php endif; ?>
                                            :aria-selected="(tab === <?php echo e($i); ?>).toString()" :tabindex="tab === <?php echo e($i); ?> ? 0 : -1"
                                            @click="tab = <?php echo e($i); ?>; if (window.innerWidth < 1024) window.scrollTo({ top: $el.closest('[role=tablist]').getBoundingClientRect().bottom + window.scrollY + 24 - 156, behavior: 'smooth' })"
                                            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['type-tab group/tab relative flex items-center gap-4 rounded-2xl border p-4 text-start sm:p-5', 'is-active' => $i === 0]); ?>"
                                            :class="{ 'is-active': tab === <?php echo e($i); ?> }">
                                        <span class="type-tab-num flex size-10 shrink-0 items-center justify-center rounded-full font-display text-[15px] font-semibold tabular-nums"><?php echo e(Money::digits(str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT))); ?></span>
                                        <span class="min-w-0 flex-1">
                                            <?php if($type['code']): ?><span class="type-tab-code block text-[11px] font-bold tracking-[0.14em] uppercase"><?php echo e($type['code']); ?></span><?php endif; ?>
                                            <span class="type-tab-name block font-display text-[1.125rem] leading-snug font-semibold"><?php echo e($type['name']); ?></span>
                                        </span>
                                        <?php if($typeFrom): ?>
                                            <span class="shrink-0 text-end">
                                                <span class="type-tab-from block text-[11px] font-semibold uppercase"><?php echo e(__('From')); ?></span>
                                                <span class="type-tab-price block font-display text-[1.125rem] leading-tight font-semibold"><?php echo e(Money::html($typeFrom)); ?></span>
                                            </span>
                                        <?php endif; ?>
                                    </button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <div class="min-w-0">
                        <?php $__currentLoopData = $p['types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div role="tabpanel" id="type-panel-<?php echo e($i); ?>" aria-labelledby="type-tab-<?php echo e($i); ?>" x-show="tab === <?php echo e($i); ?>" <?php if($i > 0): ?> x-cloak <?php endif; ?>
                                 x-transition:enter="transition duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]" x-transition:enter-start="opacity-0 translate-y-3"
                                 class="space-y-6">
                                <?php if(count($p['types']) === 1): ?>
                                    <h3 class="font-display text-display-sm text-brand" data-reveal><?php echo e($type['name']); ?></h3>
                                <?php endif; ?>

                                <?php $__currentLoopData = $type['prices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="option-card overflow-hidden rounded-[1.75rem] border border-line bg-white shadow-[var(--shadow-soft)]">
                                        <header class="flex flex-wrap items-end justify-between gap-x-6 gap-y-3 border-b border-line bg-gradient-to-br from-white to-sand-50 p-6 sm:p-8" data-reveal>
                                            <div class="min-w-0">
                                                
                                                <p class="flex flex-wrap items-center gap-x-3 gap-y-1.5">
                                                    <span class="text-[12px] font-semibold tracking-[0.14em] text-gold-deep uppercase"><?php echo e($type['name']); ?></span>
                                                    <?php if($type['description']): ?>
                                                        <span class="rounded-full bg-sand-100 px-3 py-1 text-[13px] font-medium text-ink-2"><?php echo e($type['description']); ?></span>
                                                    <?php endif; ?>
                                                </p>
                                                <h3 class="mt-1.5 font-display text-display-sm text-brand"><?php echo e($price['title']); ?></h3>
                                                <?php if($price['description']): ?><p class="mt-2 text-[15px] text-ink-2"><?php echo e($price['description']); ?></p><?php endif; ?>
                                            </div>
                                            <p class="text-end">
                                                <span class="block font-display text-[2.25rem] leading-none font-semibold text-brand"><?php echo e(Money::html($price['price'])); ?></span>
                                                <span class="mt-1 block text-[13px] text-ink-3"><?php echo e(PackagePresenter::unitLabel($price['unit'])); ?></span>
                                            </p>
                                        </header>

                                        <?php if($price['hotels']): ?>
                                            <div class="grid divide-y divide-line sm:grid-cols-2 sm:divide-x sm:divide-y-0 rtl:sm:divide-x-reverse">
                                                <?php $__currentLoopData = $price['hotels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h => $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="flex gap-4 bg-white p-6 sm:p-7" data-reveal style="--reveal-delay: <?php echo e(80 + $h * 120); ?>ms">
                                                        <span class="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-brand text-gold"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'hotel','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'hotel','class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                                        <div class="min-w-0">
                                                            <p class="text-[12px] font-semibold tracking-[0.14em] text-ink-3 uppercase"><?php echo e($hotel['heading']); ?></p>
                                                            <?php if($hotel['subheading']): ?><p class="mt-1 font-display text-[1.1875rem] leading-snug font-semibold text-brand"><?php echo e($hotel['subheading']); ?></p><?php endif; ?>
                                                            <?php if($hotel['description']): ?>
                                                                <p class="mt-2 flex gap-1.5 text-[14px] leading-relaxed text-ink-2">
                                                                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'map-pin','class' => 'mt-1 size-3.5 shrink-0 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'map-pin','class' => 'mt-1 size-3.5 shrink-0 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                                                    <span><?php echo e($hotel['description']); ?></span>
                                                                </p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endif; ?>

                                        <footer class="flex flex-col gap-3 border-t border-line p-6 sm:flex-row sm:items-center sm:p-7" data-reveal style="--reveal-delay: 150ms">
                                            <?php if($bookable): ?>
                                                <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => route('bookings.create', ['slug' => $package->slug, 'option' => $price['id']]),'variant' => 'primary','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('bookings.create', ['slug' => $package->slug, 'option' => $price['id']])),'variant' => 'primary','icon-right' => 'arrow-right']); ?><?php echo e(__('Book this option')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
                                            <?php else: ?>
                                                <span class="rounded-full bg-sand-100 px-5 py-3 text-center text-[14px] font-semibold text-ink-3"><?php echo e($booking['label']); ?></span>
                                            <?php endif; ?>
                                            <?php if($phones): ?>
                                                <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $phones[0]['href'],'variant' => 'outline','icon' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($phones[0]['href']),'variant' => 'outline','icon' => 'phone']); ?><?php echo e(__('Call')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
                                            <?php endif; ?>
                                            <?php if($whatsapp = $enquire($type['name'].' · '.$price['title'])): ?>
                                                <a href="<?php echo e($whatsapp); ?>" target="_blank" rel="noopener" class="inline-flex items-center gap-1.5 text-[14px] font-semibold text-[#15803d] hover:underline sm:ms-auto">
                                                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'whatsapp','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'whatsapp','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(__('Ask about this option')); ?>

                                                </a>
                                            <?php endif; ?>
                                        </footer>
                                    </article>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <p class="mx-auto mt-10 max-w-3xl text-center text-[13px] leading-relaxed text-ink-3" data-reveal><?php echo e(__('Prices may change if the Saudi government, airlines or exchange rates change their fees. Please pay only through our official channels.')); ?></p>
            </div>
        </section>
    <?php endif; ?>

    
    <?php if($p['flights']): ?>
        <section id="flights" class="section-dark relative isolate scroll-mt-36 overflow-hidden bg-brand-950 py-16 text-white sm:py-20 lg:py-24">
            <div class="pattern-star pointer-events-none absolute -inset-y-[25%] inset-x-0 -z-10 opacity-[0.05]" data-parallax="0.25" aria-hidden="true"></div>
            <div class="pointer-events-none absolute -top-32 -right-32 -z-10 size-[460px] rounded-full bg-gold/10 blur-3xl" data-parallax="-0.15" aria-hidden="true"></div>
            <div class="container-site grid items-center gap-10 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:gap-16">
                <div>
                    <div data-reveal>
                        <p class="eyebrow eyebrow-light"><?php echo e(__('Travel')); ?></p>
                        <h2 class="mt-4 text-display-lg text-white"><?php echo e(__('Flights')); ?></h2>
                    </div>
                    <dl class="mt-8 grid grid-cols-2 gap-4">
                        <?php if($p['duration']): ?>
                            <div class="rounded-2xl border border-white/10 bg-white/[0.05] p-5" data-reveal style="--reveal-delay: 80ms">
                                <dt class="text-[12px] font-semibold tracking-[0.14em] text-white/55 uppercase"><?php echo e(__('Duration')); ?></dt>
                                <dd class="mt-1 font-display text-2xl font-semibold text-gold" data-count><?php echo e(trans_choice(':count day|:count days', $p['duration'], ['count' => Money::digits($p['duration'])])); ?></dd>
                            </div>
                        <?php endif; ?>
                        <div class="rounded-2xl border border-white/10 bg-white/[0.05] p-5" data-reveal style="--reveal-delay: 180ms">
                            <dt class="text-[12px] font-semibold tracking-[0.14em] text-white/55 uppercase"><?php echo e(__('Booking')); ?></dt>
                            <dd class="mt-2 flex items-center gap-2 text-[15px] font-semibold text-white">
                                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['size-2.5 shrink-0 rounded-full', 'bg-emerald' => $bookable, 'bg-gold' => $booking['state'] === 'upcoming', 'bg-red-400' => $booking['state'] === 'closed']); ?>"></span>
                                <?php echo e($booking['label']); ?>

                            </dd>
                        </div>
                    </dl>
                </div>

                <div class="grid gap-5">
                    <?php $__currentLoopData = $p['flights']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="flight-card relative overflow-hidden rounded-[1.75rem] border border-white/10 bg-white/[0.06] p-7 sm:p-9">
                            <div class="flex items-start gap-5" data-reveal>
                                <span class="flex size-14 shrink-0 items-center justify-center rounded-full bg-gold text-brand-950"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'plane','class' => 'size-7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plane','class' => 'size-7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                <div class="min-w-0">
                                    <h3 class="font-display text-display-sm text-white"><?php echo e($flight['airline']); ?></h3>
                                    <?php if($flight['schedule']): ?><p class="mt-1.5 text-[15px] font-semibold text-gold"><?php echo e($flight['schedule']); ?></p><?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="flight-route relative mt-7 h-px bg-white/15" aria-hidden="true" data-reveal style="--reveal-delay: 120ms">
                                <span class="absolute -top-1 left-0 size-2 rounded-full bg-gold"></span>
                                <span class="absolute -top-1 right-0 size-2 rounded-full bg-gold"></span>
                                <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'plane','class' => 'flight-plane absolute -top-2.5 size-5 text-gold rtl:-scale-x-100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plane','class' => 'flight-plane absolute -top-2.5 size-5 text-gold rtl:-scale-x-100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                            </div>
                            <?php if($flight['description']): ?><p class="mt-6 text-[15px] leading-relaxed whitespace-pre-line text-white/75" data-reveal style="--reveal-delay: 200ms"><?php echo e($flight['description']); ?></p><?php endif; ?>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    
    <?php $__currentLoopData = $p['sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('site.packages.section', ['s' => $s, 'index' => $index], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($related->isNotEmpty()): ?>
        <section class="relative isolate overflow-hidden bg-sand-100 py-16 sm:py-20 lg:py-24">
            <div class="container-site">
                <div class="mx-auto mb-12 max-w-2xl text-center" data-reveal>
                    <p class="eyebrow justify-center"><?php echo e($p['service']->getTranslation('name', $locale)); ?></p>
                    <h2 class="mt-4 text-display-lg text-brand"><?php echo e(__('You may also like')); ?></h2>
                </div>
                <div class="mx-auto grid max-w-6xl gap-8">
                    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal897f6239282c9c8b6123196ed596e8ff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal897f6239282c9c8b6123196ed596e8ff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.package-feature','data' => ['package' => $item,'card' => $relatedCards[$item->id]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.package-feature'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['package' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item),'card' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($relatedCards[$item->id])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal897f6239282c9c8b6123196ed596e8ff)): ?>
<?php $attributes = $__attributesOriginal897f6239282c9c8b6123196ed596e8ff; ?>
<?php unset($__attributesOriginal897f6239282c9c8b6123196ed596e8ff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal897f6239282c9c8b6123196ed596e8ff)): ?>
<?php $component = $__componentOriginal897f6239282c9c8b6123196ed596e8ff; ?>
<?php unset($__componentOriginal897f6239282c9c8b6123196ed596e8ff); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-10 text-center" data-reveal>
                    <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $p['service']->url(),'variant' => 'outline','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p['service']->url()),'variant' => 'outline','icon-right' => 'arrow-right']); ?><?php echo e(__('All :service packages', ['service' => $p['service']->getTranslation('name', $locale)])); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $attributes = $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $component = $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/packages/show.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'solid']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'solid']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php $site = app(App\Support\SiteContext::class); ?>
<?php $branding = app(App\Support\Branding::class); ?>
<?php ($phones = $site->phones()); ?>

<header class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'relative z-30',
    'border-b border-line/70 bg-white' => $variant !== 'overlay',
    '-mb-20 bg-transparent' => $variant === 'overlay',
]); ?>">
    <div class="container-site flex h-20 items-center justify-between gap-4">
        <a href="<?php echo e(url('/')); ?>" aria-label="<?php echo e($site->name()); ?>">
            <img src="<?php echo e($branding->logoUrl()); ?>" srcset="<?php echo e($branding->logoSrcset()); ?>" sizes="160px" alt="<?php echo e($site->name()); ?>" width="160" height="54" class="h-auto w-[140px] sm:w-[160px]">
        </a>
        <div class="flex items-center gap-3">
            <?php if(count($languages = $site->languages()) > 1): ?>
                <?php if (isset($component)) { $__componentOriginal35c1a2b72111dcb1d789219322a7ccd3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.language-switcher','data' => ['languages' => $languages,'tone' => $variant === 'overlay' ? 'dark' : 'light']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.language-switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['languages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($languages),'tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($variant === 'overlay' ? 'dark' : 'light')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3)): ?>
<?php $attributes = $__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3; ?>
<?php unset($__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35c1a2b72111dcb1d789219322a7ccd3)): ?>
<?php $component = $__componentOriginal35c1a2b72111dcb1d789219322a7ccd3; ?>
<?php unset($__componentOriginal35c1a2b72111dcb1d789219322a7ccd3); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if($phones): ?>
                <a href="<?php echo e($phones[0]['href']); ?>" class="btn btn-gold btn-sm">
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    <span class="hidden sm:inline"><?php echo e($phones[0]['display']); ?></span>
                </a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/focused-header.blade.php ENDPATH**/ ?>
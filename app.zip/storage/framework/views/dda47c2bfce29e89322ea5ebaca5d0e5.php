
<?php if($listingView): ?>
    <?php echo $__env->make($listingView, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/page-listing.blade.php ENDPATH**/ ?>
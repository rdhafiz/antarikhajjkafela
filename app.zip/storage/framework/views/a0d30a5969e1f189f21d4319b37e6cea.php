<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    /** "solid" (default) or "overlay": transparent header on top of a dark hero. */
    'header' => 'solid',
    /** Focused landing layout for campaigns: slim header and footer, no menus. */
    'focused' => false,
    /** Extra tracking IDs for this page (campaigns): gtm_id, facebook_pixel_id. */
    'tracking' => [],
    /** Load analytics and ad tags. Off on private pages such as a customer's booking. */
    'analytics' => true,
    /** Show the footer's call-to-action band (hidden when the page already ends with one). */
    'footerCta' => true,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    /** "solid" (default) or "overlay": transparent header on top of a dark hero. */
    'header' => 'solid',
    /** Focused landing layout for campaigns: slim header and footer, no menus. */
    'focused' => false,
    /** Extra tracking IDs for this page (campaigns): gtm_id, facebook_pixel_id. */
    'tracking' => [],
    /** Load analytics and ad tags. Off on private pages such as a customer's booking. */
    'analytics' => true,
    /** Show the footer's call-to-action band (hidden when the page already ends with one). */
    'footerCta' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php ($locale = app()->getLocale()); ?>
<!DOCTYPE html>
<html lang="<?php echo e($locale); ?>" dir="<?php echo e(collect(app(App\Support\Locales::class)->available())->get($locale)['dir'] ?? 'ltr'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">

    <?php if (isset($component)) { $__componentOriginal6a23c0d7c8123e94844822bdf09b6f6f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a23c0d7c8123e94844822bdf09b6f6f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.seo-head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.seo-head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a23c0d7c8123e94844822bdf09b6f6f)): ?>
<?php $attributes = $__attributesOriginal6a23c0d7c8123e94844822bdf09b6f6f; ?>
<?php unset($__attributesOriginal6a23c0d7c8123e94844822bdf09b6f6f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a23c0d7c8123e94844822bdf09b6f6f)): ?>
<?php $component = $__componentOriginal6a23c0d7c8123e94844822bdf09b6f6f; ?>
<?php unset($__componentOriginal6a23c0d7c8123e94844822bdf09b6f6f); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc00bf6e4d161d4f389bfac1a024349f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc00bf6e4d161d4f389bfac1a024349f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.brand-head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.brand-head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc00bf6e4d161d4f389bfac1a024349f9)): ?>
<?php $attributes = $__attributesOriginalc00bf6e4d161d4f389bfac1a024349f9; ?>
<?php unset($__attributesOriginalc00bf6e4d161d4f389bfac1a024349f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc00bf6e4d161d4f389bfac1a024349f9)): ?>
<?php $component = $__componentOriginalc00bf6e4d161d4f389bfac1a024349f9; ?>
<?php unset($__componentOriginalc00bf6e4d161d4f389bfac1a024349f9); ?>
<?php endif; ?>

    <?php $__currentLoopData = $locale === 'bn' ? ['noto-sans-bengali-bengali-400-700'] : ['plus-jakarta-sans-latin-400', 'fraunces-latin-600']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="preload" as="font" type="font/woff2" href="<?php echo e(Vite::asset("resources/fonts/{$font}.woff2")); ?>" crossorigin>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php if($analytics): ?>
        <?php if (isset($component)) { $__componentOriginal9a111cc347272ac5711eae0638cb7d7f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9a111cc347272ac5711eae0638cb7d7f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.tracking','data' => ['position' => 'head','extra' => $tracking]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.tracking'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['position' => 'head','extra' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tracking)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9a111cc347272ac5711eae0638cb7d7f)): ?>
<?php $attributes = $__attributesOriginal9a111cc347272ac5711eae0638cb7d7f; ?>
<?php unset($__attributesOriginal9a111cc347272ac5711eae0638cb7d7f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a111cc347272ac5711eae0638cb7d7f)): ?>
<?php $component = $__componentOriginal9a111cc347272ac5711eae0638cb7d7f; ?>
<?php unset($__componentOriginal9a111cc347272ac5711eae0638cb7d7f); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php echo e($head ?? ''); ?>

</head>
<body class="min-h-dvh">
    <?php if($analytics): ?>
        <?php if (isset($component)) { $__componentOriginal9a111cc347272ac5711eae0638cb7d7f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9a111cc347272ac5711eae0638cb7d7f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.tracking','data' => ['position' => 'body','extra' => $tracking]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.tracking'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['position' => 'body','extra' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tracking)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9a111cc347272ac5711eae0638cb7d7f)): ?>
<?php $attributes = $__attributesOriginal9a111cc347272ac5711eae0638cb7d7f; ?>
<?php unset($__attributesOriginal9a111cc347272ac5711eae0638cb7d7f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a111cc347272ac5711eae0638cb7d7f)): ?>
<?php $component = $__componentOriginal9a111cc347272ac5711eae0638cb7d7f; ?>
<?php unset($__componentOriginal9a111cc347272ac5711eae0638cb7d7f); ?>
<?php endif; ?>
    <?php endif; ?>

    <a href="#main" class="sr-only z-[100] rounded-full bg-gold px-5 py-2.5 font-semibold text-brand-950 focus:not-sr-only focus:fixed focus:top-3 focus:left-3">
        <?php echo e(__('Skip to content')); ?>

    </a>

    <?php if($focused): ?>
        <?php if (isset($component)) { $__componentOriginal05900b50aa389018d38faac6d6d939ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal05900b50aa389018d38faac6d6d939ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.focused-header','data' => ['variant' => $header]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.focused-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($header)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal05900b50aa389018d38faac6d6d939ac)): ?>
<?php $attributes = $__attributesOriginal05900b50aa389018d38faac6d6d939ac; ?>
<?php unset($__attributesOriginal05900b50aa389018d38faac6d6d939ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05900b50aa389018d38faac6d6d939ac)): ?>
<?php $component = $__componentOriginal05900b50aa389018d38faac6d6d939ac; ?>
<?php unset($__componentOriginal05900b50aa389018d38faac6d6d939ac); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginale7973a0cd111432859375f720ac31db5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7973a0cd111432859375f720ac31db5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.header','data' => ['variant' => $header]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($header)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7973a0cd111432859375f720ac31db5)): ?>
<?php $attributes = $__attributesOriginale7973a0cd111432859375f720ac31db5; ?>
<?php unset($__attributesOriginale7973a0cd111432859375f720ac31db5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7973a0cd111432859375f720ac31db5)): ?>
<?php $component = $__componentOriginale7973a0cd111432859375f720ac31db5; ?>
<?php unset($__componentOriginale7973a0cd111432859375f720ac31db5); ?>
<?php endif; ?>
    <?php endif; ?>

    <main id="main" tabindex="-1" class="outline-none">
        <?php echo e($slot); ?>

    </main>

    <?php if($focused): ?>
        <?php if (isset($component)) { $__componentOriginale2d840e1e3e23cca5781e38e0b8999fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2d840e1e3e23cca5781e38e0b8999fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.focused-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.focused-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2d840e1e3e23cca5781e38e0b8999fc)): ?>
<?php $attributes = $__attributesOriginale2d840e1e3e23cca5781e38e0b8999fc; ?>
<?php unset($__attributesOriginale2d840e1e3e23cca5781e38e0b8999fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2d840e1e3e23cca5781e38e0b8999fc)): ?>
<?php $component = $__componentOriginale2d840e1e3e23cca5781e38e0b8999fc; ?>
<?php unset($__componentOriginale2d840e1e3e23cca5781e38e0b8999fc); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginal21120ef38d90a9d572330a5268a23b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21120ef38d90a9d572330a5268a23b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.footer','data' => ['cta' => $footerCta]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['cta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($footerCta)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21120ef38d90a9d572330a5268a23b04)): ?>
<?php $attributes = $__attributesOriginal21120ef38d90a9d572330a5268a23b04; ?>
<?php unset($__attributesOriginal21120ef38d90a9d572330a5268a23b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21120ef38d90a9d572330a5268a23b04)): ?>
<?php $component = $__componentOriginal21120ef38d90a9d572330a5268a23b04; ?>
<?php unset($__componentOriginal21120ef38d90a9d572330a5268a23b04); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginaldc17c4245d97611e90f50b817f2ee996 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc17c4245d97611e90f50b817f2ee996 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.whatsapp-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.whatsapp-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc17c4245d97611e90f50b817f2ee996)): ?>
<?php $attributes = $__attributesOriginaldc17c4245d97611e90f50b817f2ee996; ?>
<?php unset($__attributesOriginaldc17c4245d97611e90f50b817f2ee996); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc17c4245d97611e90f50b817f2ee996)): ?>
<?php $component = $__componentOriginaldc17c4245d97611e90f50b817f2ee996; ?>
<?php unset($__componentOriginaldc17c4245d97611e90f50b817f2ee996); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/layout.blade.php ENDPATH**/ ?>
<?php $site = app(App\Support\SiteContext::class); ?>
<?php
    use App\Support\Money;

    $items = array_values(array_filter($c['items'] ?? [], fn ($i) => filled($i['question'])));
    $split = ($c['layout'] ?? 'split') === 'split';
    $dark = $style['tone'] === 'dark';
    $phone = $site->phones()[0] ?? null;
    $whatsapp = $site->whatsappUrl();
    $uid = 'faq-'.$section->id;
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid items-start gap-10', 'lg:grid-cols-[minmax(0,0.75fr)_minmax(0,1.25fr)] lg:gap-16' => $split]); ?>">
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['lg:sticky lg:top-28' => $split]); ?>">
            <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'align' => $split ? 'left' : 'center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($split ? 'left' : 'center')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>

            
            <?php if($split && ($phone || $whatsapp || $c['cta'])): ?>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'relative isolate mt-8 hidden overflow-hidden rounded-[1.75rem] p-7 text-white lg:block',
                    'bg-brand-950' => ! $dark,
                    'border border-white/10 bg-white/[0.06]' => $dark,
                ]); ?>" data-reveal>
                    <div class="pattern-star absolute inset-0 -z-10 opacity-[0.07]" aria-hidden="true"></div>
                    <div class="absolute -top-24 -right-24 -z-10 size-64 rounded-full bg-gold/15 blur-3xl" aria-hidden="true"></div>
                    <p class="font-display text-[1.375rem] leading-snug font-semibold"><?php echo e(__('Still have a question?')); ?></p>
                    <p class="mt-2 text-[15px] leading-relaxed text-white/70"><?php echo e(__('Talk to our team by phone or WhatsApp.')); ?></p>
                    <div class="mt-6 flex flex-wrap gap-3">
                        <?php if($phone): ?>
                            <a href="<?php echo e($phone['href']); ?>" class="btn btn-outline-light">
                                <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                <span dir="ltr"><?php echo e($phone['display']); ?></span>
                            </a>
                        <?php endif; ?>
                        <?php if($whatsapp): ?>
                            <a href="<?php echo e($whatsapp); ?>" target="_blank" rel="noopener" class="btn btn-whatsapp">
                                <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'whatsapp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'whatsapp']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                WhatsApp
                            </a>
                        <?php endif; ?>
                    </div>
                    <?php if($c['cta']): ?>
                        <a href="<?php echo e($c['cta']['url']); ?>" <?php if($c['cta']['external']): ?> target="_blank" rel="noopener" <?php endif; ?> class="group mt-6 inline-flex items-center gap-1.5 text-[14px] font-semibold text-gold">
                            <?php echo e($c['cta']['label']); ?>

                            <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'size-4 transition-[translate] duration-500 group-hover:translate-x-1 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'size-4 transition-[translate] duration-500 group-hover:translate-x-1 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['grid gap-3', 'mx-auto w-full max-w-3xl' => ! $split]); ?>" x-data="{ open: 0 }" data-reveal>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['faq-item', 'is-open' => $index === 0]); ?>" :class="{ 'is-open': open === <?php echo e($index); ?> }">
                    <h3>
                        <button
                            type="button"
                            id="<?php echo e($uid); ?>-q-<?php echo e($index); ?>"
                            class="faq-question grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 p-4 text-start sm:gap-4 sm:p-5 sm:px-6"
                            @click="open = open === <?php echo e($index); ?> ? null : <?php echo e($index); ?>"
                            aria-expanded="<?php echo e($index === 0 ? 'true' : 'false'); ?>"
                            :aria-expanded="(open === <?php echo e($index); ?>).toString()"
                            aria-controls="<?php echo e($uid); ?>-a-<?php echo e($index); ?>"
                        >
                            <span class="faq-num w-6 font-display sm:w-7 text-[15px] font-semibold tabular-nums" aria-hidden="true"><?php echo e(Money::digits(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT))); ?></span>
                            <span class="sec-heading font-sans text-[1rem] leading-snug sm:text-[1.0625rem] font-semibold text-pretty"><?php echo e($item['question']); ?></span>
                            <span class="faq-toggle" aria-hidden="true"><span></span><span></span></span>
                        </button>
                    </h3>
                    <div id="<?php echo e($uid); ?>-a-<?php echo e($index); ?>" role="region" aria-labelledby="<?php echo e($uid); ?>-q-<?php echo e($index); ?>" x-show="open === <?php echo e($index); ?>" x-collapse <?php if($index !== 0): ?> x-cloak <?php endif; ?>>
                        <div class="faq-answer prose-site px-4 pb-5 sm:px-5 sm:pb-6 text-[1rem] sm:ps-[4.25rem] sm:pe-16"><?php echo $item['answer']; ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php if($c['cta']): ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-10 text-center', 'lg:hidden' => $split]); ?>">
            <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['cta'],'variant' => $dark ? 'gold' : 'primary','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['cta']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dark ? 'gold' : 'primary'),'icon-right' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/faq.blade.php ENDPATH**/ ?>
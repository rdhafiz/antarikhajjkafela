<?php $site = app(App\Support\SiteContext::class); ?>
<?php
    $phones = $site->phones();
    $whatsapp = $site->whatsappUrl();
?>
<div class="flex flex-col flex-wrap gap-3 sm:flex-row">
    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['primary'] ?? null,'variant' => $onDark ? 'gold' : 'primary','size' => 'lg','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['primary'] ?? null),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($onDark ? 'gold' : 'primary'),'size' => 'lg','icon-right' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['secondary'] ?? null,'variant' => $onDark ? 'outline-light' : 'outline','size' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['secondary'] ?? null),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($onDark ? 'outline-light' : 'outline'),'size' => 'lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
    <?php if($c['contact_buttons'] ?? false): ?>
        <?php if($phones): ?>
            <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $phones[0]['href'],'variant' => ($c['primary'] ?? null) ? ($onDark ? 'outline-light' : 'outline') : 'gold','size' => 'lg','icon' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($phones[0]['href']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($c['primary'] ?? null) ? ($onDark ? 'outline-light' : 'outline') : 'gold'),'size' => 'lg','icon' => 'phone']); ?><?php echo e($phones[0]['display']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($whatsapp): ?>
            <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $whatsapp,'variant' => 'whatsapp','size' => 'lg','icon' => 'whatsapp','external' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($whatsapp),'variant' => 'whatsapp','size' => 'lg','icon' => 'whatsapp','external' => true]); ?>WhatsApp <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/partials/cta-buttons.blade.php ENDPATH**/ ?>
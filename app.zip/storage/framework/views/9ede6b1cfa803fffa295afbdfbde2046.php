<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['rating']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['rating']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<span <?php echo e($attributes->class('inline-flex items-center gap-0.5')); ?> role="img" aria-label="<?php echo e(__(':rating out of 5 stars', ['rating' => App\Support\Money::digits($rating)])); ?>">
    <?php for($i = 1; $i <= 5; $i++): ?>
        <svg viewBox="0 0 24 24" aria-hidden="true" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['size-4', 'text-gold' => $i <= $rating, 'text-ink-3/25' => $i > $rating]); ?>">
            <path fill="currentColor" d="m12 2.8 2.8 5.8 6.3.9-4.6 4.4 1.1 6.3L12 17.2l-5.6 3 1.1-6.3L2.9 9.5l6.3-.9z"/>
        </svg>
    <?php endfor; ?>
</span>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/stars.blade.php ENDPATH**/ ?>

<div class="space-y-6">
    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php switch($block['type']):
            case ('text'): ?>
                <div class="prose-site"><?php echo $block['body']; ?></div>
                <?php break; ?>

            <?php case ('table'): ?>
                <figure class="overflow-x-auto rounded-2xl border border-[var(--sec-border,var(--color-line))]">
                    <table class="w-full min-w-[480px] text-left text-[15px]">
                        <?php $__currentLoopData = $block['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowIndex => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rowIndex === 0 && $block['header']): ?>
                                <thead>
                                    <tr class="bg-brand text-white">
                                        <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th scope="col" class="px-4 py-3 font-semibold"><?php echo e($cell); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                            <?php else: ?>
                                <?php if($rowIndex === 0): ?><tbody><?php endif; ?>
                                <tr class="border-t border-[var(--sec-border,var(--color-line))] odd:bg-[var(--sec-surface-2,var(--color-sand-50))]">
                                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cellIndex => $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="<?php echo \Illuminate\Support\Arr::toCssClasses(['px-4 py-3', 'sec-heading font-semibold' => $cellIndex === 0, 'sec-text' => $cellIndex > 0]); ?>"><?php echo e($cell); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if(filled($block['caption'])): ?><figcaption class="sec-muted border-t border-[var(--sec-border,var(--color-line))] px-4 py-2.5 text-[13px]"><?php echo e($block['caption']); ?></figcaption><?php endif; ?>
                </figure>
                <?php break; ?>

            <?php case ('list'): ?>
                <?php if($block['style'] === 'number'): ?>
                    <ol class="space-y-3">
                        <?php $__currentLoopData = $block['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex gap-3.5">
                                <span class="flex size-7 shrink-0 items-center justify-center rounded-full bg-gold text-[13px] font-bold text-brand-950"><?php echo e(App\Support\Money::digits($i + 1)); ?></span>
                                <span class="sec-text pt-0.5"><?php echo e($item); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                <?php else: ?>
                    <ul class="grid gap-3 sm:grid-cols-2">
                        <?php $__currentLoopData = $block['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex gap-3">
                                <?php if($block['style'] === 'check'): ?>
                                    <span class="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-emerald text-white"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
                                <?php else: ?>
                                    <span class="mt-2.5 size-2 shrink-0 rotate-45 bg-gold" aria-hidden="true"></span>
                                <?php endif; ?>
                                <span class="sec-text"><?php echo e($item); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
                <?php break; ?>

            <?php case ('image'): ?>
                <figure>
                    <img
                        src="<?php echo e($block['image']->url('md')); ?>"
                        srcset="<?php echo e($block['image']->srcset()); ?>"
                        sizes="(min-width: 1024px) 760px, 100vw"
                        alt="<?php echo e($block['image']->getTranslation('alt', app()->getLocale()) ?: $block['caption']); ?>"
                        loading="lazy"
                        decoding="async"
                        class="w-full rounded-2xl object-cover"
                    >
                    <?php if(filled($block['caption'])): ?><figcaption class="sec-muted mt-2.5 text-center text-[13px]"><?php echo e($block['caption']); ?></figcaption><?php endif; ?>
                </figure>
                <?php break; ?>

            <?php case ('video'): ?>
                <?php (preg_match('#(?:v=|embed/|shorts/|youtu\.be/)([\w-]{6,})#', $block['url'], $m)); ?>
                <?php if($m[1] ?? null): ?>
                    <figure x-data="{ playing: false }">
                        <div class="relative aspect-video overflow-hidden rounded-2xl bg-brand-950">
                            <template x-if="playing">
                                <iframe class="absolute inset-0 size-full" src="https://www.youtube-nocookie.com/embed/<?php echo e($m[1]); ?>?autoplay=1&rel=0" title="<?php echo e($block['caption'] ?: __('Video')); ?>" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>
                            </template>
                            <button type="button" x-show="!playing" @click="playing = true" class="group absolute inset-0 size-full" aria-label="<?php echo e(__('Play video')); ?>">
                                <img src="https://i.ytimg.com/vi/<?php echo e($m[1]); ?>/hqdefault.jpg" alt="" loading="lazy" class="absolute inset-0 size-full object-cover opacity-85">
                                <span class="absolute top-1/2 left-1/2 flex size-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-gold text-brand-950 shadow-xl transition-transform group-hover:scale-110">
                                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'play','class' => 'ml-1 size-7 fill-current']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','class' => 'ml-1 size-7 fill-current']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                </span>
                            </button>
                        </div>
                        <?php if(filled($block['caption'])): ?><figcaption class="sec-muted mt-2.5 text-center text-[13px]"><?php echo e($block['caption']); ?></figcaption><?php endif; ?>
                    </figure>
                <?php endif; ?>
                <?php break; ?>
        <?php endswitch; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/partials/content-blocks.blade.php ENDPATH**/ ?>
<?php
    $magazine = ($c['layout'] ?? 'grid') === 'magazine' && $posts->count() >= 2;
?>
<?php if($posts->isNotEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
        <?php if($magazine): ?>
            <?php
                $lead = $posts->first();
                $rest = $posts->skip(1)->values();
                $dark = $style['tone'] === 'dark';
                $locale = app()->getLocale();
                $leadMinutes = app(App\Domain\Blog\PostPresenter::class)->minutes($lead);
            ?>
            
            <div class="mb-10 flex flex-col gap-6 border-b border-[var(--sec-border)] pb-8 lg:flex-row lg:items-end lg:justify-between" data-reveal>
                <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'align' => 'left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
                <?php if($c['cta']): ?>
                    <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['cta'],'variant' => $dark ? 'gold' : 'outline','iconRight' => 'arrow-right','class' => 'hidden shrink-0 lg:inline-flex']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['cta']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dark ? 'gold' : 'outline'),'icon-right' => 'arrow-right','class' => 'hidden shrink-0 lg:inline-flex']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="grid gap-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)] lg:gap-12">
                <article class="news-lead group relative isolate flex min-h-[26rem] flex-col justify-end overflow-hidden rounded-[1.75rem] bg-brand-950 text-white sm:min-h-[30rem]" data-reveal="scale">
                    <?php if($lead->banner): ?>
                        <img
                            src="<?php echo e($lead->banner->url('md')); ?>"
                            srcset="<?php echo e($lead->banner->srcset()); ?>"
                            sizes="(min-width: 1024px) 680px, 100vw"
                            alt="" loading="lazy" decoding="async"
                            class="news-lead-img absolute inset-0 -z-20 size-full object-cover"
                        >
                    <?php else: ?>
                        <div class="pattern-star absolute inset-0 -z-20 opacity-[0.08]" aria-hidden="true"></div>
                    <?php endif; ?>
                    <div class="absolute inset-0 -z-10 bg-gradient-to-t from-brand-950 via-brand-950/70 to-brand-950/5" aria-hidden="true"></div>

                    <div class="p-7 sm:p-10">
                        <p class="flex flex-wrap items-center gap-x-3 gap-y-2 text-[13px] font-medium text-white/80">
                            <?php if($lead->category): ?>
                                <span class="rounded-full bg-gold px-3 py-1 text-[12px] font-semibold text-brand-950"><?php echo e($lead->category->getTranslation('name', $locale)); ?></span>
                            <?php endif; ?>
                            <time datetime="<?php echo e($lead->published_at?->toDateString()); ?>"><?php echo e(App\Domain\Blog\PostPresenter::date($lead->published_at)); ?></time>
                            <span class="size-1 rounded-full bg-gold" aria-hidden="true"></span>
                            <span><?php echo e(trans_choice(':count min read|:count min read', $leadMinutes, ['count' => App\Support\Money::digits($leadMinutes)])); ?></span>
                        </p>
                        <h3 class="mt-4 max-w-xl font-display text-display-md text-white">
                            <a href="<?php echo e($lead->url()); ?>" class="after:absolute after:inset-0 focus-visible:outline-none"><?php echo e($lead->getTranslation('title', $locale)); ?></a>
                        </h3>
                        <?php if(filled($excerpt = $lead->getTranslation('excerpt', $locale))): ?>
                            <p class="mt-3 line-clamp-2 max-w-lg text-[1rem] leading-relaxed text-white/75"><?php echo e($excerpt); ?></p>
                        <?php endif; ?>
                        <span class="mt-6 inline-flex items-center gap-2 text-[14px] font-semibold text-gold">
                            <?php echo e(__('Read article')); ?>

                            <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'size-4 transition-[translate] duration-500 group-hover:translate-x-1 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'size-4 transition-[translate] duration-500 group-hover:translate-x-1 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                        </span>
                    </div>
                </article>

                <ol class="flex flex-col" data-reveal>
                    <?php $__currentLoopData = $rest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="news-row group relative grid grid-cols-[6.5rem_minmax(0,1fr)] items-center gap-5 border-b border-[var(--sec-border)] py-5 first:pt-0 last:border-b-0 sm:grid-cols-[8.5rem_minmax(0,1fr)] lg:flex-1">
                            <div class="relative aspect-square overflow-hidden rounded-2xl bg-brand sm:aspect-[4/3]">
                                <?php if($post->banner): ?>
                                    <img src="<?php echo e($post->banner->url('sm')); ?>" alt="" loading="lazy" decoding="async" class="news-row-img size-full object-cover">
                                <?php else: ?>
                                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'book','class' => 'absolute top-1/2 left-1/2 size-8 -translate-x-1/2 -translate-y-1/2 text-gold/70']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book','class' => 'absolute top-1/2 left-1/2 size-8 -translate-x-1/2 -translate-y-1/2 text-gold/70']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="min-w-0">
                                <p class="sec-muted flex flex-wrap items-center gap-x-2.5 text-[12.5px] font-medium">
                                    <?php if($post->category): ?>
                                        <span class="font-semibold text-[var(--sec-eyebrow,var(--color-gold-deep))]"><?php echo e($post->category->getTranslation('name', $locale)); ?></span>
                                        <span class="size-1 rounded-full bg-gold" aria-hidden="true"></span>
                                    <?php endif; ?>
                                    <time datetime="<?php echo e($post->published_at?->toDateString()); ?>"><?php echo e(App\Domain\Blog\PostPresenter::date($post->published_at)); ?></time>
                                </p>
                                <h3 class="sec-heading mt-1.5 line-clamp-2 font-display text-[1.125rem] leading-[1.4] font-semibold sm:text-[1.25rem]">
                                    <a href="<?php echo e($post->url()); ?>" class="news-row-link after:absolute after:inset-0 focus-visible:outline-none"><?php echo e($post->getTranslation('title', $locale)); ?></a>
                                </h3>
                                <?php if(filled($excerpt = $post->getTranslation('excerpt', $locale))): ?>
                                    <p class="sec-text mt-1.5 line-clamp-1 hidden text-[14.5px] sm:block"><?php echo e($excerpt); ?></p>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'class' => 'mb-14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'class' => 'mb-14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'grid gap-6',
                'sm:grid-cols-2 lg:grid-cols-3' => $posts->count() >= 3,
                'mx-auto max-w-4xl sm:grid-cols-2' => $posts->count() === 2,
                'mx-auto max-w-md' => $posts->count() === 1,
            ]); ?>">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.post-card','data' => ['post' => $post,'dataReveal' => true,'style' => '--reveal-delay: '.(($index % 3) * 80).'ms']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.post-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post),'data-reveal' => true,'style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('--reveal-delay: '.(($index % 3) * 80).'ms')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a)): ?>
<?php $attributes = $__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a; ?>
<?php unset($__attributesOriginalb3c2ed3a0b35612e4078a0103d7d420a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a)): ?>
<?php $component = $__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a; ?>
<?php unset($__componentOriginalb3c2ed3a0b35612e4078a0103d7d420a); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if($c['cta']): ?>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-12 text-center', 'lg:hidden' => $magazine]); ?>">
                <?php if (isset($component)) { $__componentOriginal0456238bcdffa6b019b0919c504f80cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0456238bcdffa6b019b0919c504f80cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.link-button','data' => ['link' => $c['cta'],'variant' => $style['tone'] === 'dark' ? 'gold' : 'primary','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['cta']),'variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style['tone'] === 'dark' ? 'gold' : 'primary'),'icon-right' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $attributes = $__attributesOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__attributesOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0456238bcdffa6b019b0919c504f80cf)): ?>
<?php $component = $__componentOriginal0456238bcdffa6b019b0919c504f80cf; ?>
<?php unset($__componentOriginal0456238bcdffa6b019b0919c504f80cf); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/latest-posts.blade.php ENDPATH**/ ?>
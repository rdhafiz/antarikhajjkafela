<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id', 'title' => null, 'rounded' => 'rounded-2xl']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id', 'title' => null, 'rounded' => 'rounded-2xl']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div x-data="{ playing: false }" <?php echo e($attributes->class(['relative aspect-video overflow-hidden bg-brand-950', $rounded])); ?>>
    <template x-if="playing">
        <iframe class="absolute inset-0 size-full" src="https://www.youtube-nocookie.com/embed/<?php echo e($id); ?>?autoplay=1&rel=0" title="<?php echo e($title ?: __('Video')); ?>" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>
    </template>
    <button type="button" x-show="!playing" @click="playing = true" class="group absolute inset-0 size-full" aria-label="<?php echo e(__('Play video')); ?><?php echo e($title ? ': '.$title : ''); ?>">
        <img src="https://i.ytimg.com/vi/<?php echo e($id); ?>/hqdefault.jpg" alt="" loading="lazy" decoding="async" class="absolute inset-0 size-full object-cover opacity-90 transition-transform duration-700 group-hover:scale-[1.03]">
        <span class="absolute inset-0 bg-gradient-to-t from-brand-950/60 to-transparent"></span>
        <span class="absolute top-1/2 left-1/2 flex size-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-gold text-brand-950 shadow-xl transition-transform duration-300 group-hover:scale-110">
            <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'play','class' => 'ml-0.5 size-6 fill-current']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','class' => 'ml-0.5 size-6 fill-current']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
        </span>
    </button>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/youtube.blade.php ENDPATH**/ ?>
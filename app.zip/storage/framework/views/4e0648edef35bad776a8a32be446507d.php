<?php
    $members = array_values(array_filter($c['members'] ?? [], fn ($m) => filled($m['name'])));
    // Members per row on wide screens: all in one row up to five, then rows of four (three for six or nine).
    $perRow = count($members) <= 5 ? max(2, count($members)) : (count($members) % 3 === 0 && count($members) % 4 !== 0 ? 3 : 4);
    $width = [
        2 => 'lg:w-[calc(50%-0.75rem)]',
        3 => 'lg:w-[calc(33.333%-1rem)]',
        4 => 'lg:w-[calc(25%-1.125rem)]',
        5 => 'lg:w-[calc(20%-1.2rem)]',
    ][$perRow];
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'class' => 'mb-14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'class' => 'mb-14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>

    <ul class="flex flex-wrap justify-center gap-6">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="w-full sm:w-[calc(50%-0.75rem)] <?php echo e($width); ?>" data-reveal style="--reveal-delay: <?php echo e(($index % $perRow) * 80); ?>ms">
                <div class="sec-card group h-full overflow-hidden text-center transition-[translate,box-shadow] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1.5 hover:shadow-[var(--shadow-lift)]">
                <div class="relative bg-[var(--sec-surface-2)] px-8 pt-8">
                    <?php if($member['photo']): ?>
                        <img
                            src="<?php echo e($member['photo']->url('md')); ?>"
                            alt="<?php echo e($member['name']); ?>"
                            loading="lazy"
                            decoding="async"
                            width="320"
                            height="320"
                            class="mx-auto aspect-square w-full max-w-52 rounded-t-[999px] object-cover transition-[scale] duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]"
                        >
                    <?php else: ?>
                        
                        <div class="mx-auto aspect-square w-full max-w-52 overflow-hidden rounded-t-[999px]">
                            <?php if (isset($component)) { $__componentOriginal8f591d1bbdbdda770c76a3180877c040 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f591d1bbdbdda770c76a3180877c040 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.avatar-illustration','data' => ['variant' => $index,'class' => 'block size-full transition-[scale] duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.avatar-illustration'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($index),'class' => 'block size-full transition-[scale] duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f591d1bbdbdda770c76a3180877c040)): ?>
<?php $attributes = $__attributesOriginal8f591d1bbdbdda770c76a3180877c040; ?>
<?php unset($__attributesOriginal8f591d1bbdbdda770c76a3180877c040); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f591d1bbdbdda770c76a3180877c040)): ?>
<?php $component = $__componentOriginal8f591d1bbdbdda770c76a3180877c040; ?>
<?php unset($__componentOriginal8f591d1bbdbdda770c76a3180877c040); ?>
<?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="px-6 py-6">
                    <h3 class="sec-heading font-display text-[1.2rem] font-semibold"><?php echo e($member['name']); ?></h3>
                    <?php if(filled($member['role'])): ?><p class="mt-1 text-[14px] font-semibold text-gold-deep"><?php echo e($member['role']); ?></p><?php endif; ?>
                    <?php if(filled($member['bio'])): ?><p class="sec-text mt-3 text-[14px] leading-relaxed"><?php echo e($member['bio']); ?></p><?php endif; ?>
                </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/team.blade.php ENDPATH**/ ?>

<?php use App\Support\Money; ?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <?php if($reviews->isEmpty()): ?>
        <div class="mx-auto max-w-md py-10 text-center" data-reveal>
            <span class="sec-icon mx-auto"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'quote','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'quote','class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
            <p class="sec-heading mt-5 font-display text-display-sm"><?php echo e(__('Reviews coming soon')); ?></p>
        </div>
    <?php else: ?>
        <?php if($average): ?>
            <div class="mx-auto mb-14 flex max-w-xl flex-col items-center gap-3 text-center sm:flex-row sm:justify-center sm:gap-6 sm:text-left" data-reveal>
                <p class="sec-heading font-display text-[3.5rem] leading-none font-semibold" data-count><?php echo e(Money::digits(number_format($average, 1))); ?></p>
                <div>
                    <?php if (isset($component)) { $__componentOriginalbfd438c48abc74c4d441f9a756f44afc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfd438c48abc74c4d441f9a756f44afc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.stars','data' => ['rating' => (int) round($average),'class' => '[&_svg]:size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.stars'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute((int) round($average)),'class' => '[&_svg]:size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfd438c48abc74c4d441f9a756f44afc)): ?>
<?php $attributes = $__attributesOriginalbfd438c48abc74c4d441f9a756f44afc; ?>
<?php unset($__attributesOriginalbfd438c48abc74c4d441f9a756f44afc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfd438c48abc74c4d441f9a756f44afc)): ?>
<?php $component = $__componentOriginalbfd438c48abc74c4d441f9a756f44afc; ?>
<?php unset($__componentOriginalbfd438c48abc74c4d441f9a756f44afc); ?>
<?php endif; ?>
                    <p class="sec-text mt-1.5 text-[15px]"><?php echo e(trans_choice('Average of :count review|Average of :count reviews', $ratedCount, ['count' => Money::digits($ratedCount)])); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <?php if($videoReviews->isNotEmpty()): ?>
            <h2 class="sr-only"><?php echo e(__('Video reviews')); ?></h2>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-12 grid gap-6', 'sm:grid-cols-2' => $videoReviews->count() > 1, 'lg:grid-cols-3' => $videoReviews->count() > 2, 'mx-auto max-w-3xl' => $videoReviews->count() === 1]); ?>">
                <?php $__currentLoopData = $videoReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalad533f9c051dead466c979e382e27833 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad533f9c051dead466c979e382e27833 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.review-card','data' => ['review' => $review,'dataReveal' => true,'style' => '--reveal-delay: '.(($index % 3) * 80).'ms']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.review-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['review' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($review),'data-reveal' => true,'style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('--reveal-delay: '.(($index % 3) * 80).'ms')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad533f9c051dead466c979e382e27833)): ?>
<?php $attributes = $__attributesOriginalad533f9c051dead466c979e382e27833; ?>
<?php unset($__attributesOriginalad533f9c051dead466c979e382e27833); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad533f9c051dead466c979e382e27833)): ?>
<?php $component = $__componentOriginalad533f9c051dead466c979e382e27833; ?>
<?php unset($__componentOriginalad533f9c051dead466c979e382e27833); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php ($written = $textReviews->reject(fn ($r) => $videoReviews->contains($r))); ?>
        <?php if($written->isNotEmpty()): ?>
            <h2 class="sr-only"><?php echo e(__('Written reviews')); ?></h2>
            
            <div class="gap-6 sm:columns-2 lg:columns-3">
                <?php $__currentLoopData = $written; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalad533f9c051dead466c979e382e27833 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad533f9c051dead466c979e382e27833 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.review-card','data' => ['review' => $review,'withVideo' => false,'class' => 'mb-6 break-inside-avoid','dataReveal' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.review-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['review' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($review),'with-video' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'class' => 'mb-6 break-inside-avoid','data-reveal' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad533f9c051dead466c979e382e27833)): ?>
<?php $attributes = $__attributesOriginalad533f9c051dead466c979e382e27833; ?>
<?php unset($__attributesOriginalad533f9c051dead466c979e382e27833); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad533f9c051dead466c979e382e27833)): ?>
<?php $component = $__componentOriginalad533f9c051dead466c979e382e27833; ?>
<?php unset($__componentOriginalad533f9c051dead466c979e382e27833); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/reviews/listing.blade.php ENDPATH**/ ?>
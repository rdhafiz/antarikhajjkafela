<?php if(($c['layout'] ?? 'split') === 'concierge'): ?>
    <?php $site = app(App\Support\SiteContext::class); ?>
    <?php
        $phones = $site->phones();
        $emails = $site->emails();
        $whatsapp = $site->whatsappUrl();
        $address = $site->address();
        $map = $site->mapEmbedUrl();
        $locale = app()->getLocale();
        $headingTag = $first ? 'h1' : 'h2';

        // Each way to reach us as one row; rows that are not set are left out.
        $channels = array_values(array_filter([
            $phones ? ['icon' => 'phone', 'label' => __('Call us'), 'value' => collect($phones)->pluck('display')->implode(' · '), 'href' => $phones[0]['href'], 'ltr' => true] : null,
            $whatsapp ? ['icon' => 'whatsapp', 'label' => 'WhatsApp', 'value' => settings('contact.primary_whatsapp') ?: __('Chat on WhatsApp'), 'href' => $whatsapp, 'external' => true, 'ltr' => true] : null,
            $emails ? ['icon' => 'mail', 'label' => __('Email'), 'value' => $emails[0], 'href' => 'mailto:'.$emails[0], 'ltr' => true] : null,
            $address ? ['icon' => 'map-pin', 'label' => __('Visit our office'), 'value' => $address, 'href' => 'https://www.google.com/maps/search/?api=1&query='.rawurlencode($address), 'external' => true] : null,
        ]));
        $topics = [__('Hajj package'), __('Umrah package'), __('Visa'), __('Something else')];
    ?>
    <?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
        <div class="pointer-events-none absolute -top-40 -right-40 -z-10 size-[560px] rounded-full bg-gold/12 blur-3xl" data-parallax="-0.15" aria-hidden="true"></div>
        <div class="pattern-star-ink pointer-events-none absolute -inset-y-[20%] inset-x-0 -z-10 opacity-[0.025]" data-parallax="0.2" aria-hidden="true"></div>

        
        <div class="concierge mx-auto grid max-w-6xl overflow-hidden rounded-[2.25rem] bg-white shadow-[var(--shadow-lift)] ring-1 ring-line lg:grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)]">
            <div class="relative isolate flex flex-col overflow-hidden bg-brand-950 p-7 text-white sm:p-10 lg:p-12">
                <div class="pattern-star absolute inset-0 -z-10 opacity-[0.06]" aria-hidden="true"></div>
                <div class="concierge-orbit absolute -bottom-40 -left-40 -z-10 size-[26rem] rounded-full border-[28px] border-gold/[0.08]" aria-hidden="true"></div>

                <div data-reveal>
                    <?php if(filled($c['eyebrow'])): ?><p class="eyebrow eyebrow-light"><?php echo e($c['eyebrow']); ?></p><?php endif; ?>
                    <?php if(filled($c['title'])): ?>
                        <<?php echo e($headingTag); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-display-lg text-white', 'mt-4' => filled($c['eyebrow'])]); ?>"><?php echo e($c['title']); ?></<?php echo e($headingTag); ?>>
                    <?php endif; ?>
                    <?php if(filled($c['intro'])): ?><p class="mt-4 max-w-md text-[1.0625rem] leading-relaxed text-white/75"><?php echo e($c['intro']); ?></p><?php endif; ?>
                </div>

                <?php if($channels): ?>
                    <ul class="mt-9 space-y-3">
                        <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-reveal="left" style="--reveal-delay: <?php echo e(100 + $i * 90); ?>ms">
                                <a href="<?php echo e($channel['href']); ?>" <?php if(! empty($channel['external'])): ?> target="_blank" rel="noopener" <?php endif; ?>
                                   class="concierge-row group relative isolate flex items-center gap-4 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] p-4 sm:p-5">
                                    <span class="concierge-icon flex size-12 shrink-0 items-center justify-center rounded-xl">
                                        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => $channel['icon'],'class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($channel['icon']),'class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                    </span>
                                    <span class="min-w-0 flex-1">
                                        <span class="concierge-label block text-[12px] font-semibold tracking-[0.14em] uppercase"><?php echo e($channel['label']); ?></span>
                                        <span class="concierge-value mt-0.5 block font-semibold break-words" <?php if(! empty($channel['ltr'])): ?> dir="ltr" <?php endif; ?>><?php echo e($channel['value']); ?></span>
                                    </span>
                                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'arrow-right','class' => 'concierge-arrow size-5 shrink-0 rtl:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'concierge-arrow size-5 shrink-0 rtl:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>

                
                <div class="mt-auto flex flex-wrap items-center gap-x-5 gap-y-2 pt-9 text-[14px] text-white/70" data-reveal style="--reveal-delay: 200ms"
                     x-data="dhakaClock(<?php echo \Illuminate\Support\Js::from($locale === 'bn' ? 'bn-BD' : 'en-GB')->toHtml() ?>)">
                    <span class="flex items-center gap-2.5">
                        <span class="relative flex size-2.5" aria-hidden="true"><span class="concierge-ping absolute inset-0 rounded-full bg-emerald"></span><span class="relative size-2.5 rounded-full bg-emerald"></span></span>
                        <span><?php echo e(__('Dhaka time')); ?></span>
                        <time class="font-display text-[1.25rem] font-semibold text-white tabular-nums" x-text="time" :datetime="iso"></time>
                    </span>
                    <span class="text-white/55" x-text="day"></span>
                </div>
            </div>

            <div class="p-7 sm:p-10 lg:p-12" x-data="{ topic: null }">
                <div data-reveal>
                    <p class="font-display text-display-sm text-brand"><?php echo e(__('Send us a message')); ?></p>
                    <p class="mt-1.5 text-[15px] text-ink-2"><?php echo e(__('Leave your details and our team will call you, In Sha Allah.')); ?></p>
                </div>

                
                <div class="mt-6" data-reveal style="--reveal-delay: 80ms">
                    <p class="mb-2.5 text-[14px] font-semibold text-ink" id="topic-label-<?php echo e($section->id); ?>"><?php echo e(__('What is it about?')); ?></p>
                    <div class="flex flex-wrap gap-2" role="group" aria-labelledby="topic-label-<?php echo e($section->id); ?>">
                        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="concierge-chip rounded-full px-4 py-2 text-[14px] font-semibold"
                                    :class="topic === <?php echo \Illuminate\Support\Js::from($topic)->toHtml() ?> && 'is-active'" :aria-pressed="(topic === <?php echo \Illuminate\Support\Js::from($topic)->toHtml() ?>).toString()"
                                    @click="topic = <?php echo \Illuminate\Support\Js::from($topic)->toHtml() ?>; const f = document.getElementById('f-<?php echo e($section->id); ?>-subject'); if (f) f.value = topic"><?php echo e($topic); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="mt-7" data-reveal style="--reveal-delay: 140ms">
                    <?php if (isset($component)) { $__componentOriginal278a1e3ada932f630caf369b0e326277 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal278a1e3ada932f630caf369b0e326277 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.form-shell','data' => ['section' => $section,'submitLabel' => $c['submit_label'] ?: __('Send message'),'success' => $c['success'] ?: __('Thank you! We will contact you shortly.'),'plain' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.form-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section),'submit-label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['submit_label'] ?: __('Send message')),'success' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['success'] ?: __('Thank you! We will contact you shortly.')),'plain' => true]); ?>
                        <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'name', 'label' => __('Full name'), 'type' => 'text', 'required' => true, 'autocomplete' => 'name'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'phone', 'label' => __('Mobile number'), 'type' => 'tel', 'required' => true, 'autocomplete' => 'tel'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'email', 'label' => __('Email'), 'type' => 'email', 'required' => false, 'autocomplete' => 'email'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'subject', 'label' => __('Subject'), 'type' => 'text', 'required' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'message', 'label' => __('Message'), 'type' => 'textarea', 'required' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal278a1e3ada932f630caf369b0e326277)): ?>
<?php $attributes = $__attributesOriginal278a1e3ada932f630caf369b0e326277; ?>
<?php unset($__attributesOriginal278a1e3ada932f630caf369b0e326277); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal278a1e3ada932f630caf369b0e326277)): ?>
<?php $component = $__componentOriginal278a1e3ada932f630caf369b0e326277; ?>
<?php unset($__componentOriginal278a1e3ada932f630caf369b0e326277); ?>
<?php endif; ?>
                </div>
            </div>
        </div>

        <?php if($map): ?>
            <div class="mx-auto mt-8 max-w-6xl overflow-hidden rounded-[2rem] shadow-[var(--shadow-soft)] ring-1 ring-line" data-reveal>
                <iframe src="<?php echo e($map); ?>" title="<?php echo e(__('Office location on Google Maps')); ?>" class="h-[360px] w-full" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php else: ?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="grid items-start gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <?php if (isset($component)) { $__componentOriginale9f479952627ceb8ba3a264ab1e76163 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f479952627ceb8ba3a264ab1e76163 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block-heading','data' => ['c' => $c,'align' => 'left','class' => 'lg:sticky lg:top-28','as' => $first ? 'h1' : 'h2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['c' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c),'align' => 'left','class' => 'lg:sticky lg:top-28','as' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($first ? 'h1' : 'h2')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $attributes = $__attributesOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__attributesOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f479952627ceb8ba3a264ab1e76163)): ?>
<?php $component = $__componentOriginale9f479952627ceb8ba3a264ab1e76163; ?>
<?php unset($__componentOriginale9f479952627ceb8ba3a264ab1e76163); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal278a1e3ada932f630caf369b0e326277 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal278a1e3ada932f630caf369b0e326277 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.form-shell','data' => ['section' => $section,'submitLabel' => $c['submit_label'] ?: __('Send message'),'success' => $c['success'] ?: __('Thank you! We will contact you shortly.')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.form-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section),'submit-label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['submit_label'] ?: __('Send message')),'success' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['success'] ?: __('Thank you! We will contact you shortly.'))]); ?>
            <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'name', 'label' => __('Full name'), 'type' => 'text', 'required' => true, 'autocomplete' => 'name'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'phone', 'label' => __('Mobile number'), 'type' => 'tel', 'required' => true, 'autocomplete' => 'tel'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'email', 'label' => __('Email'), 'type' => 'email', 'required' => false, 'autocomplete' => 'email'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'subject', 'label' => __('Subject'), 'type' => 'text', 'required' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('sections.partials.form-field', ['sectionId' => $section->id, 'name' => 'message', 'label' => __('Message'), 'type' => 'textarea', 'required' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal278a1e3ada932f630caf369b0e326277)): ?>
<?php $attributes = $__attributesOriginal278a1e3ada932f630caf369b0e326277; ?>
<?php unset($__attributesOriginal278a1e3ada932f630caf369b0e326277); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal278a1e3ada932f630caf369b0e326277)): ?>
<?php $component = $__componentOriginal278a1e3ada932f630caf369b0e326277; ?>
<?php unset($__componentOriginal278a1e3ada932f630caf369b0e326277); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/contact-form.blade.php ENDPATH**/ ?>
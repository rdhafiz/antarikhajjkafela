<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'solid']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'solid']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php $site = app(App\Support\SiteContext::class); ?>
<?php $branding = app(App\Support\Branding::class); ?>
<?php
    $menu = $site->menu('primary');
    $phones = $site->phones();
    $languages = $site->languages();
    $current = rtrim(request()->url(), '/');
    $home = rtrim(url('/'), '/');

    $isActive = function (array $item) use (&$isActive, $current, $home): bool {
        $url = rtrim((string) $item['url'], '/');

        if ($url !== '' && ($url === $current || ($url !== $home && str_starts_with($current.'/', $url.'/')))) {
            return true;
        }

        return collect($item['children'])->contains(fn ($child) => $isActive($child));
    };

    $overlay = $variant === 'overlay';
?>

<div x-data="siteHeader" @keydown.escape.window="closeMenu()" class="contents">
    
    <header
        data-transparent="<?php echo e($overlay ? 'true' : 'false'); ?>"
        :data-transparent="(!scrolled && <?php echo e($overlay ? 'true' : 'false'); ?>).toString()"
        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'group/header sticky top-0 z-30 border-b transition-[background-color,box-shadow,border-color] duration-300',
            'border-line/70 bg-white/92 backdrop-blur-md' => ! $overlay,
            'border-transparent -mb-[calc(5rem+1px)]' => $overlay,
        ]); ?>"
        :class="scrolled && '!border-line/70 !bg-white/92 shadow-[0_8px_30px_-18px_rgb(13_27_46/0.35)] backdrop-blur-md'"
    >
        <div class="container-site flex h-20 items-center justify-between gap-6">
            <a href="<?php echo e(url('/')); ?>" class="relative shrink-0" aria-label="<?php echo e($site->name()); ?> – <?php echo e(__('Home')); ?>">
                <img
                    src="<?php echo e($branding->logoUrl()); ?>"
                    srcset="<?php echo e($branding->logoSrcset()); ?>"
                    sizes="180px"
                    alt="<?php echo e($site->name()); ?>"
                    width="180"
                    height="61"
                    class="h-auto w-[150px] sm:w-[172px]"
                    fetchpriority="high"
                >
            </a>

            
            <nav class="hidden lg:block" aria-label="<?php echo e(__('Main')); ?>">
                <ul class="flex items-center gap-1 xl:gap-2">
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($active = $isActive($item)); ?>
                        <li class="relative" <?php if($item['children']): ?> x-data="dropdown" @mouseenter="show()" @mouseleave="hide()" @focusout="$el.contains($event.relatedTarget) || hide(0)" <?php endif; ?>>
                            <?php if($item['children']): ?>
                                <button
                                    type="button"
                                    @click="toggle()"
                                    :aria-expanded="open.toString()"
                                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'group flex items-center gap-1 rounded-full px-3.5 py-2 text-[15px] font-medium transition-colors',
                                        'text-brand' => $active,
                                    ]); ?>"
                                    :class="!scrolled && <?php echo e($overlay ? 'true' : 'false'); ?> ? 'text-white hover:text-gold' : '<?php echo e($active ? 'text-brand' : 'text-ink-2 hover:text-brand'); ?>'"
                                >
                                    <?php echo e($item['label']); ?>

                                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'chevron-down','class' => 'size-4 transition-transform duration-200',':class' => 'open && \'rotate-180\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','class' => 'size-4 transition-transform duration-200',':class' => 'open && \'rotate-180\'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                                </button>

                                <div
                                    x-cloak
                                    x-show="open"
                                    x-transition:enter="transition duration-200 ease-out"
                                    x-transition:enter-start="opacity-0 translate-y-1"
                                    x-transition:leave="transition duration-120 ease-in"
                                    x-transition:leave-end="opacity-0"
                                    class="absolute top-full left-1/2 z-40 w-64 -translate-x-1/2 pt-3"
                                >
                                    <ul class="card-site p-2 shadow-[var(--shadow-lift)]">
                                        <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <?php if($child['url']): ?>
                                                    <a href="<?php echo e($child['url']); ?>" <?php if($child['new_tab']): ?> target="_blank" rel="noopener" <?php endif; ?>
                                                       class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex items-center justify-between rounded-xl px-3.5 py-2.5 text-[15px] transition-colors hover:bg-sand-100', 'bg-sand-100 font-semibold text-brand' => $isActive($child), 'text-ink-2 hover:text-brand' => ! $isActive($child)]); ?>">
                                                        <?php echo e($child['label']); ?>

                                                    </a>
                                                <?php else: ?>
                                                    <p class="px-3.5 pt-3 pb-1 text-[12px] font-bold tracking-wider text-ink-3 uppercase"><?php echo e($child['label']); ?></p>
                                                <?php endif; ?>
                                                <?php if($child['children']): ?>
                                                    <ul class="mb-1 ml-3.5 border-l border-line pl-2">
                                                        <?php $__currentLoopData = $child['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <a href="<?php echo e($grandchild['url'] ?? '#'); ?>" <?php if($grandchild['new_tab']): ?> target="_blank" rel="noopener" <?php endif; ?>
                                                                   class="block rounded-lg px-3 py-2 text-[14px] text-ink-3 transition-colors hover:bg-sand-100 hover:text-brand">
                                                                    <?php echo e($grandchild['label']); ?>

                                                                </a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php else: ?>
                                <a
                                    href="<?php echo e($item['url'] ?? '#'); ?>"
                                    <?php if($item['new_tab']): ?> target="_blank" rel="noopener" <?php endif; ?>
                                    <?php if($active): ?> aria-current="page" <?php endif; ?>
                                    class="relative block rounded-full px-3.5 py-2 text-[15px] font-medium transition-colors"
                                    :class="!scrolled && <?php echo e($overlay ? 'true' : 'false'); ?> ? 'text-white hover:text-gold' : '<?php echo e($active ? 'text-brand' : 'text-ink-2 hover:text-brand'); ?>'"
                                >
                                    <?php echo e($item['label']); ?>

                                    <?php if($active): ?>
                                        <span class="absolute inset-x-3.5 -bottom-0.5 h-0.5 rounded-full bg-gold" aria-hidden="true"></span>
                                    <?php endif; ?>
                                </a>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </nav>

            <div class="flex items-center gap-2 sm:gap-3">
                <?php if(count($languages) > 1): ?>
                    <?php if (isset($component)) { $__componentOriginal35c1a2b72111dcb1d789219322a7ccd3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.language-switcher','data' => ['languages' => $languages,'tone' => 'header']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.language-switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['languages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($languages),'tone' => 'header']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3)): ?>
<?php $attributes = $__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3; ?>
<?php unset($__attributesOriginal35c1a2b72111dcb1d789219322a7ccd3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35c1a2b72111dcb1d789219322a7ccd3)): ?>
<?php $component = $__componentOriginal35c1a2b72111dcb1d789219322a7ccd3; ?>
<?php unset($__componentOriginal35c1a2b72111dcb1d789219322a7ccd3); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if($phones): ?>
                    <a href="<?php echo e($phones[0]['href']); ?>" class="btn btn-gold btn-sm hidden sm:inline-flex">
                        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                        <span class="hidden xl:inline"><?php echo e($phones[0]['display']); ?></span>
                        <span class="xl:hidden"><?php echo e(__('Call us')); ?></span>
                    </a>
                <?php endif; ?>
                <button
                    type="button"
                    class="-mr-2 flex size-11 items-center justify-center rounded-full transition-colors lg:hidden"
                    :class="!scrolled && <?php echo e($overlay ? 'true' : 'false'); ?> ? 'text-white hover:bg-white/10' : 'text-brand hover:bg-sand-100'"
                    x-ref="menuButton"
                    @click="openMenu($el)"
                    aria-controls="mobile-menu"
                    :aria-expanded="mobileOpen.toString()"
                >
                    <span class="sr-only"><?php echo e(__('Open menu')); ?></span>
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'menu','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu','class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                </button>
            </div>
        </div>
    </header>

    
    <div
        id="mobile-menu"
        class="mm lg:hidden"
        :class="mobileOpen && 'is-open'"
        :style="`--mm-origin: ${origin}`"
        role="dialog"
        aria-modal="true"
        aria-label="<?php echo e(__('Menu')); ?>"
        inert
        :inert="!mobileOpen"
    >
        <div class="mm-layer mm-layer-gold" aria-hidden="true"></div>
        <div class="mm-layer mm-layer-blue" aria-hidden="true"></div>

        <div class="mm-layer mm-layer-main" x-trap.noscroll="mobileOpen">
            <div class="mm-pattern pattern-star" aria-hidden="true"></div>
            <img src="<?php echo e($branding->iconUrl(512)); ?>" alt="" class="mm-emblem" width="512" height="512" loading="lazy" aria-hidden="true">
            <div class="mm-glow" aria-hidden="true"></div>

            <div class="relative flex h-full flex-col">
                
                <div class="mm-fade container-site flex h-20 shrink-0 items-center justify-between" style="--d: 380ms">
                    <a href="<?php echo e(url('/')); ?>" aria-label="<?php echo e($site->name()); ?> – <?php echo e(__('Home')); ?>">
                        <img src="<?php echo e($branding->logoUrl()); ?>" srcset="<?php echo e($branding->logoSrcset()); ?>" sizes="150px" alt="<?php echo e($site->name()); ?>" class="h-auto w-[150px]" loading="lazy">
                    </a>
                    <button type="button" class="mm-close" @click="closeMenu()">
                        <span class="sr-only"><?php echo e(__('Close menu')); ?></span>
                        <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'x','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    </button>
                </div>

                
                <nav class="container-site flex-1 overflow-y-auto overscroll-contain pt-6 pb-8" aria-label="<?php echo e(__('Main')); ?>">
                    <p class="mm-fade mb-5 text-[12px] font-semibold tracking-[0.2em] text-gold/80 uppercase" style="--d: 420ms"><?php echo e(__('Menu')); ?></p>
                    <ol class="space-y-1">
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($active = $isActive($item)); ?>
                            <li class="mm-item" style="--i: <?php echo e($index); ?>" <?php if($item['children']): ?> x-data="{ open: <?php echo e($active ? 'true' : 'false'); ?> }" <?php endif; ?>>
                                <div class="mm-mask">
                                    <?php if($item['children']): ?>
                                        <button type="button" @click="open = !open" :aria-expanded="open.toString()" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mm-link mm-rise w-full', 'is-active' => $active]); ?>">
                                            <span class="mm-index" aria-hidden="true"><?php echo e(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?></span>
                                            <span class="flex-1 text-left"><?php echo e($item['label']); ?></span>
                                            <span class="mm-toggle" :class="open && 'is-open'" aria-hidden="true"></span>
                                        </button>
                                    <?php else: ?>
                                        <a href="<?php echo e($item['url'] ?? '#'); ?>" <?php if($item['new_tab']): ?> target="_blank" rel="noopener" <?php endif; ?> <?php if($active): ?> aria-current="page" <?php endif; ?>
                                           class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mm-link mm-rise', 'is-active' => $active]); ?>">
                                            <span class="mm-index" aria-hidden="true"><?php echo e(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?></span>
                                            <span><?php echo e($item['label']); ?></span>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <?php if($item['children']): ?>
                                    <ul x-show="open" x-collapse <?php if (! ($active)): ?> x-cloak <?php endif; ?> class="mt-1 mb-3 ml-[2.6rem] space-y-0.5 border-l border-gold/30 pl-4">
                                        <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e($child['url'] ?? '#'); ?>" <?php if($child['new_tab']): ?> target="_blank" rel="noopener" <?php endif; ?>
                                                   class="<?php echo \Illuminate\Support\Arr::toCssClasses(['block py-2 text-[17px] transition-colors', 'font-semibold text-gold' => $isActive($child), 'text-white/75 hover:text-white' => ! $isActive($child)]); ?>">
                                                    <?php echo e($child['label']); ?>

                                                </a>
                                                <?php $__currentLoopData = $child['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e($grandchild['url'] ?? '#'); ?>" class="block py-1.5 pl-4 text-[15px] text-white/55 hover:text-white"><?php echo e($grandchild['label']); ?></a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </nav>

                
                <div class="mm-fade shrink-0 border-t border-white/10 bg-brand-950/60 backdrop-blur-md" style="--d: 560ms">
                    <div class="container-site py-5" style="padding-bottom: max(1.25rem, env(safe-area-inset-bottom))">
                        <div class="grid grid-cols-2 gap-3">
                            <?php if($phones): ?>
                                <a href="<?php echo e($phones[0]['href']); ?>" class="btn btn-gold"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?> <?php echo e(__('Call')); ?></a>
                            <?php endif; ?>
                            <?php if($whatsapp = $site->whatsappUrl()): ?>
                                <a href="<?php echo e($whatsapp); ?>" target="_blank" rel="noopener" class="btn btn-whatsapp"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'whatsapp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'whatsapp']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?> WhatsApp</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/header.blade.php ENDPATH**/ ?>
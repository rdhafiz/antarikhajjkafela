<?php $branding = app(App\Support\Branding::class); ?>
<?php ($colors = $branding->colors()); ?>
<meta name="theme-color" content="<?php echo e($colors['primary']); ?>">
<style>
    :root {
        --brand-primary: <?php echo e($colors['primary']); ?>;
        --brand-secondary: <?php echo e($colors['secondary']); ?>;
        --brand-accent: <?php echo e($colors['accent']); ?>;
    }
</style>
<link rel="icon" type="image/webp" sizes="32x32" href="<?php echo e($branding->faviconUrl(32)); ?>">
<link rel="icon" type="image/webp" sizes="192x192" href="<?php echo e($branding->faviconUrl(192)); ?>">
<link rel="apple-touch-icon" href="<?php echo e($branding->iconUrl(192)); ?>">
<link rel="manifest" href="<?php echo e(route('manifest')); ?>">
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/brand-head.blade.php ENDPATH**/ ?>
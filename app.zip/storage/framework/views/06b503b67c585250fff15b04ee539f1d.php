<?php $site = app(App\Support\SiteContext::class); ?>
<?php
    use App\Domain\Travel\PackagePresenter;
    use App\Support\Money;

    $result = session('payment_result');
    $statusLabels = [
        'pending' => __('Pending confirmation'),
        'confirmed' => __('Confirmed'),
        'advance_paid' => __('Advance paid'),
        'fully_paid' => __('Fully paid'),
        'completed' => __('Completed'),
        'cancelled' => __('Cancelled'),
    ];
    $tone = match ($booking->status) {
        'cancelled' => 'bg-red-600 text-white',
        'pending' => 'bg-gold text-brand-950',
        default => 'bg-emerald text-white',
    };
    $phones = $site->phones();
?>
<?php if (isset($component)) { $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.layout','data' => ['analytics' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['analytics' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
    <section class="section-light bg-sand-50 py-12 sm:py-16">
        <div class="container-site max-w-4xl">
            
            <?php if($result === 'paid'): ?>
                <div class="mb-6 flex gap-4 rounded-2xl bg-emerald/10 p-5 text-emerald ring-1 ring-emerald/25" role="status">
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check-circle','class' => 'size-7 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','class' => 'size-7 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    <div><p class="font-semibold text-ink"><?php echo e(__('Payment received. Jazakallahu khairan!')); ?></p><p class="mt-1 text-[14px] text-ink-2"><?php echo e(__('A receipt has been sent to your email. Our team will contact you with the next steps.')); ?></p></div>
                </div>
            <?php elseif(in_array($result, ['failed', 'cancelled'], true)): ?>
                <div class="mb-6 rounded-2xl bg-red-50 p-5 ring-1 ring-red-200" role="alert">
                    <p class="font-semibold text-red-800"><?php echo e($result === 'cancelled' ? __('The payment was cancelled.') : __('The payment did not go through.')); ?></p>
                    <p class="mt-1 text-[14px] text-red-800/80"><?php echo e(__('Your booking is saved. You can try again below or pay us directly.')); ?></p>
                </div>
            <?php elseif($result === 'pending'): ?>
                <div class="mb-6 rounded-2xl bg-gold/15 p-5 ring-1 ring-gold/40" role="status">
                    <p class="font-semibold text-ink"><?php echo e(__('We are confirming your payment.')); ?></p>
                    <p class="mt-1 text-[14px] text-ink-2"><?php echo e(__('This can take a few minutes. Refresh this page later, or call us if the amount was taken from your account.')); ?></p>
                </div>
            <?php elseif($result === 'unavailable'): ?>
                <div class="mb-6 rounded-2xl bg-gold/15 p-5 ring-1 ring-gold/40" role="status">
                    <p class="font-semibold text-ink"><?php echo e(__('Online payment is not available right now.')); ?></p>
                    <p class="mt-1 text-[14px] text-ink-2"><?php echo e(__('Your booking is saved. Please try again later or contact us to pay.')); ?></p>
                </div>
            <?php elseif(session('booking_created')): ?>
                <div class="mb-6 flex gap-4 rounded-2xl bg-emerald/10 p-5 text-emerald ring-1 ring-emerald/25" role="status">
                    <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'check-circle','class' => 'size-7 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','class' => 'size-7 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                    <div><p class="font-semibold text-ink"><?php echo e(__('Your booking has been received.')); ?></p><p class="mt-1 text-[14px] text-ink-2"><?php echo e(__('Our team will call you shortly to confirm. Save this page or your reference number.')); ?></p></div>
                </div>
            <?php endif; ?>

            <div class="overflow-hidden rounded-[1.75rem] bg-white shadow-[var(--shadow-lift)] ring-1 ring-line">
                
                <div class="relative bg-brand-950 p-6 text-white sm:p-9">
                    <div class="pattern-star absolute inset-0 opacity-[0.05]" aria-hidden="true"></div>
                    <div class="relative flex flex-wrap items-start justify-between gap-5">
                        <div>
                            <p class="text-[12px] font-semibold tracking-wider text-gold uppercase"><?php echo e(__('Booking reference')); ?></p>
                            <h1 class="mt-2 font-display text-[2rem] leading-none font-semibold tracking-wide"><?php echo e($booking->reference); ?></h1>
                            <p class="mt-3 text-[14px] text-white/65"><?php echo e(__('Booked on :date', ['date' => App\Support\Dates::format($booking->created_at)])); ?></p>
                        </div>
                        <span class="rounded-full px-4 py-1.5 text-[14px] font-semibold <?php echo e($tone); ?>"><?php echo e($statusLabels[$booking->status] ?? $booking->status); ?></span>
                    </div>
                </div>

                <div class="grid gap-8 p-6 sm:p-9 md:grid-cols-[1.2fr_1fr]">
                    
                    <div>
                        <h2 class="text-[13px] font-semibold tracking-wider text-ink-3 uppercase"><?php echo e(__('Package')); ?></h2>
                        <p class="mt-2 font-display text-display-sm text-brand">
                            <?php if($booking->package?->isPublished()): ?>
                                <a href="<?php echo e($booking->package->url()); ?>" class="hover:underline"><?php echo e($booking->snap('package')); ?></a>
                            <?php else: ?>
                                <?php echo e($booking->snap('package')); ?>

                            <?php endif; ?>
                        </p>
                        <p class="mt-1 text-ink-2"><?php echo e(trim($booking->snap('type').' – '.$booking->snap('option'), ' –')); ?></p>

                        <dl class="mt-6 grid grid-cols-2 gap-4 text-[15px]">
                            <div><dt class="text-[13px] text-ink-3"><?php echo e(__('Travelers')); ?></dt><dd class="font-semibold text-ink"><?php echo e(Money::digits($booking->travelers)); ?></dd></div>
                            <div><dt class="text-[13px] text-ink-3"><?php echo e(__('Price')); ?></dt><dd class="font-semibold text-ink"><?php echo e(Money::html($booking->unit_price)); ?> <span class="text-[13px] font-normal text-ink-3"><?php echo e(PackagePresenter::unitLabel($booking->snapshot['unit'] ?? 'person')); ?></span></dd></div>
                            <div><dt class="text-[13px] text-ink-3"><?php echo e(__('Name')); ?></dt><dd class="font-semibold text-ink"><?php echo e($booking->customer_name); ?></dd></div>
                            <div><dt class="text-[13px] text-ink-3"><?php echo e(__('Mobile number')); ?></dt><dd class="font-semibold text-ink"><?php echo e($booking->customer_phone); ?></dd></div>
                        </dl>
                    </div>

                    
                    <div class="rounded-2xl bg-sand-50 p-6 ring-1 ring-line">
                        <dl class="space-y-3 text-[15px]">
                            <div class="flex justify-between gap-4"><dt class="text-ink-2"><?php echo e(__('Total')); ?></dt><dd class="font-semibold text-ink"><?php echo e(Money::html($booking->total)); ?></dd></div>
                            <?php if((float) $booking->advance_amount > 0): ?>
                                <div class="flex justify-between gap-4"><dt class="text-ink-2"><?php echo e(__('Advance')); ?></dt><dd class="text-ink"><?php echo e(Money::html($booking->advance_amount)); ?></dd></div>
                            <?php endif; ?>
                            <div class="flex justify-between gap-4"><dt class="text-ink-2"><?php echo e(__('Paid')); ?></dt><dd class="font-semibold text-emerald"><?php echo e(Money::html($booking->paid_amount)); ?></dd></div>
                            <div class="flex justify-between gap-4 border-t border-line pt-3 text-lg"><dt class="font-semibold text-ink"><?php echo e(__('Balance')); ?></dt><dd class="font-display font-semibold text-brand"><?php echo e(Money::html($booking->balance())); ?></dd></div>
                        </dl>

                        <?php if($canPay): ?>
                            <form method="POST" action="<?php echo e(URL::signedRoute('bookings.pay', ['booking' => $booking->reference])); ?>" class="mt-6" x-data="{ busy: false }" @submit="busy = true">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary w-full" :disabled="busy"><?php echo e(__('Pay advance :amount online', ['amount' => Money::format($booking->advanceDue())])); ?></button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($booking->payments->isNotEmpty()): ?>
                    <div class="border-t border-line p-6 sm:px-9">
                        <h2 class="text-[13px] font-semibold tracking-wider text-ink-3 uppercase"><?php echo e(__('Payments')); ?></h2>
                        <ul class="mt-3 divide-y divide-line">
                            <?php $__currentLoopData = $booking->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex flex-wrap justify-between gap-3 py-3 text-[15px]">
                                    <span class="text-ink-2"><?php echo e(App\Support\Dates::format($payment->paid_at)); ?> · <?php echo e($payment->is_online ? $payment->methodLabel() : __('Office payment')); ?></span>
                                    <span class="font-semibold text-ink"><?php echo e(Money::html($payment->amount)); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="flex flex-col gap-4 border-t border-line bg-sand-50/60 p-6 sm:flex-row sm:items-center sm:justify-between sm:px-9">
                    <p class="text-[14px] text-ink-2"><?php echo e(__('Questions about your booking? Call us with your reference number.')); ?></p>
                    <div class="flex gap-3">
                        <?php if($phones): ?>
                            <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $phones[0]['href'],'variant' => 'outline','icon' => 'phone','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($phones[0]['href']),'variant' => 'outline','icon' => 'phone','size' => 'sm']); ?><?php echo e($phones[0]['display']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
                        <?php endif; ?>
                        <?php if($wa = $site->whatsappUrl(__('Assalamu alaikum, my booking reference is :reference.', ['reference' => $booking->reference]))): ?>
                            <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $wa,'variant' => 'whatsapp','icon' => 'whatsapp','size' => 'sm','external' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($wa),'variant' => 'whatsapp','icon' => 'whatsapp','size' => 'sm','external' => true]); ?>WhatsApp <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $attributes = $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $component = $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/bookings/show.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['c', 'align' => 'center', 'as' => 'h2']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['c', 'align' => 'center', 'as' => 'h2']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(filled($c['eyebrow'] ?? null) || filled($c['title'] ?? null) || filled($c['intro'] ?? null)): ?>
    <div <?php echo e($attributes->class(['max-w-2xl', 'mx-auto text-center' => $align === 'center'])); ?> data-reveal>
        <?php if(filled($c['eyebrow'] ?? null)): ?>
            <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['eyebrow', 'justify-center' => $align === 'center']); ?>"><?php echo e($c['eyebrow']); ?></p>
        <?php endif; ?>
        <?php if(filled($c['title'] ?? null)): ?>
            <<?php echo e($as); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sec-heading text-display-lg', 'mt-4' => filled($c['eyebrow'] ?? null)]); ?>"><?php echo e($c['title']); ?></<?php echo e($as); ?>>
        <?php endif; ?>
        <?php if(filled($c['intro'] ?? null)): ?>
            <p class="sec-text mt-5 text-[1.0625rem] leading-relaxed"><?php echo e($c['intro']); ?></p>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/components/site/block-heading.blade.php ENDPATH**/ ?>
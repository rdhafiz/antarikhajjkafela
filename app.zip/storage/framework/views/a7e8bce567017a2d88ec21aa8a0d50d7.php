<?php ($title = filled($c['title']) ? $c['title'] : $page->getTranslation('title', app()->getLocale())); ?>

<?php if (isset($component)) { $__componentOriginal7581f317093bf3292868869e04b36f91 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7581f317093bf3292868869e04b36f91 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.hero','data' => ['title' => $title,'eyebrow' => $c['eyebrow'],'highlight' => $c['highlight'] ?? null,'intro' => $c['intro'],'image' => $c['image'] ?? $style['image'],'top' => $first,'id' => $style['id'],'dataSection' => 'page_banner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'eyebrow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['eyebrow']),'highlight' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['highlight'] ?? null),'intro' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['intro']),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c['image'] ?? $style['image']),'top' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($first),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style['id']),'data-section' => 'page_banner']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7581f317093bf3292868869e04b36f91)): ?>
<?php $attributes = $__attributesOriginal7581f317093bf3292868869e04b36f91; ?>
<?php unset($__attributesOriginal7581f317093bf3292868869e04b36f91); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7581f317093bf3292868869e04b36f91)): ?>
<?php $component = $__componentOriginal7581f317093bf3292868869e04b36f91; ?>
<?php unset($__componentOriginal7581f317093bf3292868869e04b36f91); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/sections/page-banner.blade.php ENDPATH**/ ?>
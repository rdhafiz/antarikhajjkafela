
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <title><?php echo e($title); ?></title>
    <style>
        *{box-sizing:border-box}
        body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;background:#f7f2e9;color:#0d1b2e;font-family:system-ui,-apple-system,'Segoe UI',Roboto,'Noto Sans Bengali',sans-serif}
        main{max-width:520px;text-align:center}
        img{width:160px;height:auto}
        .code{margin:28px 0 0;font:600 64px/1 Georgia,serif;color:#846500}
        h1{margin:12px 0 0;font:600 28px/1.25 Georgia,serif;color:#012a51}
        p{margin:14px 0 0;line-height:1.6;color:#3d4b5f}
        a{display:inline-block;margin-top:28px;padding:12px 26px;border-radius:999px;background:#012a51;color:#fff;font-weight:600;text-decoration:none}
        a:focus-visible{outline:3px solid #fdc802;outline-offset:3px}
    </style>
</head>
<body>
    <main>
        <img src="<?php echo e(asset('images/brand/logo-360.webp')); ?>" alt="<?php echo e(config('app.name')); ?>" width="160" height="55">
        <p class="code" aria-hidden="true"><?php echo e($code); ?></p>
        <h1><?php echo e($title); ?></h1>
        <p><?php echo e($text); ?></p>
        <?php if($code !== 503): ?>
            <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Back to home')); ?></a>
        <?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/errors/minimal-layout.blade.php ENDPATH**/ ?>
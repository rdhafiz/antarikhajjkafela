<?php
    $locale = app()->getLocale();
    $title = $service?->getTranslation('name', $locale) ?? __('Hajj & Umrah packages');
    $intro = $service?->getTranslation('summary', $locale) ?? __('Compare our packages: hotels near the Haram, flights, durations and prices, all guided by experienced scholars.');
?>
<?php if (isset($component)) { $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.layout','data' => ['header' => 'overlay']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'overlay']); ?>
    <?php if (isset($component)) { $__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-header','data' => ['eyebrow' => $service ? __('Packages') : __('Our packages'),'title' => $title,'intro' => $intro,'image' => $service?->image]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service ? __('Packages') : __('Our packages')),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'intro' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($intro),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service?->image)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a)): ?>
<?php $attributes = $__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a; ?>
<?php unset($__attributesOriginal9c22c6e74234f1a5584eeca12ed79c5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a)): ?>
<?php $component = $__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a; ?>
<?php unset($__componentOriginal9c22c6e74234f1a5584eeca12ed79c5a); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal2472f7d0b1ca22068dd46dfd59e8a3a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2472f7d0b1ca22068dd46dfd59e8a3a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.section','data' => ['tone' => 'sand','spacing' => 'md']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'sand','spacing' => 'md']); ?>
        <?php if($services->count() > 1): ?>
            <nav class="mx-auto mb-10 flex max-w-6xl flex-wrap gap-2" aria-label="<?php echo e(__('Filter packages')); ?>">
                <a href="<?php echo e(route('packages.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'rounded-full px-5 py-2 text-[15px] font-semibold transition-colors',
                    'bg-brand text-white' => ! $current,
                    'bg-white text-ink-2 ring-1 ring-line hover:text-brand' => $current,
                ]); ?>" <?php if(! $current): ?> aria-current="page" <?php endif; ?>><?php echo e(__('All')); ?></a>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($item->url()); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'rounded-full px-5 py-2 text-[15px] font-semibold transition-colors',
                        'bg-brand text-white' => $current?->is($item),
                        'bg-white text-ink-2 ring-1 ring-line hover:text-brand' => ! $current?->is($item),
                    ]); ?>" <?php if($current?->is($item)): ?> aria-current="page" <?php endif; ?>><?php echo e($item->getTranslation('name', $locale)); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
        <?php endif; ?>

        <?php if($service && ($description = $service->getTranslation('description', $locale))): ?>
            <div class="mb-12 max-w-3xl text-[1.0625rem] leading-relaxed whitespace-pre-line text-ink-2"><?php echo e($description); ?></div>
        <?php endif; ?>

        <?php if($packages->isEmpty()): ?>
            <div class="card-site flex flex-col items-center px-6 py-16 text-center">
                <?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'calendar','class' => 'size-10 text-gold-deep']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'calendar','class' => 'size-10 text-gold-deep']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
                <h2 class="mt-5 font-display text-display-sm text-brand"><?php echo e(__('New packages are being prepared')); ?></h2>
                <p class="mt-3 max-w-md text-ink-2"><?php echo e(__('Call or message us and we will share the latest packages and prices with you.')); ?></p>
            </div>
        <?php else: ?>
            <h2 class="sr-only"><?php echo e(__('Packages')); ?></h2>
            <div class="mx-auto grid max-w-6xl gap-8">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal897f6239282c9c8b6123196ed596e8ff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal897f6239282c9c8b6123196ed596e8ff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.package-feature','data' => ['package' => $package,'card' => $cards[$package->id],'showService' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.package-feature'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['package' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($package),'card' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cards[$package->id]),'show-service' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal897f6239282c9c8b6123196ed596e8ff)): ?>
<?php $attributes = $__attributesOriginal897f6239282c9c8b6123196ed596e8ff; ?>
<?php unset($__attributesOriginal897f6239282c9c8b6123196ed596e8ff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal897f6239282c9c8b6123196ed596e8ff)): ?>
<?php $component = $__componentOriginal897f6239282c9c8b6123196ed596e8ff; ?>
<?php unset($__componentOriginal897f6239282c9c8b6123196ed596e8ff); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2472f7d0b1ca22068dd46dfd59e8a3a7)): ?>
<?php $attributes = $__attributesOriginal2472f7d0b1ca22068dd46dfd59e8a3a7; ?>
<?php unset($__attributesOriginal2472f7d0b1ca22068dd46dfd59e8a3a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2472f7d0b1ca22068dd46dfd59e8a3a7)): ?>
<?php $component = $__componentOriginal2472f7d0b1ca22068dd46dfd59e8a3a7; ?>
<?php unset($__componentOriginal2472f7d0b1ca22068dd46dfd59e8a3a7); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $attributes = $__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__attributesOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519)): ?>
<?php $component = $__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519; ?>
<?php unset($__componentOriginal13c2ac5f3b2b74a0bb24b2968555c519); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/packages/index.blade.php ENDPATH**/ ?>
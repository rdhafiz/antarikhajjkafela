
<?php
    use App\Support\Money;

    $locale = app()->getLocale();
    $title = filled($c['title'] ?? null) ? $c['title'] : ($first ? $page->getTranslation('title', $locale) : null);
    $rest = $featured ? $albums->getCollection()->slice(1)->values() : $albums->getCollection();
    $headingTag = $first ? 'h1' : 'h2';
?>
<?php if (isset($component)) { $__componentOriginal482661b7d50aaefe02fb7b4750f214a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.block','data' => ['style' => $style,'section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($style),'section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="pointer-events-none absolute -top-40 left-1/2 -z-10 size-[620px] -translate-x-1/2 rounded-full bg-gold/10 blur-3xl" data-parallax="-0.15" aria-hidden="true"></div>

    
    <?php if($title || filled($c['eyebrow'] ?? null) || filled($c['intro'] ?? null)): ?>
        <div class="mx-auto mb-12 max-w-2xl text-center sm:mb-14" data-reveal>
            <?php if(filled($c['eyebrow'] ?? null)): ?><p class="eyebrow justify-center"><?php echo e($c['eyebrow']); ?></p><?php endif; ?>
            <?php if($title): ?>
                <<?php echo e($headingTag); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sec-heading text-display-lg', 'mt-4' => filled($c['eyebrow'] ?? null)]); ?>"><?php echo e($title); ?></<?php echo e($headingTag); ?>>
            <?php endif; ?>
            <?php if(filled($c['intro'] ?? null)): ?><p class="sec-text mt-5 text-[1.0625rem] leading-relaxed"><?php echo e($c['intro']); ?></p><?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if($albums->isEmpty()): ?>
        <div class="mx-auto max-w-md py-10 text-center" data-reveal>
            <span class="sec-icon mx-auto size-14"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'images','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'images','class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?></span>
            <p class="sec-heading mt-5 font-display text-display-sm"><?php echo e(__('Photos coming soon')); ?></p>
        </div>
    <?php else: ?>
        <h2 class="sr-only"><?php echo e(__('Albums')); ?></h2>

        
        <?php if($featured): ?>
            <article class="mx-auto max-w-6xl">
                <div class="relative isolate flex min-h-[24rem] flex-col items-start justify-end overflow-hidden rounded-[2rem] bg-brand-950 px-6 pt-24 pb-9 text-start text-white shadow-[var(--shadow-lift)] sm:min-h-[30rem] sm:px-12 sm:pb-12">
                    <?php if($featured->cover): ?>
                        <img src="<?php echo e($featured->cover->url('lg') ?? $featured->cover->url('md')); ?>" srcset="<?php echo e($featured->cover->srcset()); ?>" sizes="(min-width: 1200px) 1150px, 100vw" alt=""
                             class="absolute inset-0 -z-20 size-full object-cover">
                    <?php else: ?>
                        <div class="pattern-star absolute inset-0 -z-20 opacity-[0.08]" aria-hidden="true"></div>
                    <?php endif; ?>
                    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-brand-950/90 via-brand-950/45 to-transparent rtl:bg-gradient-to-l" aria-hidden="true"></div>
                    <div class="absolute inset-x-0 bottom-0 -z-10 h-2/3 bg-gradient-to-t from-brand-950/85 to-transparent" aria-hidden="true"></div>

                    <div class="flex max-w-xl flex-col items-start" data-reveal>
                        <p class="flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] font-semibold text-gold">
                            <span class="rounded-full bg-gold px-3 py-1 text-[12px] font-bold text-brand-950"><?php echo e(__('Latest album')); ?></span>
                            <?php if($featured->event_date): ?><span><?php echo e(App\Support\Dates::format($featured->event_date, 'j F Y', $locale)); ?></span><?php endif; ?>
                        </p>
                        <h3 class="mt-4 font-display text-display-lg text-white"><?php echo e($featured->getTranslation('title', $locale)); ?></h3>
                        <?php if(filled($description = $featured->getTranslation('description', $locale))): ?>
                            <p class="mt-3 line-clamp-2 text-[1.0625rem] leading-relaxed text-white/80"><?php echo e($description); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="mt-7 flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:gap-6" data-reveal style="--reveal-delay: 120ms">
                        <p class="flex items-center gap-4 text-[14px] font-medium text-white/80">
                            <?php if($featured->images_count): ?>
                                <span class="inline-flex items-center gap-1.5"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'image','class' => 'size-4 text-gold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image','class' => 'size-4 text-gold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(trans_choice(':count photo|:count photos', $featured->images_count, ['count' => Money::digits($featured->images_count)])); ?></span>
                            <?php endif; ?>
                            <?php if($featured->videos_count): ?>
                                <span class="inline-flex items-center gap-1.5"><?php if (isset($component)) { $__componentOriginala8b802320c1b90e42beaaa41cb5d3644 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.icon','data' => ['name' => 'play','class' => 'size-4 text-gold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','class' => 'size-4 text-gold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $attributes = $__attributesOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__attributesOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644)): ?>
<?php $component = $__componentOriginala8b802320c1b90e42beaaa41cb5d3644; ?>
<?php unset($__componentOriginala8b802320c1b90e42beaaa41cb5d3644); ?>
<?php endif; ?><?php echo e(trans_choice(':count video|:count videos', $featured->videos_count, ['count' => Money::digits($featured->videos_count)])); ?></span>
                            <?php endif; ?>
                        </p>
                        <?php if (isset($component)) { $__componentOriginalb1a2106982ac627324c4693af9429db9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1a2106982ac627324c4693af9429db9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.button','data' => ['href' => $featured->url(),'variant' => 'gold','iconRight' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featured->url()),'variant' => 'gold','icon-right' => 'arrow-right']); ?><?php echo e(__('View album')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $attributes = $__attributesOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__attributesOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1a2106982ac627324c4693af9429db9)): ?>
<?php $component = $__componentOriginalb1a2106982ac627324c4693af9429db9; ?>
<?php unset($__componentOriginalb1a2106982ac627324c4693af9429db9); ?>
<?php endif; ?>
                    </div>
                </div>
            </article>
        <?php endif; ?>

        
        <?php if($rest->isNotEmpty()): ?>
            <?php if($featured): ?>
                <div class="mx-auto mt-16 mb-8 max-w-xl text-center" data-reveal>
                    <p class="eyebrow justify-center"><?php echo e(__('More albums')); ?></p>
                </div>
            <?php endif; ?>
            <div class="mx-auto flex max-w-6xl flex-wrap justify-center gap-6">
                <?php $__currentLoopData = $rest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.album-card','data' => ['album' => $album,'class' => 'w-full sm:w-[calc(50%-0.75rem)] lg:w-[calc(33.333%-1rem)]','dataReveal' => true,'style' => '--reveal-delay: '.(($index % 3) * 90).'ms']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.album-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['album' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($album),'class' => 'w-full sm:w-[calc(50%-0.75rem)] lg:w-[calc(33.333%-1rem)]','data-reveal' => true,'style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('--reveal-delay: '.(($index % 3) * 90).'ms')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3)): ?>
<?php $attributes = $__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3; ?>
<?php unset($__attributesOriginal089d0f518bc1f3929da9f7ef6678e8c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3)): ?>
<?php $component = $__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3; ?>
<?php unset($__componentOriginal089d0f518bc1f3929da9f7ef6678e8c3); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal421d6be1b5f010ae1063d2260f192bb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal421d6be1b5f010ae1063d2260f192bb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.pagination','data' => ['paginator' => $albums,'class' => 'mt-14 flex justify-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($albums),'class' => 'mt-14 flex justify-center']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal421d6be1b5f010ae1063d2260f192bb5)): ?>
<?php $attributes = $__attributesOriginal421d6be1b5f010ae1063d2260f192bb5; ?>
<?php unset($__attributesOriginal421d6be1b5f010ae1063d2260f192bb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal421d6be1b5f010ae1063d2260f192bb5)): ?>
<?php $component = $__componentOriginal421d6be1b5f010ae1063d2260f192bb5; ?>
<?php unset($__componentOriginal421d6be1b5f010ae1063d2260f192bb5); ?>
<?php endif; ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $attributes = $__attributesOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__attributesOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0)): ?>
<?php $component = $__componentOriginal482661b7d50aaefe02fb7b4750f214a0; ?>
<?php unset($__componentOriginal482661b7d50aaefe02fb7b4750f214a0); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\antarikhajjkafela\resources\views/site/gallery/listing.blade.php ENDPATH**/ ?>
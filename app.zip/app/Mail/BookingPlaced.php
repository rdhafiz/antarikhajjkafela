<?php

namespace App\Mail;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * Sent to the agency when a new booking arrives.
 */
class BookingPlaced extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Booking $booking) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: "New booking {$this->booking->reference}: {$this->booking->customer_name}",
            replyTo: $this->booking->customer_email ? [new Address($this->booking->customer_email, $this->booking->customer_name)] : [],
        );
    }

    public function content(): Content
    {
        return new Content(view: 'emails.booking-placed');
    }
}
